package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the SLOT_PROFILE database table.
 * 
 */
@Embeddable
public class SlotProfilePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PROF_NAME")
	private String profName;

	@Column(name="WH_ID")
	private String whId;

	public SlotProfilePK() {
	}
	public String getProfName() {
		return this.profName;
	}
	public void setProfName(String profName) {
		this.profName = profName;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SlotProfilePK)) {
			return false;
		}
		SlotProfilePK castOther = (SlotProfilePK)other;
		return 
			this.profName.equals(castOther.profName)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.profName.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}