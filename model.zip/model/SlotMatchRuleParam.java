package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SLOT_MATCH_RULE_PARAMS database table.
 * 
 */
@Entity
@Table(name="SLOT_MATCH_RULE_PARAMS")
@NamedQuery(name="SlotMatchRuleParam.findAll", query="SELECT s FROM SlotMatchRuleParam s")
public class SlotMatchRuleParam implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SlotMatchRuleParamPK id;

	@Temporal(TemporalType.DATE)
	@Column(name="CTRL_DT")
	private Date ctrlDt;

	@Column(name="CTRL_USER_ID")
	private String ctrlUserId;

	@Column(name="PARAM_REQ_FLG")
	private BigDecimal paramReqFlg;

	@Column(name="PARAM_SET_NAME_FLG")
	private BigDecimal paramSetNameFlg;

	@Column(name="VAR_NAM")
	private String varNam;

	public SlotMatchRuleParam() {
	}

	public SlotMatchRuleParamPK getId() {
		return this.id;
	}

	public void setId(SlotMatchRuleParamPK id) {
		this.id = id;
	}

	public Date getCtrlDt() {
		return this.ctrlDt;
	}

	public void setCtrlDt(Date ctrlDt) {
		this.ctrlDt = ctrlDt;
	}

	public String getCtrlUserId() {
		return this.ctrlUserId;
	}

	public void setCtrlUserId(String ctrlUserId) {
		this.ctrlUserId = ctrlUserId;
	}

	public BigDecimal getParamReqFlg() {
		return this.paramReqFlg;
	}

	public void setParamReqFlg(BigDecimal paramReqFlg) {
		this.paramReqFlg = paramReqFlg;
	}

	public BigDecimal getParamSetNameFlg() {
		return this.paramSetNameFlg;
	}

	public void setParamSetNameFlg(BigDecimal paramSetNameFlg) {
		this.paramSetNameFlg = paramSetNameFlg;
	}

	public String getVarNam() {
		return this.varNam;
	}

	public void setVarNam(String varNam) {
		this.varNam = varNam;
	}

}