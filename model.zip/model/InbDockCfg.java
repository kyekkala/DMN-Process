package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the INB_DOCK_CFG database table.
 * 
 */
@Entity
@Table(name="INB_DOCK_CFG")
@NamedQuery(name="InbDockCfg.findAll", query="SELECT i FROM InbDockCfg i")
public class InbDockCfg implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private InbDockCfgPK id;

	@Column(name="PRT_CLIENT_ID")
	private String prtClientId;

	@Column(name="PRT_CLIENT_ID_FLG")
	private BigDecimal prtClientIdFlg;

	private String prtfam;

	@Column(name="PRTFAM_FLG")
	private BigDecimal prtfamFlg;

	private String prtfamgrp;

	@Column(name="PRTFAMGRP_FLG")
	private BigDecimal prtfamgrpFlg;

	private String prtnum;

	@Column(name="PRTNUM_FLG")
	private BigDecimal prtnumFlg;

	private BigDecimal seqnum;

	@Column(name="THRESH_PCT")
	private BigDecimal threshPct;

	public InbDockCfg() {
	}

	public InbDockCfgPK getId() {
		return this.id;
	}

	public void setId(InbDockCfgPK id) {
		this.id = id;
	}

	public String getPrtClientId() {
		return this.prtClientId;
	}

	public void setPrtClientId(String prtClientId) {
		this.prtClientId = prtClientId;
	}

	public BigDecimal getPrtClientIdFlg() {
		return this.prtClientIdFlg;
	}

	public void setPrtClientIdFlg(BigDecimal prtClientIdFlg) {
		this.prtClientIdFlg = prtClientIdFlg;
	}

	public String getPrtfam() {
		return this.prtfam;
	}

	public void setPrtfam(String prtfam) {
		this.prtfam = prtfam;
	}

	public BigDecimal getPrtfamFlg() {
		return this.prtfamFlg;
	}

	public void setPrtfamFlg(BigDecimal prtfamFlg) {
		this.prtfamFlg = prtfamFlg;
	}

	public String getPrtfamgrp() {
		return this.prtfamgrp;
	}

	public void setPrtfamgrp(String prtfamgrp) {
		this.prtfamgrp = prtfamgrp;
	}

	public BigDecimal getPrtfamgrpFlg() {
		return this.prtfamgrpFlg;
	}

	public void setPrtfamgrpFlg(BigDecimal prtfamgrpFlg) {
		this.prtfamgrpFlg = prtfamgrpFlg;
	}

	public String getPrtnum() {
		return this.prtnum;
	}

	public void setPrtnum(String prtnum) {
		this.prtnum = prtnum;
	}

	public BigDecimal getPrtnumFlg() {
		return this.prtnumFlg;
	}

	public void setPrtnumFlg(BigDecimal prtnumFlg) {
		this.prtnumFlg = prtnumFlg;
	}

	public BigDecimal getSeqnum() {
		return this.seqnum;
	}

	public void setSeqnum(BigDecimal seqnum) {
		this.seqnum = seqnum;
	}

	public BigDecimal getThreshPct() {
		return this.threshPct;
	}

	public void setThreshPct(BigDecimal threshPct) {
		this.threshPct = threshPct;
	}

}