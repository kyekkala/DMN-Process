package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PACK_CFG database table.
 * 
 */
@Embeddable
public class PackCfgPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="WH_ID")
	private String whId;

	@Column(name="CLIENT_ID")
	private String clientId;

	public PackCfgPK() {
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getClientId() {
		return this.clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PackCfgPK)) {
			return false;
		}
		PackCfgPK castOther = (PackCfgPK)other;
		return 
			this.whId.equals(castOther.whId)
			&& this.clientId.equals(castOther.clientId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.clientId.hashCode();
		
		return hash;
	}
}