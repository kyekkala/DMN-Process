package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PCK_REL_RULE database table.
 * 
 */
@Entity
@Table(name="PCK_REL_RULE")
@NamedQuery(name="PckRelRule.findAll", query="SELECT p FROM PckRelRule p")
public class PckRelRule implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PCK_REL_RULE_ID")
	private long pckRelRuleId;

	@Column(name="\"ACTION\"")
	private String action;

	@Column(name="ASG_ROLE_ID")
	private String asgRoleId;

	@Column(name="BASE_PRI_OFFSET")
	private BigDecimal basePriOffset;

	private BigDecimal baspri;

	@Column(name="DEFAULT_FLG")
	private BigDecimal defaultFlg;

	@Column(name="DST_MOV_ZONE_ID")
	private BigDecimal dstMovZoneId;

	@Column(name="GROUP_ARG")
	private String groupArg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private String oprcod;

	@Column(name="PCK_MTHD_ID")
	private BigDecimal pckMthdId;

	@Column(name="THRESH_FLG")
	private BigDecimal threshFlg;

	private String wrktyp;

	public PckRelRule() {
	}

	public long getPckRelRuleId() {
		return this.pckRelRuleId;
	}

	public void setPckRelRuleId(long pckRelRuleId) {
		this.pckRelRuleId = pckRelRuleId;
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getAsgRoleId() {
		return this.asgRoleId;
	}

	public void setAsgRoleId(String asgRoleId) {
		this.asgRoleId = asgRoleId;
	}

	public BigDecimal getBasePriOffset() {
		return this.basePriOffset;
	}

	public void setBasePriOffset(BigDecimal basePriOffset) {
		this.basePriOffset = basePriOffset;
	}

	public BigDecimal getBaspri() {
		return this.baspri;
	}

	public void setBaspri(BigDecimal baspri) {
		this.baspri = baspri;
	}

	public BigDecimal getDefaultFlg() {
		return this.defaultFlg;
	}

	public void setDefaultFlg(BigDecimal defaultFlg) {
		this.defaultFlg = defaultFlg;
	}

	public BigDecimal getDstMovZoneId() {
		return this.dstMovZoneId;
	}

	public void setDstMovZoneId(BigDecimal dstMovZoneId) {
		this.dstMovZoneId = dstMovZoneId;
	}

	public String getGroupArg() {
		return this.groupArg;
	}

	public void setGroupArg(String groupArg) {
		this.groupArg = groupArg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getOprcod() {
		return this.oprcod;
	}

	public void setOprcod(String oprcod) {
		this.oprcod = oprcod;
	}

	public BigDecimal getPckMthdId() {
		return this.pckMthdId;
	}

	public void setPckMthdId(BigDecimal pckMthdId) {
		this.pckMthdId = pckMthdId;
	}

	public BigDecimal getThreshFlg() {
		return this.threshFlg;
	}

	public void setThreshFlg(BigDecimal threshFlg) {
		this.threshFlg = threshFlg;
	}

	public String getWrktyp() {
		return this.wrktyp;
	}

	public void setWrktyp(String wrktyp) {
		this.wrktyp = wrktyp;
	}

}