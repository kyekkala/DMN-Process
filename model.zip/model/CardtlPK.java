package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the CARDTL database table.
 * 
 */
@Embeddable
public class CardtlPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String carcod;

	private String srvlvl;

	public CardtlPK() {
	}
	public String getCarcod() {
		return this.carcod;
	}
	public void setCarcod(String carcod) {
		this.carcod = carcod;
	}
	public String getSrvlvl() {
		return this.srvlvl;
	}
	public void setSrvlvl(String srvlvl) {
		this.srvlvl = srvlvl;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof CardtlPK)) {
			return false;
		}
		CardtlPK castOther = (CardtlPK)other;
		return 
			this.carcod.equals(castOther.carcod)
			&& this.srvlvl.equals(castOther.srvlvl);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.carcod.hashCode();
		hash = hash * prime + this.srvlvl.hashCode();
		
		return hash;
	}
}