package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PCK_ZONE_VER_FLG database table.
 * 
 */
@Entity
@Table(name="PCK_ZONE_VER_FLG")
@NamedQuery(name="PckZoneVerFlg.findAll", query="SELECT p FROM PckZoneVerFlg p")
public class PckZoneVerFlg implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PckZoneVerFlgPK id;

	@Column(name="ATTR_DTE1_FLG")
	private BigDecimal attrDte1Flg;

	@Column(name="ATTR_DTE2_FLG")
	private BigDecimal attrDte2Flg;

	@Column(name="ATTR_FLT1_FLG")
	private BigDecimal attrFlt1Flg;

	@Column(name="ATTR_FLT2_FLG")
	private BigDecimal attrFlt2Flg;

	@Column(name="ATTR_FLT3_FLG")
	private BigDecimal attrFlt3Flg;

	@Column(name="ATTR_INT1_FLG")
	private BigDecimal attrInt1Flg;

	@Column(name="ATTR_INT2_FLG")
	private BigDecimal attrInt2Flg;

	@Column(name="ATTR_INT3_FLG")
	private BigDecimal attrInt3Flg;

	@Column(name="ATTR_INT4_FLG")
	private BigDecimal attrInt4Flg;

	@Column(name="ATTR_INT5_FLG")
	private BigDecimal attrInt5Flg;

	@Column(name="ATTR_STR1_FLG")
	private BigDecimal attrStr1Flg;

	@Column(name="ATTR_STR10_FLG")
	private BigDecimal attrStr10Flg;

	@Column(name="ATTR_STR11_FLG")
	private BigDecimal attrStr11Flg;

	@Column(name="ATTR_STR12_FLG")
	private BigDecimal attrStr12Flg;

	@Column(name="ATTR_STR13_FLG")
	private BigDecimal attrStr13Flg;

	@Column(name="ATTR_STR14_FLG")
	private BigDecimal attrStr14Flg;

	@Column(name="ATTR_STR15_FLG")
	private BigDecimal attrStr15Flg;

	@Column(name="ATTR_STR16_FLG")
	private BigDecimal attrStr16Flg;

	@Column(name="ATTR_STR17_FLG")
	private BigDecimal attrStr17Flg;

	@Column(name="ATTR_STR18_FLG")
	private BigDecimal attrStr18Flg;

	@Column(name="ATTR_STR2_FLG")
	private BigDecimal attrStr2Flg;

	@Column(name="ATTR_STR3_FLG")
	private BigDecimal attrStr3Flg;

	@Column(name="ATTR_STR4_FLG")
	private BigDecimal attrStr4Flg;

	@Column(name="ATTR_STR5_FLG")
	private BigDecimal attrStr5Flg;

	@Column(name="ATTR_STR6_FLG")
	private BigDecimal attrStr6Flg;

	@Column(name="ATTR_STR7_FLG")
	private BigDecimal attrStr7Flg;

	@Column(name="ATTR_STR8_FLG")
	private BigDecimal attrStr8Flg;

	@Column(name="ATTR_STR9_FLG")
	private BigDecimal attrStr9Flg;

	@Column(name="CATCH_QTY_FLG")
	private BigDecimal catchQtyFlg;

	@Column(name="CSTMS_TYP_FLG")
	private BigDecimal cstmsTypFlg;

	private BigDecimal dtlflg;

	@Column(name="EXPDTE_FLG")
	private BigDecimal expdteFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private BigDecimal locflg;

	private BigDecimal lodflg;

	private BigDecimal lotflg;

	@Column(name="MANDTE_FLG")
	private BigDecimal mandteFlg;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private BigDecimal orgflg;

	private BigDecimal prtflg;

	private BigDecimal qtyflg;

	private BigDecimal revflg;

	@Column(name="RTTN_ID_FLG")
	private BigDecimal rttnIdFlg;

	private BigDecimal subflg;

	@Column(name="SUP_LOT_FLG")
	private BigDecimal supLotFlg;

	private BigDecimal supflg;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	public PckZoneVerFlg() {
	}

	public PckZoneVerFlgPK getId() {
		return this.id;
	}

	public void setId(PckZoneVerFlgPK id) {
		this.id = id;
	}

	public BigDecimal getAttrDte1Flg() {
		return this.attrDte1Flg;
	}

	public void setAttrDte1Flg(BigDecimal attrDte1Flg) {
		this.attrDte1Flg = attrDte1Flg;
	}

	public BigDecimal getAttrDte2Flg() {
		return this.attrDte2Flg;
	}

	public void setAttrDte2Flg(BigDecimal attrDte2Flg) {
		this.attrDte2Flg = attrDte2Flg;
	}

	public BigDecimal getAttrFlt1Flg() {
		return this.attrFlt1Flg;
	}

	public void setAttrFlt1Flg(BigDecimal attrFlt1Flg) {
		this.attrFlt1Flg = attrFlt1Flg;
	}

	public BigDecimal getAttrFlt2Flg() {
		return this.attrFlt2Flg;
	}

	public void setAttrFlt2Flg(BigDecimal attrFlt2Flg) {
		this.attrFlt2Flg = attrFlt2Flg;
	}

	public BigDecimal getAttrFlt3Flg() {
		return this.attrFlt3Flg;
	}

	public void setAttrFlt3Flg(BigDecimal attrFlt3Flg) {
		this.attrFlt3Flg = attrFlt3Flg;
	}

	public BigDecimal getAttrInt1Flg() {
		return this.attrInt1Flg;
	}

	public void setAttrInt1Flg(BigDecimal attrInt1Flg) {
		this.attrInt1Flg = attrInt1Flg;
	}

	public BigDecimal getAttrInt2Flg() {
		return this.attrInt2Flg;
	}

	public void setAttrInt2Flg(BigDecimal attrInt2Flg) {
		this.attrInt2Flg = attrInt2Flg;
	}

	public BigDecimal getAttrInt3Flg() {
		return this.attrInt3Flg;
	}

	public void setAttrInt3Flg(BigDecimal attrInt3Flg) {
		this.attrInt3Flg = attrInt3Flg;
	}

	public BigDecimal getAttrInt4Flg() {
		return this.attrInt4Flg;
	}

	public void setAttrInt4Flg(BigDecimal attrInt4Flg) {
		this.attrInt4Flg = attrInt4Flg;
	}

	public BigDecimal getAttrInt5Flg() {
		return this.attrInt5Flg;
	}

	public void setAttrInt5Flg(BigDecimal attrInt5Flg) {
		this.attrInt5Flg = attrInt5Flg;
	}

	public BigDecimal getAttrStr1Flg() {
		return this.attrStr1Flg;
	}

	public void setAttrStr1Flg(BigDecimal attrStr1Flg) {
		this.attrStr1Flg = attrStr1Flg;
	}

	public BigDecimal getAttrStr10Flg() {
		return this.attrStr10Flg;
	}

	public void setAttrStr10Flg(BigDecimal attrStr10Flg) {
		this.attrStr10Flg = attrStr10Flg;
	}

	public BigDecimal getAttrStr11Flg() {
		return this.attrStr11Flg;
	}

	public void setAttrStr11Flg(BigDecimal attrStr11Flg) {
		this.attrStr11Flg = attrStr11Flg;
	}

	public BigDecimal getAttrStr12Flg() {
		return this.attrStr12Flg;
	}

	public void setAttrStr12Flg(BigDecimal attrStr12Flg) {
		this.attrStr12Flg = attrStr12Flg;
	}

	public BigDecimal getAttrStr13Flg() {
		return this.attrStr13Flg;
	}

	public void setAttrStr13Flg(BigDecimal attrStr13Flg) {
		this.attrStr13Flg = attrStr13Flg;
	}

	public BigDecimal getAttrStr14Flg() {
		return this.attrStr14Flg;
	}

	public void setAttrStr14Flg(BigDecimal attrStr14Flg) {
		this.attrStr14Flg = attrStr14Flg;
	}

	public BigDecimal getAttrStr15Flg() {
		return this.attrStr15Flg;
	}

	public void setAttrStr15Flg(BigDecimal attrStr15Flg) {
		this.attrStr15Flg = attrStr15Flg;
	}

	public BigDecimal getAttrStr16Flg() {
		return this.attrStr16Flg;
	}

	public void setAttrStr16Flg(BigDecimal attrStr16Flg) {
		this.attrStr16Flg = attrStr16Flg;
	}

	public BigDecimal getAttrStr17Flg() {
		return this.attrStr17Flg;
	}

	public void setAttrStr17Flg(BigDecimal attrStr17Flg) {
		this.attrStr17Flg = attrStr17Flg;
	}

	public BigDecimal getAttrStr18Flg() {
		return this.attrStr18Flg;
	}

	public void setAttrStr18Flg(BigDecimal attrStr18Flg) {
		this.attrStr18Flg = attrStr18Flg;
	}

	public BigDecimal getAttrStr2Flg() {
		return this.attrStr2Flg;
	}

	public void setAttrStr2Flg(BigDecimal attrStr2Flg) {
		this.attrStr2Flg = attrStr2Flg;
	}

	public BigDecimal getAttrStr3Flg() {
		return this.attrStr3Flg;
	}

	public void setAttrStr3Flg(BigDecimal attrStr3Flg) {
		this.attrStr3Flg = attrStr3Flg;
	}

	public BigDecimal getAttrStr4Flg() {
		return this.attrStr4Flg;
	}

	public void setAttrStr4Flg(BigDecimal attrStr4Flg) {
		this.attrStr4Flg = attrStr4Flg;
	}

	public BigDecimal getAttrStr5Flg() {
		return this.attrStr5Flg;
	}

	public void setAttrStr5Flg(BigDecimal attrStr5Flg) {
		this.attrStr5Flg = attrStr5Flg;
	}

	public BigDecimal getAttrStr6Flg() {
		return this.attrStr6Flg;
	}

	public void setAttrStr6Flg(BigDecimal attrStr6Flg) {
		this.attrStr6Flg = attrStr6Flg;
	}

	public BigDecimal getAttrStr7Flg() {
		return this.attrStr7Flg;
	}

	public void setAttrStr7Flg(BigDecimal attrStr7Flg) {
		this.attrStr7Flg = attrStr7Flg;
	}

	public BigDecimal getAttrStr8Flg() {
		return this.attrStr8Flg;
	}

	public void setAttrStr8Flg(BigDecimal attrStr8Flg) {
		this.attrStr8Flg = attrStr8Flg;
	}

	public BigDecimal getAttrStr9Flg() {
		return this.attrStr9Flg;
	}

	public void setAttrStr9Flg(BigDecimal attrStr9Flg) {
		this.attrStr9Flg = attrStr9Flg;
	}

	public BigDecimal getCatchQtyFlg() {
		return this.catchQtyFlg;
	}

	public void setCatchQtyFlg(BigDecimal catchQtyFlg) {
		this.catchQtyFlg = catchQtyFlg;
	}

	public BigDecimal getCstmsTypFlg() {
		return this.cstmsTypFlg;
	}

	public void setCstmsTypFlg(BigDecimal cstmsTypFlg) {
		this.cstmsTypFlg = cstmsTypFlg;
	}

	public BigDecimal getDtlflg() {
		return this.dtlflg;
	}

	public void setDtlflg(BigDecimal dtlflg) {
		this.dtlflg = dtlflg;
	}

	public BigDecimal getExpdteFlg() {
		return this.expdteFlg;
	}

	public void setExpdteFlg(BigDecimal expdteFlg) {
		this.expdteFlg = expdteFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getLocflg() {
		return this.locflg;
	}

	public void setLocflg(BigDecimal locflg) {
		this.locflg = locflg;
	}

	public BigDecimal getLodflg() {
		return this.lodflg;
	}

	public void setLodflg(BigDecimal lodflg) {
		this.lodflg = lodflg;
	}

	public BigDecimal getLotflg() {
		return this.lotflg;
	}

	public void setLotflg(BigDecimal lotflg) {
		this.lotflg = lotflg;
	}

	public BigDecimal getMandteFlg() {
		return this.mandteFlg;
	}

	public void setMandteFlg(BigDecimal mandteFlg) {
		this.mandteFlg = mandteFlg;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getOrgflg() {
		return this.orgflg;
	}

	public void setOrgflg(BigDecimal orgflg) {
		this.orgflg = orgflg;
	}

	public BigDecimal getPrtflg() {
		return this.prtflg;
	}

	public void setPrtflg(BigDecimal prtflg) {
		this.prtflg = prtflg;
	}

	public BigDecimal getQtyflg() {
		return this.qtyflg;
	}

	public void setQtyflg(BigDecimal qtyflg) {
		this.qtyflg = qtyflg;
	}

	public BigDecimal getRevflg() {
		return this.revflg;
	}

	public void setRevflg(BigDecimal revflg) {
		this.revflg = revflg;
	}

	public BigDecimal getRttnIdFlg() {
		return this.rttnIdFlg;
	}

	public void setRttnIdFlg(BigDecimal rttnIdFlg) {
		this.rttnIdFlg = rttnIdFlg;
	}

	public BigDecimal getSubflg() {
		return this.subflg;
	}

	public void setSubflg(BigDecimal subflg) {
		this.subflg = subflg;
	}

	public BigDecimal getSupLotFlg() {
		return this.supLotFlg;
	}

	public void setSupLotFlg(BigDecimal supLotFlg) {
		this.supLotFlg = supLotFlg;
	}

	public BigDecimal getSupflg() {
		return this.supflg;
	}

	public void setSupflg(BigDecimal supflg) {
		this.supflg = supflg;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

}