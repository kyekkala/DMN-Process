package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CYCLE_ABC_CONFIG database table.
 * 
 */
@Entity
@Table(name="CYCLE_ABC_CONFIG")
@NamedQuery(name="CycleAbcConfig.findAll", query="SELECT c FROM CycleAbcConfig c")
public class CycleAbcConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	public CycleAbcConfig() {
	}

}