package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RES_FLTR_RULE database table.
 * 
 */
@Embeddable
public class ResFltrRulePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="RES_KEY")
	private String resKey;

	@Column(name="RES_VAL")
	private String resVal;

	@Column(name="ARG_KEY")
	private String argKey;

	@Column(name="ARG_VAL")
	private String argVal;

	public ResFltrRulePK() {
	}
	public String getResKey() {
		return this.resKey;
	}
	public void setResKey(String resKey) {
		this.resKey = resKey;
	}
	public String getResVal() {
		return this.resVal;
	}
	public void setResVal(String resVal) {
		this.resVal = resVal;
	}
	public String getArgKey() {
		return this.argKey;
	}
	public void setArgKey(String argKey) {
		this.argKey = argKey;
	}
	public String getArgVal() {
		return this.argVal;
	}
	public void setArgVal(String argVal) {
		this.argVal = argVal;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ResFltrRulePK)) {
			return false;
		}
		ResFltrRulePK castOther = (ResFltrRulePK)other;
		return 
			this.resKey.equals(castOther.resKey)
			&& this.resVal.equals(castOther.resVal)
			&& this.argKey.equals(castOther.argKey)
			&& this.argVal.equals(castOther.argVal);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.resKey.hashCode();
		hash = hash * prime + this.resVal.hashCode();
		hash = hash * prime + this.argKey.hashCode();
		hash = hash * prime + this.argVal.hashCode();
		
		return hash;
	}
}