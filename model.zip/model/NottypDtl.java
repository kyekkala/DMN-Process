package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the NOTTYP_DTL database table.
 * 
 */
@Entity
@Table(name="NOTTYP_DTL")
@NamedQuery(name="NottypDtl.findAll", query="SELECT n FROM NottypDtl n")
public class NottypDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private NottypDtlPK id;

	@Column(name="DSP_AUTO_FLG")
	private BigDecimal dspAutoFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	public NottypDtl() {
	}

	public NottypDtlPK getId() {
		return this.id;
	}

	public void setId(NottypDtlPK id) {
		this.id = id;
	}

	public BigDecimal getDspAutoFlg() {
		return this.dspAutoFlg;
	}

	public void setDspAutoFlg(BigDecimal dspAutoFlg) {
		this.dspAutoFlg = dspAutoFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

}