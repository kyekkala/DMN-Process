package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CRITERIA_MST database table.
 * 
 */
@Entity
@Table(name="CRITERIA_MST")
@NamedQuery(name="CriteriaMst.findAll", query="SELECT c FROM CriteriaMst c")
public class CriteriaMst implements Serializable {
	private static final long serialVersionUID = 1L;

	public CriteriaMst() {
	}

}