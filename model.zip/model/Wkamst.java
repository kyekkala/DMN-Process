package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the WKAMST database table.
 * 
 */
@Entity
@NamedQuery(name="Wkamst.findAll", query="SELECT w FROM Wkamst w")
public class Wkamst implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private WkamstPK id;

	@Column(name="DIST_THRESH")
	private BigDecimal distThresh;

	private BigDecimal hmemaxprithr;

	private BigDecimal maxprithr;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private BigDecimal prithr;

	@Column(name="VOC_COD")
	private BigDecimal vocCod;

	public Wkamst() {
	}

	public WkamstPK getId() {
		return this.id;
	}

	public void setId(WkamstPK id) {
		this.id = id;
	}

	public BigDecimal getDistThresh() {
		return this.distThresh;
	}

	public void setDistThresh(BigDecimal distThresh) {
		this.distThresh = distThresh;
	}

	public BigDecimal getHmemaxprithr() {
		return this.hmemaxprithr;
	}

	public void setHmemaxprithr(BigDecimal hmemaxprithr) {
		this.hmemaxprithr = hmemaxprithr;
	}

	public BigDecimal getMaxprithr() {
		return this.maxprithr;
	}

	public void setMaxprithr(BigDecimal maxprithr) {
		this.maxprithr = maxprithr;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getPrithr() {
		return this.prithr;
	}

	public void setPrithr(BigDecimal prithr) {
		this.prithr = prithr;
	}

	public BigDecimal getVocCod() {
		return this.vocCod;
	}

	public void setVocCod(BigDecimal vocCod) {
		this.vocCod = vocCod;
	}

}