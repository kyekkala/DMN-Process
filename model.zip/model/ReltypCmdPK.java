package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RELTYP_CMD database table.
 * 
 */
@Embeddable
public class ReltypCmdPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="WH_ID")
	private String whId;

	@Column(name="RELTYP_ID")
	private String reltypId;

	@Column(name="CNT_ZONE_ID")
	private long cntZoneId;

	public ReltypCmdPK() {
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getReltypId() {
		return this.reltypId;
	}
	public void setReltypId(String reltypId) {
		this.reltypId = reltypId;
	}
	public long getCntZoneId() {
		return this.cntZoneId;
	}
	public void setCntZoneId(long cntZoneId) {
		this.cntZoneId = cntZoneId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ReltypCmdPK)) {
			return false;
		}
		ReltypCmdPK castOther = (ReltypCmdPK)other;
		return 
			this.whId.equals(castOther.whId)
			&& this.reltypId.equals(castOther.reltypId)
			&& (this.cntZoneId == castOther.cntZoneId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.reltypId.hashCode();
		hash = hash * prime + ((int) (this.cntZoneId ^ (this.cntZoneId >>> 32)));
		
		return hash;
	}
}