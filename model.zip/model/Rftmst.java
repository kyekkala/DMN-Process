package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the RFTMST database table.
 * 
 */
@Entity
@NamedQuery(name="Rftmst.findAll", query="SELECT r FROM Rftmst r")
public class Rftmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RftmstPK id;

	@Temporal(TemporalType.DATE)
	private Date actdte;

	@Column(name="CUR_WRK_ZONE_ID")
	private BigDecimal curWrkZoneId;

	private String curstoloc;

	private String curwrkare;

	private String hmewrkare;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private String rftmod;

	private String vehtyp;

	public Rftmst() {
	}

	public RftmstPK getId() {
		return this.id;
	}

	public void setId(RftmstPK id) {
		this.id = id;
	}

	public Date getActdte() {
		return this.actdte;
	}

	public void setActdte(Date actdte) {
		this.actdte = actdte;
	}

	public BigDecimal getCurWrkZoneId() {
		return this.curWrkZoneId;
	}

	public void setCurWrkZoneId(BigDecimal curWrkZoneId) {
		this.curWrkZoneId = curWrkZoneId;
	}

	public String getCurstoloc() {
		return this.curstoloc;
	}

	public void setCurstoloc(String curstoloc) {
		this.curstoloc = curstoloc;
	}

	public String getCurwrkare() {
		return this.curwrkare;
	}

	public void setCurwrkare(String curwrkare) {
		this.curwrkare = curwrkare;
	}

	public String getHmewrkare() {
		return this.hmewrkare;
	}

	public void setHmewrkare(String hmewrkare) {
		this.hmewrkare = hmewrkare;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getRftmod() {
		return this.rftmod;
	}

	public void setRftmod(String rftmod) {
		this.rftmod = rftmod;
	}

	public String getVehtyp() {
		return this.vehtyp;
	}

	public void setVehtyp(String vehtyp) {
		this.vehtyp = vehtyp;
	}

}