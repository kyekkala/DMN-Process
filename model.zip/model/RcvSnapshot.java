package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the RCV_SNAPSHOT database table.
 * 
 */
@Entity
@Table(name="RCV_SNAPSHOT")
@NamedQuery(name="RcvSnapshot.findAll", query="SELECT r FROM RcvSnapshot r")
public class RcvSnapshot implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RcvSnapshotPK id;

	private BigDecimal expqty;

	private BigDecimal idnqty;

	private BigDecimal rcvqty;

	public RcvSnapshot() {
	}

	public RcvSnapshotPK getId() {
		return this.id;
	}

	public void setId(RcvSnapshotPK id) {
		this.id = id;
	}

	public BigDecimal getExpqty() {
		return this.expqty;
	}

	public void setExpqty(BigDecimal expqty) {
		this.expqty = expqty;
	}

	public BigDecimal getIdnqty() {
		return this.idnqty;
	}

	public void setIdnqty(BigDecimal idnqty) {
		this.idnqty = idnqty;
	}

	public BigDecimal getRcvqty() {
		return this.rcvqty;
	}

	public void setRcvqty(BigDecimal rcvqty) {
		this.rcvqty = rcvqty;
	}

}