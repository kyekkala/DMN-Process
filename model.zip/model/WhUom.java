package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the WH_UOM database table.
 * 
 */
@Entity
@Table(name="WH_UOM")
@NamedQuery(name="WhUom.findAll", query="SELECT w FROM WhUom w")
public class WhUom implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private WhUomPK id;

	@Column(name="DEFAULT_BULK_PICK_FLG")
	private BigDecimal defaultBulkPickFlg;

	@Column(name="DEFAULT_SHP_RELEASE_FLG")
	private BigDecimal defaultShpReleaseFlg;

	@Column(name="DEFAULT_WKO_RELEASE_FLG")
	private BigDecimal defaultWkoReleaseFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	public WhUom() {
	}

	public WhUomPK getId() {
		return this.id;
	}

	public void setId(WhUomPK id) {
		this.id = id;
	}

	public BigDecimal getDefaultBulkPickFlg() {
		return this.defaultBulkPickFlg;
	}

	public void setDefaultBulkPickFlg(BigDecimal defaultBulkPickFlg) {
		this.defaultBulkPickFlg = defaultBulkPickFlg;
	}

	public BigDecimal getDefaultShpReleaseFlg() {
		return this.defaultShpReleaseFlg;
	}

	public void setDefaultShpReleaseFlg(BigDecimal defaultShpReleaseFlg) {
		this.defaultShpReleaseFlg = defaultShpReleaseFlg;
	}

	public BigDecimal getDefaultWkoReleaseFlg() {
		return this.defaultWkoReleaseFlg;
	}

	public void setDefaultWkoReleaseFlg(BigDecimal defaultWkoReleaseFlg) {
		this.defaultWkoReleaseFlg = defaultWkoReleaseFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

}