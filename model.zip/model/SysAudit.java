package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SYS_AUDIT database table.
 * 
 */
@Entity
@Table(name="SYS_AUDIT")
@NamedQuery(name="SysAudit.findAll", query="SELECT s FROM SysAudit s")
public class SysAudit implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="APPL_ID")
	private String applId;

	@Column(name="AUD_TYP")
	private String audTyp;

	@Temporal(TemporalType.DATE)
	private Date auddte;

	@Column(name="EXEC_CMD")
	private String execCmd;

	@Column(name="EXEC_ROWS")
	private BigDecimal execRows;

	@Column(name="RET_STS")
	private BigDecimal retSts;

	private String tcpadr;

	@Column(name="USR_ID")
	private String usrId;

	public SysAudit() {
	}

	public String getApplId() {
		return this.applId;
	}

	public void setApplId(String applId) {
		this.applId = applId;
	}

	public String getAudTyp() {
		return this.audTyp;
	}

	public void setAudTyp(String audTyp) {
		this.audTyp = audTyp;
	}

	public Date getAuddte() {
		return this.auddte;
	}

	public void setAuddte(Date auddte) {
		this.auddte = auddte;
	}

	public String getExecCmd() {
		return this.execCmd;
	}

	public void setExecCmd(String execCmd) {
		this.execCmd = execCmd;
	}

	public BigDecimal getExecRows() {
		return this.execRows;
	}

	public void setExecRows(BigDecimal execRows) {
		this.execRows = execRows;
	}

	public BigDecimal getRetSts() {
		return this.retSts;
	}

	public void setRetSts(BigDecimal retSts) {
		this.retSts = retSts;
	}

	public String getTcpadr() {
		return this.tcpadr;
	}

	public void setTcpadr(String tcpadr) {
		this.tcpadr = tcpadr;
	}

	public String getUsrId() {
		return this.usrId;
	}

	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}

}