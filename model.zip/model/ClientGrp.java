package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CLIENT_GRP database table.
 * 
 */
@Entity
@Table(name="CLIENT_GRP")
@NamedQuery(name="ClientGrp.findAll", query="SELECT c FROM ClientGrp c")
public class ClientGrp implements Serializable {
	private static final long serialVersionUID = 1L;

	public ClientGrp() {
	}

}