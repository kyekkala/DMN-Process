package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the INVSTS_ROLE database table.
 * 
 */
@Entity
@Table(name="INVSTS_ROLE")
@NamedQuery(name="InvstsRole.findAll", query="SELECT i FROM InvstsRole i")
public class InvstsRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="INVSTS_ROLE_ID")
	private long invstsRoleId;

	@Column(name="FRM_INVSTS")
	private String frmInvsts;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="ROLE_ID")
	private String roleId;

	@Column(name="TO_INVSTS")
	private String toInvsts;

	public InvstsRole() {
	}

	public long getInvstsRoleId() {
		return this.invstsRoleId;
	}

	public void setInvstsRoleId(long invstsRoleId) {
		this.invstsRoleId = invstsRoleId;
	}

	public String getFrmInvsts() {
		return this.frmInvsts;
	}

	public void setFrmInvsts(String frmInvsts) {
		this.frmInvsts = frmInvsts;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getRoleId() {
		return this.roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getToInvsts() {
		return this.toInvsts;
	}

	public void setToInvsts(String toInvsts) {
		this.toInvsts = toInvsts;
	}

}