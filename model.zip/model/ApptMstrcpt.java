package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the APPT_MSTRCPT database table.
 * 
 */
@Entity
@Table(name="APPT_MSTRCPT")
@NamedQuery(name="ApptMstrcpt.findAll", query="SELECT a FROM ApptMstrcpt a")
public class ApptMstrcpt implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ApptMstrcptPK id;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	public ApptMstrcpt() {
	}

	public ApptMstrcptPK getId() {
		return this.id;
	}

	public void setId(ApptMstrcptPK id) {
		this.id = id;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

}