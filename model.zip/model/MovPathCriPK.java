package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the MOV_PATH_CRI database table.
 * 
 */
@Embeddable
public class MovPathCriPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="CRI_ID")
	private String criId;

	private long seqnum;

	@Column(name="WH_ID")
	private String whId;

	public MovPathCriPK() {
	}
	public String getCriId() {
		return this.criId;
	}
	public void setCriId(String criId) {
		this.criId = criId;
	}
	public long getSeqnum() {
		return this.seqnum;
	}
	public void setSeqnum(long seqnum) {
		this.seqnum = seqnum;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof MovPathCriPK)) {
			return false;
		}
		MovPathCriPK castOther = (MovPathCriPK)other;
		return 
			this.criId.equals(castOther.criId)
			&& (this.seqnum == castOther.seqnum)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.criId.hashCode();
		hash = hash * prime + ((int) (this.seqnum ^ (this.seqnum >>> 32)));
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}