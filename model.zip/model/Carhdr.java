package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CARHDR database table.
 * 
 */
@Entity
@NamedQuery(name="Carhdr.findAll", query="SELECT c FROM Carhdr c")
public class Carhdr implements Serializable {
	private static final long serialVersionUID = 1L;

	public Carhdr() {
	}

}