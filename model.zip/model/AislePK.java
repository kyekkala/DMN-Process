package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the AISLE database table.
 * 
 */
@Embeddable
public class AislePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="WH_ID")
	private String whId;

	@Column(name="AISLE_ID")
	private String aisleId;

	public AislePK() {
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getAisleId() {
		return this.aisleId;
	}
	public void setAisleId(String aisleId) {
		this.aisleId = aisleId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AislePK)) {
			return false;
		}
		AislePK castOther = (AislePK)other;
		return 
			this.whId.equals(castOther.whId)
			&& this.aisleId.equals(castOther.aisleId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.aisleId.hashCode();
		
		return hash;
	}
}