package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the RCVTRK database table.
 * 
 */
@Entity
@NamedQuery(name="Rcvtrk.findAll", query="SELECT r FROM Rcvtrk r")
public class Rcvtrk implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RcvtrkPK id;

	@Column(name="ARC_SRC")
	private String arcSrc;

	@Temporal(TemporalType.DATE)
	private Date arcdte;

	@Column(name="AUTOASNRCV_STAT")
	private String autoasnrcvStat;

	@Temporal(TemporalType.DATE)
	private Date clsdte;

	@Column(name="CRNCY_CODE")
	private String crncyCode;

	private String devcod;

	@Column(name="DOC_NUM")
	private String docNum;

	@Temporal(TemporalType.DATE)
	private Date expdte;

	private BigDecimal frtcst;

	private BigDecimal grswgt;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_RCPT_CONF_DTE")
	private Date lastRcptConfDte;

	private BigDecimal lblflg;

	@Column(name="LM_GOAL_SECONDS")
	private BigDecimal lmGoalSeconds;

	@Temporal(TemporalType.DATE)
	@Column(name="LMS_PLAN_DTE")
	private Date lmsPlanDte;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="MST_BOL")
	private String mstBol;

	private BigDecimal numcas;

	private BigDecimal numpal;

	@Column(name="RCVTRK_STAT")
	private String rcvtrkStat;

	@Column(name="REC_LOC")
	private String recLoc;

	@Temporal(TemporalType.DATE)
	private Date shpdte;

	@Column(name="SYS_GEN_FLG")
	private BigDecimal sysGenFlg;

	@Column(name="TMS_LOAD_ID")
	private String tmsLoadId;

	@Column(name="TMS_SOURCE_ID")
	private String tmsSourceId;

	@Column(name="TMS_STOP_SEQ")
	private BigDecimal tmsStopSeq;

	@Column(name="TRACK_NUM")
	private String trackNum;

	private String trkref;

	@Column(name="TRLR_ID")
	private String trlrId;

	private String trnspt;

	public Rcvtrk() {
	}

	public RcvtrkPK getId() {
		return this.id;
	}

	public void setId(RcvtrkPK id) {
		this.id = id;
	}

	public String getArcSrc() {
		return this.arcSrc;
	}

	public void setArcSrc(String arcSrc) {
		this.arcSrc = arcSrc;
	}

	public Date getArcdte() {
		return this.arcdte;
	}

	public void setArcdte(Date arcdte) {
		this.arcdte = arcdte;
	}

	public String getAutoasnrcvStat() {
		return this.autoasnrcvStat;
	}

	public void setAutoasnrcvStat(String autoasnrcvStat) {
		this.autoasnrcvStat = autoasnrcvStat;
	}

	public Date getClsdte() {
		return this.clsdte;
	}

	public void setClsdte(Date clsdte) {
		this.clsdte = clsdte;
	}

	public String getCrncyCode() {
		return this.crncyCode;
	}

	public void setCrncyCode(String crncyCode) {
		this.crncyCode = crncyCode;
	}

	public String getDevcod() {
		return this.devcod;
	}

	public void setDevcod(String devcod) {
		this.devcod = devcod;
	}

	public String getDocNum() {
		return this.docNum;
	}

	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	public Date getExpdte() {
		return this.expdte;
	}

	public void setExpdte(Date expdte) {
		this.expdte = expdte;
	}

	public BigDecimal getFrtcst() {
		return this.frtcst;
	}

	public void setFrtcst(BigDecimal frtcst) {
		this.frtcst = frtcst;
	}

	public BigDecimal getGrswgt() {
		return this.grswgt;
	}

	public void setGrswgt(BigDecimal grswgt) {
		this.grswgt = grswgt;
	}

	public Date getLastRcptConfDte() {
		return this.lastRcptConfDte;
	}

	public void setLastRcptConfDte(Date lastRcptConfDte) {
		this.lastRcptConfDte = lastRcptConfDte;
	}

	public BigDecimal getLblflg() {
		return this.lblflg;
	}

	public void setLblflg(BigDecimal lblflg) {
		this.lblflg = lblflg;
	}

	public BigDecimal getLmGoalSeconds() {
		return this.lmGoalSeconds;
	}

	public void setLmGoalSeconds(BigDecimal lmGoalSeconds) {
		this.lmGoalSeconds = lmGoalSeconds;
	}

	public Date getLmsPlanDte() {
		return this.lmsPlanDte;
	}

	public void setLmsPlanDte(Date lmsPlanDte) {
		this.lmsPlanDte = lmsPlanDte;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getMstBol() {
		return this.mstBol;
	}

	public void setMstBol(String mstBol) {
		this.mstBol = mstBol;
	}

	public BigDecimal getNumcas() {
		return this.numcas;
	}

	public void setNumcas(BigDecimal numcas) {
		this.numcas = numcas;
	}

	public BigDecimal getNumpal() {
		return this.numpal;
	}

	public void setNumpal(BigDecimal numpal) {
		this.numpal = numpal;
	}

	public String getRcvtrkStat() {
		return this.rcvtrkStat;
	}

	public void setRcvtrkStat(String rcvtrkStat) {
		this.rcvtrkStat = rcvtrkStat;
	}

	public String getRecLoc() {
		return this.recLoc;
	}

	public void setRecLoc(String recLoc) {
		this.recLoc = recLoc;
	}

	public Date getShpdte() {
		return this.shpdte;
	}

	public void setShpdte(Date shpdte) {
		this.shpdte = shpdte;
	}

	public BigDecimal getSysGenFlg() {
		return this.sysGenFlg;
	}

	public void setSysGenFlg(BigDecimal sysGenFlg) {
		this.sysGenFlg = sysGenFlg;
	}

	public String getTmsLoadId() {
		return this.tmsLoadId;
	}

	public void setTmsLoadId(String tmsLoadId) {
		this.tmsLoadId = tmsLoadId;
	}

	public String getTmsSourceId() {
		return this.tmsSourceId;
	}

	public void setTmsSourceId(String tmsSourceId) {
		this.tmsSourceId = tmsSourceId;
	}

	public BigDecimal getTmsStopSeq() {
		return this.tmsStopSeq;
	}

	public void setTmsStopSeq(BigDecimal tmsStopSeq) {
		this.tmsStopSeq = tmsStopSeq;
	}

	public String getTrackNum() {
		return this.trackNum;
	}

	public void setTrackNum(String trackNum) {
		this.trackNum = trackNum;
	}

	public String getTrkref() {
		return this.trkref;
	}

	public void setTrkref(String trkref) {
		this.trkref = trkref;
	}

	public String getTrlrId() {
		return this.trlrId;
	}

	public void setTrlrId(String trlrId) {
		this.trlrId = trlrId;
	}

	public String getTrnspt() {
		return this.trnspt;
	}

	public void setTrnspt(String trnspt) {
		this.trnspt = trnspt;
	}

}