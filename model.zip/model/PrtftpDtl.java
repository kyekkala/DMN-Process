package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PRTFTP_DTL database table.
 * 
 */
@Entity
@Table(name="PRTFTP_DTL")
@NamedQuery(name="PrtftpDtl.findAll", query="SELECT p FROM PrtftpDtl p")
public class PrtftpDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PrtftpDtlPK id;

	@Column(name="BULK_PCK_FLG")
	private BigDecimal bulkPckFlg;

	@Column(name="CAS_FLG")
	private BigDecimal casFlg;

	@Column(name="CTN_DSTR_FLG")
	private BigDecimal ctnDstrFlg;

	@Column(name="CTN_FLG")
	private BigDecimal ctnFlg;

	private BigDecimal grswgt;

	private BigDecimal hgt;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LAYER_FLG")
	private BigDecimal layerFlg;

	private BigDecimal len;

	private BigDecimal netwgt;

	@Column(name="PAK_FLG")
	private BigDecimal pakFlg;

	@Column(name="PAL_FLG")
	private BigDecimal palFlg;

	@Column(name="RCV_FLG")
	private BigDecimal rcvFlg;

	@Column(name="STK_FLG")
	private BigDecimal stkFlg;

	@Column(name="THRESH_PCT")
	private BigDecimal threshPct;

	private BigDecimal untqty;

	private BigDecimal uomlvl;

	private BigDecimal wid;

	public PrtftpDtl() {
	}

	public PrtftpDtlPK getId() {
		return this.id;
	}

	public void setId(PrtftpDtlPK id) {
		this.id = id;
	}

	public BigDecimal getBulkPckFlg() {
		return this.bulkPckFlg;
	}

	public void setBulkPckFlg(BigDecimal bulkPckFlg) {
		this.bulkPckFlg = bulkPckFlg;
	}

	public BigDecimal getCasFlg() {
		return this.casFlg;
	}

	public void setCasFlg(BigDecimal casFlg) {
		this.casFlg = casFlg;
	}

	public BigDecimal getCtnDstrFlg() {
		return this.ctnDstrFlg;
	}

	public void setCtnDstrFlg(BigDecimal ctnDstrFlg) {
		this.ctnDstrFlg = ctnDstrFlg;
	}

	public BigDecimal getCtnFlg() {
		return this.ctnFlg;
	}

	public void setCtnFlg(BigDecimal ctnFlg) {
		this.ctnFlg = ctnFlg;
	}

	public BigDecimal getGrswgt() {
		return this.grswgt;
	}

	public void setGrswgt(BigDecimal grswgt) {
		this.grswgt = grswgt;
	}

	public BigDecimal getHgt() {
		return this.hgt;
	}

	public void setHgt(BigDecimal hgt) {
		this.hgt = hgt;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getLayerFlg() {
		return this.layerFlg;
	}

	public void setLayerFlg(BigDecimal layerFlg) {
		this.layerFlg = layerFlg;
	}

	public BigDecimal getLen() {
		return this.len;
	}

	public void setLen(BigDecimal len) {
		this.len = len;
	}

	public BigDecimal getNetwgt() {
		return this.netwgt;
	}

	public void setNetwgt(BigDecimal netwgt) {
		this.netwgt = netwgt;
	}

	public BigDecimal getPakFlg() {
		return this.pakFlg;
	}

	public void setPakFlg(BigDecimal pakFlg) {
		this.pakFlg = pakFlg;
	}

	public BigDecimal getPalFlg() {
		return this.palFlg;
	}

	public void setPalFlg(BigDecimal palFlg) {
		this.palFlg = palFlg;
	}

	public BigDecimal getRcvFlg() {
		return this.rcvFlg;
	}

	public void setRcvFlg(BigDecimal rcvFlg) {
		this.rcvFlg = rcvFlg;
	}

	public BigDecimal getStkFlg() {
		return this.stkFlg;
	}

	public void setStkFlg(BigDecimal stkFlg) {
		this.stkFlg = stkFlg;
	}

	public BigDecimal getThreshPct() {
		return this.threshPct;
	}

	public void setThreshPct(BigDecimal threshPct) {
		this.threshPct = threshPct;
	}

	public BigDecimal getUntqty() {
		return this.untqty;
	}

	public void setUntqty(BigDecimal untqty) {
		this.untqty = untqty;
	}

	public BigDecimal getUomlvl() {
		return this.uomlvl;
	}

	public void setUomlvl(BigDecimal uomlvl) {
		this.uomlvl = uomlvl;
	}

	public BigDecimal getWid() {
		return this.wid;
	}

	public void setWid(BigDecimal wid) {
		this.wid = wid;
	}

}