package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the WRKQUE database table.
 * 
 */
@Entity
@NamedQuery(name="Wrkque.findAll", query="SELECT w FROM Wrkque w")
public class Wrkque implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long reqnum;

	@Column(name="ACK_USR_ID")
	private String ackUsrId;

	private String ackdevcod;

	@Temporal(TemporalType.DATE)
	private Date ackdte;

	@Temporal(TemporalType.DATE)
	private Date adddte;

	@Column(name="ASG_ROLE_ID")
	private String asgRoleId;

	@Column(name="ASG_USR_ID")
	private String asgUsrId;

	private BigDecimal baspri;

	private String batnum;

	@Column(name="CLIENT_ID")
	private String clientId;

	private String cntgrp;

	private String ctnnum;

	@Temporal(TemporalType.DATE)
	private Date depdte;

	private String dstloc;

	private BigDecimal effpri;

	@Temporal(TemporalType.DATE)
	private Date issdte;

	private String lblbat;

	@Column(name="LIST_ID")
	private String listId;

	private String locacc;

	private String loctrvseq;

	private String lodlvl;

	private String lodnum;

	@Temporal(TemporalType.DATE)
	private Date lstescdte;

	@Column(name="MAN_REL_SEQ")
	private BigDecimal manRelSeq;

	private String oprcod;

	@Temporal(TemporalType.DATE)
	private Date pckdte;

	private String refloc;

	@Column(name="RF_OUT_AUD_ID")
	private String rfOutAudId;

	private String schbat;

	@Temporal(TemporalType.DATE)
	@Column(name="SIGN_OFF_DATE")
	private Date signOffDate;

	@Column(name="SRC_AISLE_ID")
	private String srcAisleId;

	@Column(name="SRC_BLDG_ID")
	private String srcBldgId;

	@Column(name="SRC_WRK_ZONE_ID")
	private BigDecimal srcWrkZoneId;

	private String srcloc;

	private String srcwrkare;

	@Column(name="WH_ID")
	private String whId;

	private String wrkref;

	private String wrksts;

	private BigDecimal zontrvseq;

	public Wrkque() {
	}

	public long getReqnum() {
		return this.reqnum;
	}

	public void setReqnum(long reqnum) {
		this.reqnum = reqnum;
	}

	public String getAckUsrId() {
		return this.ackUsrId;
	}

	public void setAckUsrId(String ackUsrId) {
		this.ackUsrId = ackUsrId;
	}

	public String getAckdevcod() {
		return this.ackdevcod;
	}

	public void setAckdevcod(String ackdevcod) {
		this.ackdevcod = ackdevcod;
	}

	public Date getAckdte() {
		return this.ackdte;
	}

	public void setAckdte(Date ackdte) {
		this.ackdte = ackdte;
	}

	public Date getAdddte() {
		return this.adddte;
	}

	public void setAdddte(Date adddte) {
		this.adddte = adddte;
	}

	public String getAsgRoleId() {
		return this.asgRoleId;
	}

	public void setAsgRoleId(String asgRoleId) {
		this.asgRoleId = asgRoleId;
	}

	public String getAsgUsrId() {
		return this.asgUsrId;
	}

	public void setAsgUsrId(String asgUsrId) {
		this.asgUsrId = asgUsrId;
	}

	public BigDecimal getBaspri() {
		return this.baspri;
	}

	public void setBaspri(BigDecimal baspri) {
		this.baspri = baspri;
	}

	public String getBatnum() {
		return this.batnum;
	}

	public void setBatnum(String batnum) {
		this.batnum = batnum;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getCntgrp() {
		return this.cntgrp;
	}

	public void setCntgrp(String cntgrp) {
		this.cntgrp = cntgrp;
	}

	public String getCtnnum() {
		return this.ctnnum;
	}

	public void setCtnnum(String ctnnum) {
		this.ctnnum = ctnnum;
	}

	public Date getDepdte() {
		return this.depdte;
	}

	public void setDepdte(Date depdte) {
		this.depdte = depdte;
	}

	public String getDstloc() {
		return this.dstloc;
	}

	public void setDstloc(String dstloc) {
		this.dstloc = dstloc;
	}

	public BigDecimal getEffpri() {
		return this.effpri;
	}

	public void setEffpri(BigDecimal effpri) {
		this.effpri = effpri;
	}

	public Date getIssdte() {
		return this.issdte;
	}

	public void setIssdte(Date issdte) {
		this.issdte = issdte;
	}

	public String getLblbat() {
		return this.lblbat;
	}

	public void setLblbat(String lblbat) {
		this.lblbat = lblbat;
	}

	public String getListId() {
		return this.listId;
	}

	public void setListId(String listId) {
		this.listId = listId;
	}

	public String getLocacc() {
		return this.locacc;
	}

	public void setLocacc(String locacc) {
		this.locacc = locacc;
	}

	public String getLoctrvseq() {
		return this.loctrvseq;
	}

	public void setLoctrvseq(String loctrvseq) {
		this.loctrvseq = loctrvseq;
	}

	public String getLodlvl() {
		return this.lodlvl;
	}

	public void setLodlvl(String lodlvl) {
		this.lodlvl = lodlvl;
	}

	public String getLodnum() {
		return this.lodnum;
	}

	public void setLodnum(String lodnum) {
		this.lodnum = lodnum;
	}

	public Date getLstescdte() {
		return this.lstescdte;
	}

	public void setLstescdte(Date lstescdte) {
		this.lstescdte = lstescdte;
	}

	public BigDecimal getManRelSeq() {
		return this.manRelSeq;
	}

	public void setManRelSeq(BigDecimal manRelSeq) {
		this.manRelSeq = manRelSeq;
	}

	public String getOprcod() {
		return this.oprcod;
	}

	public void setOprcod(String oprcod) {
		this.oprcod = oprcod;
	}

	public Date getPckdte() {
		return this.pckdte;
	}

	public void setPckdte(Date pckdte) {
		this.pckdte = pckdte;
	}

	public String getRefloc() {
		return this.refloc;
	}

	public void setRefloc(String refloc) {
		this.refloc = refloc;
	}

	public String getRfOutAudId() {
		return this.rfOutAudId;
	}

	public void setRfOutAudId(String rfOutAudId) {
		this.rfOutAudId = rfOutAudId;
	}

	public String getSchbat() {
		return this.schbat;
	}

	public void setSchbat(String schbat) {
		this.schbat = schbat;
	}

	public Date getSignOffDate() {
		return this.signOffDate;
	}

	public void setSignOffDate(Date signOffDate) {
		this.signOffDate = signOffDate;
	}

	public String getSrcAisleId() {
		return this.srcAisleId;
	}

	public void setSrcAisleId(String srcAisleId) {
		this.srcAisleId = srcAisleId;
	}

	public String getSrcBldgId() {
		return this.srcBldgId;
	}

	public void setSrcBldgId(String srcBldgId) {
		this.srcBldgId = srcBldgId;
	}

	public BigDecimal getSrcWrkZoneId() {
		return this.srcWrkZoneId;
	}

	public void setSrcWrkZoneId(BigDecimal srcWrkZoneId) {
		this.srcWrkZoneId = srcWrkZoneId;
	}

	public String getSrcloc() {
		return this.srcloc;
	}

	public void setSrcloc(String srcloc) {
		this.srcloc = srcloc;
	}

	public String getSrcwrkare() {
		return this.srcwrkare;
	}

	public void setSrcwrkare(String srcwrkare) {
		this.srcwrkare = srcwrkare;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

	public String getWrkref() {
		return this.wrkref;
	}

	public void setWrkref(String wrkref) {
		this.wrkref = wrkref;
	}

	public String getWrksts() {
		return this.wrksts;
	}

	public void setWrksts(String wrksts) {
		this.wrksts = wrksts;
	}

	public BigDecimal getZontrvseq() {
		return this.zontrvseq;
	}

	public void setZontrvseq(BigDecimal zontrvseq) {
		this.zontrvseq = zontrvseq;
	}

}