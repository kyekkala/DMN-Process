package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the LES_USR_PREF database table.
 * 
 */
@Entity
@Table(name="LES_USR_PREF")
@NamedQuery(name="LesUsrPref.findAll", query="SELECT l FROM LesUsrPref l")
public class LesUsrPref implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private LesUsrPrefPK id;

	@Column(name="GRP_NAM")
	private String grpNam;

	@Column(name="PREF_VAL")
	private String prefVal;

	public LesUsrPref() {
	}

	public LesUsrPrefPK getId() {
		return this.id;
	}

	public void setId(LesUsrPrefPK id) {
		this.id = id;
	}

	public String getGrpNam() {
		return this.grpNam;
	}

	public void setGrpNam(String grpNam) {
		this.grpNam = grpNam;
	}

	public String getPrefVal() {
		return this.prefVal;
	}

	public void setPrefVal(String prefVal) {
		this.prefVal = prefVal;
	}

}