package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CYCLE_PROMPT_CONFIG database table.
 * 
 */
@Entity
@Table(name="CYCLE_PROMPT_CONFIG")
@NamedQuery(name="CyclePromptConfig.findAll", query="SELECT c FROM CyclePromptConfig c")
public class CyclePromptConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	public CyclePromptConfig() {
	}

}