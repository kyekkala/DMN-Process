package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the INVTYPMST database table.
 * 
 */
@Entity
@NamedQuery(name="Invtypmst.findAll", query="SELECT i FROM Invtypmst i")
public class Invtypmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String invtyp;

	@Column(name="BILL_ANVSTG_FLG")
	private BigDecimal billAnvstgFlg;

	private BigDecimal delvflg;

	@Column(name="GS1_INVTYP")
	private String gs1Invtyp;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private BigDecimal retflg;

	@Column(name="STD_PUT_FLG")
	private BigDecimal stdPutFlg;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	@Column(name="WM_DEFAULT_FLG")
	private BigDecimal wmDefaultFlg;

	public Invtypmst() {
	}

	public String getInvtyp() {
		return this.invtyp;
	}

	public void setInvtyp(String invtyp) {
		this.invtyp = invtyp;
	}

	public BigDecimal getBillAnvstgFlg() {
		return this.billAnvstgFlg;
	}

	public void setBillAnvstgFlg(BigDecimal billAnvstgFlg) {
		this.billAnvstgFlg = billAnvstgFlg;
	}

	public BigDecimal getDelvflg() {
		return this.delvflg;
	}

	public void setDelvflg(BigDecimal delvflg) {
		this.delvflg = delvflg;
	}

	public String getGs1Invtyp() {
		return this.gs1Invtyp;
	}

	public void setGs1Invtyp(String gs1Invtyp) {
		this.gs1Invtyp = gs1Invtyp;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getRetflg() {
		return this.retflg;
	}

	public void setRetflg(BigDecimal retflg) {
		this.retflg = retflg;
	}

	public BigDecimal getStdPutFlg() {
		return this.stdPutFlg;
	}

	public void setStdPutFlg(BigDecimal stdPutFlg) {
		this.stdPutFlg = stdPutFlg;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

	public BigDecimal getWmDefaultFlg() {
		return this.wmDefaultFlg;
	}

	public void setWmDefaultFlg(BigDecimal wmDefaultFlg) {
		this.wmDefaultFlg = wmDefaultFlg;
	}

}