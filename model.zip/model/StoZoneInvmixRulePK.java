package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the STO_ZONE_INVMIX_RULE database table.
 * 
 */
@Embeddable
public class StoZoneInvmixRulePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="STO_ZONE_ID")
	private long stoZoneId;

	private String tblnme;

	@Column(name="COLUMN_NAME")
	private String columnName;

	public StoZoneInvmixRulePK() {
	}
	public long getStoZoneId() {
		return this.stoZoneId;
	}
	public void setStoZoneId(long stoZoneId) {
		this.stoZoneId = stoZoneId;
	}
	public String getTblnme() {
		return this.tblnme;
	}
	public void setTblnme(String tblnme) {
		this.tblnme = tblnme;
	}
	public String getColumnName() {
		return this.columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof StoZoneInvmixRulePK)) {
			return false;
		}
		StoZoneInvmixRulePK castOther = (StoZoneInvmixRulePK)other;
		return 
			(this.stoZoneId == castOther.stoZoneId)
			&& this.tblnme.equals(castOther.tblnme)
			&& this.columnName.equals(castOther.columnName);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.stoZoneId ^ (this.stoZoneId >>> 32)));
		hash = hash * prime + this.tblnme.hashCode();
		hash = hash * prime + this.columnName.hashCode();
		
		return hash;
	}
}