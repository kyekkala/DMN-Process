package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the WH_SERV_INVSTS database table.
 * 
 */
@Entity
@Table(name="WH_SERV_INVSTS")
@NamedQuery(name="WhServInvst.findAll", query="SELECT w FROM WhServInvst w")
public class WhServInvst implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private WhServInvstPK id;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	public WhServInvst() {
	}

	public WhServInvstPK getId() {
		return this.id;
	}

	public void setId(WhServInvstPK id) {
		this.id = id;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

}