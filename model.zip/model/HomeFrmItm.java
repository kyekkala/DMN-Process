package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the HOME_FRM_ITM database table.
 * 
 */
@Entity
@Table(name="HOME_FRM_ITM")
@NamedQuery(name="HomeFrmItm.findAll", query="SELECT h FROM HomeFrmItm h")
public class HomeFrmItm implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private HomeFrmItmPK id;

	@Column(name="COL_POS")
	private BigDecimal colPos;

	@Column(name="ENA_FLG")
	private BigDecimal enaFlg;

	@Column(name="EXEC_PARM")
	private String execParm;

	@Column(name="GRP_NAM")
	private String grpNam;

	@Column(name="IMG_ID")
	private String imgId;

	@Column(name="OPT_NAM")
	private String optNam;

	@Column(name="ROW_POS")
	private BigDecimal rowPos;

	@Column(name="STARTUP_MODE")
	private BigDecimal startupMode;

	@Column(name="TEXT_POS")
	private BigDecimal textPos;

	@Column(name="TTIP_MLS_ID")
	private String ttipMlsId;

	public HomeFrmItm() {
	}

	public HomeFrmItmPK getId() {
		return this.id;
	}

	public void setId(HomeFrmItmPK id) {
		this.id = id;
	}

	public BigDecimal getColPos() {
		return this.colPos;
	}

	public void setColPos(BigDecimal colPos) {
		this.colPos = colPos;
	}

	public BigDecimal getEnaFlg() {
		return this.enaFlg;
	}

	public void setEnaFlg(BigDecimal enaFlg) {
		this.enaFlg = enaFlg;
	}

	public String getExecParm() {
		return this.execParm;
	}

	public void setExecParm(String execParm) {
		this.execParm = execParm;
	}

	public String getGrpNam() {
		return this.grpNam;
	}

	public void setGrpNam(String grpNam) {
		this.grpNam = grpNam;
	}

	public String getImgId() {
		return this.imgId;
	}

	public void setImgId(String imgId) {
		this.imgId = imgId;
	}

	public String getOptNam() {
		return this.optNam;
	}

	public void setOptNam(String optNam) {
		this.optNam = optNam;
	}

	public BigDecimal getRowPos() {
		return this.rowPos;
	}

	public void setRowPos(BigDecimal rowPos) {
		this.rowPos = rowPos;
	}

	public BigDecimal getStartupMode() {
		return this.startupMode;
	}

	public void setStartupMode(BigDecimal startupMode) {
		this.startupMode = startupMode;
	}

	public BigDecimal getTextPos() {
		return this.textPos;
	}

	public void setTextPos(BigDecimal textPos) {
		this.textPos = textPos;
	}

	public String getTtipMlsId() {
		return this.ttipMlsId;
	}

	public void setTtipMlsId(String ttipMlsId) {
		this.ttipMlsId = ttipMlsId;
	}

}