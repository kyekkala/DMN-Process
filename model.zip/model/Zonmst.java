package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the ZONMST database table.
 * 
 */
@Entity
@NamedQuery(name="Zonmst.findAll", query="SELECT z FROM Zonmst z")
public class Zonmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="WRK_ZONE_ID")
	private long wrkZoneId;

	@Column(name="BLDG_ID")
	private String bldgId;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private BigDecimal maxdev;

	private BigDecimal maxprithr;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private BigDecimal oosflg;

	@Column(name="PCK_EXP_ARE")
	private String pckExpAre;

	private BigDecimal prithr;

	private BigDecimal trvseq;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	@Column(name="WH_ID")
	private String whId;

	private String wrkare;

	private String wrkzon;

	public Zonmst() {
	}

	public long getWrkZoneId() {
		return this.wrkZoneId;
	}

	public void setWrkZoneId(long wrkZoneId) {
		this.wrkZoneId = wrkZoneId;
	}

	public String getBldgId() {
		return this.bldgId;
	}

	public void setBldgId(String bldgId) {
		this.bldgId = bldgId;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getMaxdev() {
		return this.maxdev;
	}

	public void setMaxdev(BigDecimal maxdev) {
		this.maxdev = maxdev;
	}

	public BigDecimal getMaxprithr() {
		return this.maxprithr;
	}

	public void setMaxprithr(BigDecimal maxprithr) {
		this.maxprithr = maxprithr;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getOosflg() {
		return this.oosflg;
	}

	public void setOosflg(BigDecimal oosflg) {
		this.oosflg = oosflg;
	}

	public String getPckExpAre() {
		return this.pckExpAre;
	}

	public void setPckExpAre(String pckExpAre) {
		this.pckExpAre = pckExpAre;
	}

	public BigDecimal getPrithr() {
		return this.prithr;
	}

	public void setPrithr(BigDecimal prithr) {
		this.prithr = prithr;
	}

	public BigDecimal getTrvseq() {
		return this.trvseq;
	}

	public void setTrvseq(BigDecimal trvseq) {
		this.trvseq = trvseq;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

	public String getWrkare() {
		return this.wrkare;
	}

	public void setWrkare(String wrkare) {
		this.wrkare = wrkare;
	}

	public String getWrkzon() {
		return this.wrkzon;
	}

	public void setWrkzon(String wrkzon) {
		this.wrkzon = wrkzon;
	}

}