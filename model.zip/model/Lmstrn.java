package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LMSTRN database table.
 * 
 */
@Entity
@NamedQuery(name="Lmstrn.findAll", query="SELECT l FROM Lmstrn l")
public class Lmstrn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LMS_TRN_ID")
	private String lmsTrnId;

	private String actcod;

	private String adrnum;

	@Column(name="ASSIGN_FLG")
	private BigDecimal assignFlg;

	@Temporal(TemporalType.DATE)
	private Date begdte;

	private BigDecimal casqty;

	private String cstnum;

	private String devcod;

	@Column(name="DISC_PROC_ID")
	private String discProcId;

	private String dstare;

	private String dstloc;

	private String dstlod;

	private String dstsub;

	private String dtlnum;

	@Temporal(TemporalType.DATE)
	private Date enddte;

	private String eqptyp;

	private BigDecimal grpseq;

	private BigDecimal hldflg;

	private BigDecimal inpqty;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private BigDecimal layqty;

	private String lmsasn;

	private String lmscod;

	private String lmstyp;

	private String lmswrk;

	private String lodnum;

	private BigDecimal lstflg;

	private String oprcod;

	private BigDecimal palqty;

	@Temporal(TemporalType.DATE)
	private Date plndte;

	@Column(name="PROC_REPETITION")
	private BigDecimal procRepetition;

	@Column(name="PRT_CLIENT_ID")
	private String prtClientId;

	private String prtdsc;

	private String prtnum;

	private BigDecimal reqnum;

	@Temporal(TemporalType.DATE)
	@Column(name="SENT_DTE")
	private Date sentDte;

	private String srcare;

	private String srcloc;

	private String subnum;

	private String supnum;

	@Column(name="TRLR_NUM")
	private String trlrNum;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	private BigDecimal untqty;

	private BigDecimal untvol;

	private BigDecimal untwgt;

	@Column(name="USER_DEF_1")
	private String userDef1;

	@Column(name="USER_DEF_2")
	private String userDef2;

	@Column(name="USER_DEF_3")
	private String userDef3;

	@Column(name="USER_DEF_4")
	private String userDef4;

	@Column(name="USER_DEF_5")
	private String userDef5;

	@Column(name="USR_ID")
	private String usrId;

	@Column(name="WH_ID")
	private String whId;

	public Lmstrn() {
	}

	public String getLmsTrnId() {
		return this.lmsTrnId;
	}

	public void setLmsTrnId(String lmsTrnId) {
		this.lmsTrnId = lmsTrnId;
	}

	public String getActcod() {
		return this.actcod;
	}

	public void setActcod(String actcod) {
		this.actcod = actcod;
	}

	public String getAdrnum() {
		return this.adrnum;
	}

	public void setAdrnum(String adrnum) {
		this.adrnum = adrnum;
	}

	public BigDecimal getAssignFlg() {
		return this.assignFlg;
	}

	public void setAssignFlg(BigDecimal assignFlg) {
		this.assignFlg = assignFlg;
	}

	public Date getBegdte() {
		return this.begdte;
	}

	public void setBegdte(Date begdte) {
		this.begdte = begdte;
	}

	public BigDecimal getCasqty() {
		return this.casqty;
	}

	public void setCasqty(BigDecimal casqty) {
		this.casqty = casqty;
	}

	public String getCstnum() {
		return this.cstnum;
	}

	public void setCstnum(String cstnum) {
		this.cstnum = cstnum;
	}

	public String getDevcod() {
		return this.devcod;
	}

	public void setDevcod(String devcod) {
		this.devcod = devcod;
	}

	public String getDiscProcId() {
		return this.discProcId;
	}

	public void setDiscProcId(String discProcId) {
		this.discProcId = discProcId;
	}

	public String getDstare() {
		return this.dstare;
	}

	public void setDstare(String dstare) {
		this.dstare = dstare;
	}

	public String getDstloc() {
		return this.dstloc;
	}

	public void setDstloc(String dstloc) {
		this.dstloc = dstloc;
	}

	public String getDstlod() {
		return this.dstlod;
	}

	public void setDstlod(String dstlod) {
		this.dstlod = dstlod;
	}

	public String getDstsub() {
		return this.dstsub;
	}

	public void setDstsub(String dstsub) {
		this.dstsub = dstsub;
	}

	public String getDtlnum() {
		return this.dtlnum;
	}

	public void setDtlnum(String dtlnum) {
		this.dtlnum = dtlnum;
	}

	public Date getEnddte() {
		return this.enddte;
	}

	public void setEnddte(Date enddte) {
		this.enddte = enddte;
	}

	public String getEqptyp() {
		return this.eqptyp;
	}

	public void setEqptyp(String eqptyp) {
		this.eqptyp = eqptyp;
	}

	public BigDecimal getGrpseq() {
		return this.grpseq;
	}

	public void setGrpseq(BigDecimal grpseq) {
		this.grpseq = grpseq;
	}

	public BigDecimal getHldflg() {
		return this.hldflg;
	}

	public void setHldflg(BigDecimal hldflg) {
		this.hldflg = hldflg;
	}

	public BigDecimal getInpqty() {
		return this.inpqty;
	}

	public void setInpqty(BigDecimal inpqty) {
		this.inpqty = inpqty;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getLayqty() {
		return this.layqty;
	}

	public void setLayqty(BigDecimal layqty) {
		this.layqty = layqty;
	}

	public String getLmsasn() {
		return this.lmsasn;
	}

	public void setLmsasn(String lmsasn) {
		this.lmsasn = lmsasn;
	}

	public String getLmscod() {
		return this.lmscod;
	}

	public void setLmscod(String lmscod) {
		this.lmscod = lmscod;
	}

	public String getLmstyp() {
		return this.lmstyp;
	}

	public void setLmstyp(String lmstyp) {
		this.lmstyp = lmstyp;
	}

	public String getLmswrk() {
		return this.lmswrk;
	}

	public void setLmswrk(String lmswrk) {
		this.lmswrk = lmswrk;
	}

	public String getLodnum() {
		return this.lodnum;
	}

	public void setLodnum(String lodnum) {
		this.lodnum = lodnum;
	}

	public BigDecimal getLstflg() {
		return this.lstflg;
	}

	public void setLstflg(BigDecimal lstflg) {
		this.lstflg = lstflg;
	}

	public String getOprcod() {
		return this.oprcod;
	}

	public void setOprcod(String oprcod) {
		this.oprcod = oprcod;
	}

	public BigDecimal getPalqty() {
		return this.palqty;
	}

	public void setPalqty(BigDecimal palqty) {
		this.palqty = palqty;
	}

	public Date getPlndte() {
		return this.plndte;
	}

	public void setPlndte(Date plndte) {
		this.plndte = plndte;
	}

	public BigDecimal getProcRepetition() {
		return this.procRepetition;
	}

	public void setProcRepetition(BigDecimal procRepetition) {
		this.procRepetition = procRepetition;
	}

	public String getPrtClientId() {
		return this.prtClientId;
	}

	public void setPrtClientId(String prtClientId) {
		this.prtClientId = prtClientId;
	}

	public String getPrtdsc() {
		return this.prtdsc;
	}

	public void setPrtdsc(String prtdsc) {
		this.prtdsc = prtdsc;
	}

	public String getPrtnum() {
		return this.prtnum;
	}

	public void setPrtnum(String prtnum) {
		this.prtnum = prtnum;
	}

	public BigDecimal getReqnum() {
		return this.reqnum;
	}

	public void setReqnum(BigDecimal reqnum) {
		this.reqnum = reqnum;
	}

	public Date getSentDte() {
		return this.sentDte;
	}

	public void setSentDte(Date sentDte) {
		this.sentDte = sentDte;
	}

	public String getSrcare() {
		return this.srcare;
	}

	public void setSrcare(String srcare) {
		this.srcare = srcare;
	}

	public String getSrcloc() {
		return this.srcloc;
	}

	public void setSrcloc(String srcloc) {
		this.srcloc = srcloc;
	}

	public String getSubnum() {
		return this.subnum;
	}

	public void setSubnum(String subnum) {
		this.subnum = subnum;
	}

	public String getSupnum() {
		return this.supnum;
	}

	public void setSupnum(String supnum) {
		this.supnum = supnum;
	}

	public String getTrlrNum() {
		return this.trlrNum;
	}

	public void setTrlrNum(String trlrNum) {
		this.trlrNum = trlrNum;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

	public BigDecimal getUntqty() {
		return this.untqty;
	}

	public void setUntqty(BigDecimal untqty) {
		this.untqty = untqty;
	}

	public BigDecimal getUntvol() {
		return this.untvol;
	}

	public void setUntvol(BigDecimal untvol) {
		this.untvol = untvol;
	}

	public BigDecimal getUntwgt() {
		return this.untwgt;
	}

	public void setUntwgt(BigDecimal untwgt) {
		this.untwgt = untwgt;
	}

	public String getUserDef1() {
		return this.userDef1;
	}

	public void setUserDef1(String userDef1) {
		this.userDef1 = userDef1;
	}

	public String getUserDef2() {
		return this.userDef2;
	}

	public void setUserDef2(String userDef2) {
		this.userDef2 = userDef2;
	}

	public String getUserDef3() {
		return this.userDef3;
	}

	public void setUserDef3(String userDef3) {
		this.userDef3 = userDef3;
	}

	public String getUserDef4() {
		return this.userDef4;
	}

	public void setUserDef4(String userDef4) {
		this.userDef4 = userDef4;
	}

	public String getUserDef5() {
		return this.userDef5;
	}

	public void setUserDef5(String userDef5) {
		this.userDef5 = userDef5;
	}

	public String getUsrId() {
		return this.usrId;
	}

	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}