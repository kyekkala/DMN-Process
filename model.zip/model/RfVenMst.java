package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the RF_VEN_MST database table.
 * 
 */
@Entity
@Table(name="RF_VEN_MST")
@NamedQuery(name="RfVenMst.findAll", query="SELECT r FROM RfVenMst r")
public class RfVenMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="RF_VEN_NAM")
	private String rfVenNam;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="RF_VEN_INQ")
	private String rfVenInq;

	@Column(name="RF_VEN_RESP")
	private String rfVenResp;

	@Column(name="RF_VEN_RESP_TIME")
	private BigDecimal rfVenRespTime;

	public RfVenMst() {
	}

	public String getRfVenNam() {
		return this.rfVenNam;
	}

	public void setRfVenNam(String rfVenNam) {
		this.rfVenNam = rfVenNam;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getRfVenInq() {
		return this.rfVenInq;
	}

	public void setRfVenInq(String rfVenInq) {
		this.rfVenInq = rfVenInq;
	}

	public String getRfVenResp() {
		return this.rfVenResp;
	}

	public void setRfVenResp(String rfVenResp) {
		this.rfVenResp = rfVenResp;
	}

	public BigDecimal getRfVenRespTime() {
		return this.rfVenRespTime;
	}

	public void setRfVenRespTime(BigDecimal rfVenRespTime) {
		this.rfVenRespTime = rfVenRespTime;
	}

}