package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PRTMST_WH database table.
 * 
 */
@Embeddable
public class PrtmstWhPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String prtnum;

	@Column(name="WH_ID")
	private String whId;

	@Column(name="PRT_CLIENT_ID")
	private String prtClientId;

	public PrtmstWhPK() {
	}
	public String getPrtnum() {
		return this.prtnum;
	}
	public void setPrtnum(String prtnum) {
		this.prtnum = prtnum;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getPrtClientId() {
		return this.prtClientId;
	}
	public void setPrtClientId(String prtClientId) {
		this.prtClientId = prtClientId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PrtmstWhPK)) {
			return false;
		}
		PrtmstWhPK castOther = (PrtmstWhPK)other;
		return 
			this.prtnum.equals(castOther.prtnum)
			&& this.whId.equals(castOther.whId)
			&& this.prtClientId.equals(castOther.prtClientId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.prtnum.hashCode();
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.prtClientId.hashCode();
		
		return hash;
	}
}