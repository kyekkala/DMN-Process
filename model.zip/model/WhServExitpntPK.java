package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the WH_SERV_EXITPNT database table.
 * 
 */
@Embeddable
public class WhServExitpntPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SERV_ID")
	private String servId;

	@Column(name="WH_ID")
	private String whId;

	@Column(name="EXITPNT_TYP")
	private String exitpntTyp;

	private String exitpnt;

	public WhServExitpntPK() {
	}
	public String getServId() {
		return this.servId;
	}
	public void setServId(String servId) {
		this.servId = servId;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getExitpntTyp() {
		return this.exitpntTyp;
	}
	public void setExitpntTyp(String exitpntTyp) {
		this.exitpntTyp = exitpntTyp;
	}
	public String getExitpnt() {
		return this.exitpnt;
	}
	public void setExitpnt(String exitpnt) {
		this.exitpnt = exitpnt;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof WhServExitpntPK)) {
			return false;
		}
		WhServExitpntPK castOther = (WhServExitpntPK)other;
		return 
			this.servId.equals(castOther.servId)
			&& this.whId.equals(castOther.whId)
			&& this.exitpntTyp.equals(castOther.exitpntTyp)
			&& this.exitpnt.equals(castOther.exitpnt);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.servId.hashCode();
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.exitpntTyp.hashCode();
		hash = hash * prime + this.exitpnt.hashCode();
		
		return hash;
	}
}