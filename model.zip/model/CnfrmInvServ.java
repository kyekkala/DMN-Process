package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CNFRM_INV_SERV database table.
 * 
 */
@Entity
@Table(name="CNFRM_INV_SERV")
@NamedQuery(name="CnfrmInvServ.findAll", query="SELECT c FROM CnfrmInvServ c")
public class CnfrmInvServ implements Serializable {
	private static final long serialVersionUID = 1L;

	public CnfrmInvServ() {
	}

}