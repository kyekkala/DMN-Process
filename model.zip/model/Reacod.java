package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the REACOD database table.
 * 
 */
@Entity
@NamedQuery(name="Reacod.findAll", query="SELECT r FROM Reacod r")
public class Reacod implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String reacod;

	@Column(name="CSTMS_ORDTYP")
	private String cstmsOrdtyp;

	@Column(name="CSTMS_RCPT_TYP")
	private String cstmsRcptTyp;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	public Reacod() {
	}

	public String getReacod() {
		return this.reacod;
	}

	public void setReacod(String reacod) {
		this.reacod = reacod;
	}

	public String getCstmsOrdtyp() {
		return this.cstmsOrdtyp;
	}

	public void setCstmsOrdtyp(String cstmsOrdtyp) {
		this.cstmsOrdtyp = cstmsOrdtyp;
	}

	public String getCstmsRcptTyp() {
		return this.cstmsRcptTyp;
	}

	public void setCstmsRcptTyp(String cstmsRcptTyp) {
		this.cstmsRcptTyp = cstmsRcptTyp;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

}