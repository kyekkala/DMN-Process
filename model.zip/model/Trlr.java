package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TRLR database table.
 * 
 */
@Entity
@NamedQuery(name="Trlr.findAll", query="SELECT t FROM Trlr t")
public class Trlr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TRLR_ID")
	private String trlrId;

	@Column(name="APPT_ID")
	private String apptId;

	@Temporal(TemporalType.DATE)
	private Date arrdte;

	@Column(name="AUTOGEN_FLG")
	private BigDecimal autogenFlg;

	private String carcod;

	@Column(name="CLIENT_ID")
	private String clientId;

	@Temporal(TemporalType.DATE)
	@Column(name="CLOSE_DTE")
	private Date closeDte;

	@Column(name="DELV_FLG")
	private BigDecimal delvFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="DISPATCH_DTE")
	private Date dispatchDte;

	@Column(name="DRIVER_LIC_NUM")
	private String driverLicNum;

	@Column(name="DRIVER_NAM")
	private String driverNam;

	@Column(name="FRONT_AXLE_POS")
	private BigDecimal frontAxlePos;

	@Column(name="HOT_FLG")
	private BigDecimal hotFlg;

	@Column(name="LIVE_LOAD_FLG")
	private BigDecimal liveLoadFlg;

	@Column(name="MAX_TRLR_AXLE_POS")
	private BigDecimal maxTrlrAxlePos;

	@Column(name="MIN_TRLR_AXLE_POS")
	private BigDecimal minTrlrAxlePos;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="ORIG_TRLR_NUM")
	private String origTrlrNum;

	@Column(name="PAL_SLOT_FLG")
	private BigDecimal palSlotFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="PEND_DTE")
	private Date pendDte;

	@Column(name="POWERUNIT_ID")
	private String powerunitId;

	@Column(name="REFRIG_FLG")
	private BigDecimal refrigFlg;

	@Column(name="SAFE_CHECK_ID")
	private String safeCheckId;

	@Column(name="SAFE_STS")
	private String safeSts;

	@Column(name="SEC_TRLR_NUM")
	private String secTrlrNum;

	private String stoloc;

	@Column(name="STOLOC_WH_ID")
	private String stolocWhId;

	@Column(name="TRACTOR_NUM")
	private String tractorNum;

	@Column(name="TRLR_BROKER")
	private String trlrBroker;

	@Column(name="TRLR_COD")
	private String trlrCod;

	@Column(name="TRLR_COND")
	private String trlrCond;

	@Column(name="TRLR_NUM")
	private String trlrNum;

	@Column(name="TRLR_REF")
	private String trlrRef;

	@Column(name="TRLR_SEAL1")
	private String trlrSeal1;

	@Column(name="TRLR_SEAL2")
	private String trlrSeal2;

	@Column(name="TRLR_SEAL3")
	private String trlrSeal3;

	@Column(name="TRLR_SEAL4")
	private String trlrSeal4;

	@Column(name="TRLR_SIZE")
	private BigDecimal trlrSize;

	@Column(name="TRLR_STAT")
	private String trlrStat;

	@Column(name="TRLR_TYP")
	private String trlrTyp;

	@Column(name="TRLR_WGT")
	private BigDecimal trlrWgt;

	@Column(name="TURN_FLG")
	private BigDecimal turnFlg;

	@Column(name="YARD_LOC")
	private String yardLoc;

	@Column(name="YARD_LOC_WH_ID")
	private String yardLocWhId;

	@Column(name="YARD_STAT")
	private String yardStat;

	public Trlr() {
	}

	public String getTrlrId() {
		return this.trlrId;
	}

	public void setTrlrId(String trlrId) {
		this.trlrId = trlrId;
	}

	public String getApptId() {
		return this.apptId;
	}

	public void setApptId(String apptId) {
		this.apptId = apptId;
	}

	public Date getArrdte() {
		return this.arrdte;
	}

	public void setArrdte(Date arrdte) {
		this.arrdte = arrdte;
	}

	public BigDecimal getAutogenFlg() {
		return this.autogenFlg;
	}

	public void setAutogenFlg(BigDecimal autogenFlg) {
		this.autogenFlg = autogenFlg;
	}

	public String getCarcod() {
		return this.carcod;
	}

	public void setCarcod(String carcod) {
		this.carcod = carcod;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public Date getCloseDte() {
		return this.closeDte;
	}

	public void setCloseDte(Date closeDte) {
		this.closeDte = closeDte;
	}

	public BigDecimal getDelvFlg() {
		return this.delvFlg;
	}

	public void setDelvFlg(BigDecimal delvFlg) {
		this.delvFlg = delvFlg;
	}

	public Date getDispatchDte() {
		return this.dispatchDte;
	}

	public void setDispatchDte(Date dispatchDte) {
		this.dispatchDte = dispatchDte;
	}

	public String getDriverLicNum() {
		return this.driverLicNum;
	}

	public void setDriverLicNum(String driverLicNum) {
		this.driverLicNum = driverLicNum;
	}

	public String getDriverNam() {
		return this.driverNam;
	}

	public void setDriverNam(String driverNam) {
		this.driverNam = driverNam;
	}

	public BigDecimal getFrontAxlePos() {
		return this.frontAxlePos;
	}

	public void setFrontAxlePos(BigDecimal frontAxlePos) {
		this.frontAxlePos = frontAxlePos;
	}

	public BigDecimal getHotFlg() {
		return this.hotFlg;
	}

	public void setHotFlg(BigDecimal hotFlg) {
		this.hotFlg = hotFlg;
	}

	public BigDecimal getLiveLoadFlg() {
		return this.liveLoadFlg;
	}

	public void setLiveLoadFlg(BigDecimal liveLoadFlg) {
		this.liveLoadFlg = liveLoadFlg;
	}

	public BigDecimal getMaxTrlrAxlePos() {
		return this.maxTrlrAxlePos;
	}

	public void setMaxTrlrAxlePos(BigDecimal maxTrlrAxlePos) {
		this.maxTrlrAxlePos = maxTrlrAxlePos;
	}

	public BigDecimal getMinTrlrAxlePos() {
		return this.minTrlrAxlePos;
	}

	public void setMinTrlrAxlePos(BigDecimal minTrlrAxlePos) {
		this.minTrlrAxlePos = minTrlrAxlePos;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getOrigTrlrNum() {
		return this.origTrlrNum;
	}

	public void setOrigTrlrNum(String origTrlrNum) {
		this.origTrlrNum = origTrlrNum;
	}

	public BigDecimal getPalSlotFlg() {
		return this.palSlotFlg;
	}

	public void setPalSlotFlg(BigDecimal palSlotFlg) {
		this.palSlotFlg = palSlotFlg;
	}

	public Date getPendDte() {
		return this.pendDte;
	}

	public void setPendDte(Date pendDte) {
		this.pendDte = pendDte;
	}

	public String getPowerunitId() {
		return this.powerunitId;
	}

	public void setPowerunitId(String powerunitId) {
		this.powerunitId = powerunitId;
	}

	public BigDecimal getRefrigFlg() {
		return this.refrigFlg;
	}

	public void setRefrigFlg(BigDecimal refrigFlg) {
		this.refrigFlg = refrigFlg;
	}

	public String getSafeCheckId() {
		return this.safeCheckId;
	}

	public void setSafeCheckId(String safeCheckId) {
		this.safeCheckId = safeCheckId;
	}

	public String getSafeSts() {
		return this.safeSts;
	}

	public void setSafeSts(String safeSts) {
		this.safeSts = safeSts;
	}

	public String getSecTrlrNum() {
		return this.secTrlrNum;
	}

	public void setSecTrlrNum(String secTrlrNum) {
		this.secTrlrNum = secTrlrNum;
	}

	public String getStoloc() {
		return this.stoloc;
	}

	public void setStoloc(String stoloc) {
		this.stoloc = stoloc;
	}

	public String getStolocWhId() {
		return this.stolocWhId;
	}

	public void setStolocWhId(String stolocWhId) {
		this.stolocWhId = stolocWhId;
	}

	public String getTractorNum() {
		return this.tractorNum;
	}

	public void setTractorNum(String tractorNum) {
		this.tractorNum = tractorNum;
	}

	public String getTrlrBroker() {
		return this.trlrBroker;
	}

	public void setTrlrBroker(String trlrBroker) {
		this.trlrBroker = trlrBroker;
	}

	public String getTrlrCod() {
		return this.trlrCod;
	}

	public void setTrlrCod(String trlrCod) {
		this.trlrCod = trlrCod;
	}

	public String getTrlrCond() {
		return this.trlrCond;
	}

	public void setTrlrCond(String trlrCond) {
		this.trlrCond = trlrCond;
	}

	public String getTrlrNum() {
		return this.trlrNum;
	}

	public void setTrlrNum(String trlrNum) {
		this.trlrNum = trlrNum;
	}

	public String getTrlrRef() {
		return this.trlrRef;
	}

	public void setTrlrRef(String trlrRef) {
		this.trlrRef = trlrRef;
	}

	public String getTrlrSeal1() {
		return this.trlrSeal1;
	}

	public void setTrlrSeal1(String trlrSeal1) {
		this.trlrSeal1 = trlrSeal1;
	}

	public String getTrlrSeal2() {
		return this.trlrSeal2;
	}

	public void setTrlrSeal2(String trlrSeal2) {
		this.trlrSeal2 = trlrSeal2;
	}

	public String getTrlrSeal3() {
		return this.trlrSeal3;
	}

	public void setTrlrSeal3(String trlrSeal3) {
		this.trlrSeal3 = trlrSeal3;
	}

	public String getTrlrSeal4() {
		return this.trlrSeal4;
	}

	public void setTrlrSeal4(String trlrSeal4) {
		this.trlrSeal4 = trlrSeal4;
	}

	public BigDecimal getTrlrSize() {
		return this.trlrSize;
	}

	public void setTrlrSize(BigDecimal trlrSize) {
		this.trlrSize = trlrSize;
	}

	public String getTrlrStat() {
		return this.trlrStat;
	}

	public void setTrlrStat(String trlrStat) {
		this.trlrStat = trlrStat;
	}

	public String getTrlrTyp() {
		return this.trlrTyp;
	}

	public void setTrlrTyp(String trlrTyp) {
		this.trlrTyp = trlrTyp;
	}

	public BigDecimal getTrlrWgt() {
		return this.trlrWgt;
	}

	public void setTrlrWgt(BigDecimal trlrWgt) {
		this.trlrWgt = trlrWgt;
	}

	public BigDecimal getTurnFlg() {
		return this.turnFlg;
	}

	public void setTurnFlg(BigDecimal turnFlg) {
		this.turnFlg = turnFlg;
	}

	public String getYardLoc() {
		return this.yardLoc;
	}

	public void setYardLoc(String yardLoc) {
		this.yardLoc = yardLoc;
	}

	public String getYardLocWhId() {
		return this.yardLocWhId;
	}

	public void setYardLocWhId(String yardLocWhId) {
		this.yardLocWhId = yardLocWhId;
	}

	public String getYardStat() {
		return this.yardStat;
	}

	public void setYardStat(String yardStat) {
		this.yardStat = yardStat;
	}

}