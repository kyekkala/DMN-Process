package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the AISLE_DCKLOC database table.
 * 
 */
@Embeddable
public class AisleDcklocPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="AISLE_DCKLOC_ID")
	private long aisleDcklocId;

	@Column(name="WH_ID")
	private String whId;

	public AisleDcklocPK() {
	}
	public long getAisleDcklocId() {
		return this.aisleDcklocId;
	}
	public void setAisleDcklocId(long aisleDcklocId) {
		this.aisleDcklocId = aisleDcklocId;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AisleDcklocPK)) {
			return false;
		}
		AisleDcklocPK castOther = (AisleDcklocPK)other;
		return 
			(this.aisleDcklocId == castOther.aisleDcklocId)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.aisleDcklocId ^ (this.aisleDcklocId >>> 32)));
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}