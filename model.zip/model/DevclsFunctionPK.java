package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the DEVCLS_FUNCTION database table.
 * 
 */
@Embeddable
public class DevclsFunctionPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String devcls;

	@Column(name="DEV_FUNCTION")
	private long devFunction;

	public DevclsFunctionPK() {
	}
	public String getDevcls() {
		return this.devcls;
	}
	public void setDevcls(String devcls) {
		this.devcls = devcls;
	}
	public long getDevFunction() {
		return this.devFunction;
	}
	public void setDevFunction(long devFunction) {
		this.devFunction = devFunction;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof DevclsFunctionPK)) {
			return false;
		}
		DevclsFunctionPK castOther = (DevclsFunctionPK)other;
		return 
			this.devcls.equals(castOther.devcls)
			&& (this.devFunction == castOther.devFunction);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.devcls.hashCode();
		hash = hash * prime + ((int) (this.devFunction ^ (this.devFunction >>> 32)));
		
		return hash;
	}
}