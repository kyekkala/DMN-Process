package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the VOC_REGION_DTL database table.
 * 
 */
@Embeddable
public class VocRegionDtlPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="REGION_NUM")
	private long regionNum;

	@Column(name="VOC_VALID_FUNCTION")
	private long vocValidFunction;

	@Column(name="WH_ID")
	private String whId;

	private String varnam;

	public VocRegionDtlPK() {
	}
	public long getRegionNum() {
		return this.regionNum;
	}
	public void setRegionNum(long regionNum) {
		this.regionNum = regionNum;
	}
	public long getVocValidFunction() {
		return this.vocValidFunction;
	}
	public void setVocValidFunction(long vocValidFunction) {
		this.vocValidFunction = vocValidFunction;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getVarnam() {
		return this.varnam;
	}
	public void setVarnam(String varnam) {
		this.varnam = varnam;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof VocRegionDtlPK)) {
			return false;
		}
		VocRegionDtlPK castOther = (VocRegionDtlPK)other;
		return 
			(this.regionNum == castOther.regionNum)
			&& (this.vocValidFunction == castOther.vocValidFunction)
			&& this.whId.equals(castOther.whId)
			&& this.varnam.equals(castOther.varnam);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.regionNum ^ (this.regionNum >>> 32)));
		hash = hash * prime + ((int) (this.vocValidFunction ^ (this.vocValidFunction >>> 32)));
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.varnam.hashCode();
		
		return hash;
	}
}