package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the LES_USR_PREF database table.
 * 
 */
@Embeddable
public class LesUsrPrefPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="USR_ID")
	private String usrId;

	@Column(name="PREF_ID")
	private String prefId;

	public LesUsrPrefPK() {
	}
	public String getUsrId() {
		return this.usrId;
	}
	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}
	public String getPrefId() {
		return this.prefId;
	}
	public void setPrefId(String prefId) {
		this.prefId = prefId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof LesUsrPrefPK)) {
			return false;
		}
		LesUsrPrefPK castOther = (LesUsrPrefPK)other;
		return 
			this.usrId.equals(castOther.usrId)
			&& this.prefId.equals(castOther.prefId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.usrId.hashCode();
		hash = hash * prime + this.prefId.hashCode();
		
		return hash;
	}
}