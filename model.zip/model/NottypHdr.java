package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the NOTTYP_HDR database table.
 * 
 */
@Entity
@Table(name="NOTTYP_HDR")
@NamedQuery(name="NottypHdr.findAll", query="SELECT n FROM NottypHdr n")
public class NottypHdr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String nottyp;

	@Column(name="BILL_PRINT_FLG")
	private BigDecimal billPrintFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="PACK_PRINT_FLG")
	private BigDecimal packPrintFlg;

	public NottypHdr() {
	}

	public String getNottyp() {
		return this.nottyp;
	}

	public void setNottyp(String nottyp) {
		this.nottyp = nottyp;
	}

	public BigDecimal getBillPrintFlg() {
		return this.billPrintFlg;
	}

	public void setBillPrintFlg(BigDecimal billPrintFlg) {
		this.billPrintFlg = billPrintFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getPackPrintFlg() {
		return this.packPrintFlg;
	}

	public void setPackPrintFlg(BigDecimal packPrintFlg) {
		this.packPrintFlg = packPrintFlg;
	}

}