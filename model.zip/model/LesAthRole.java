package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the LES_ATH_ROLE database table.
 * 
 */
@Entity
@Table(name="LES_ATH_ROLE")
@NamedQuery(name="LesAthRole.findAll", query="SELECT l FROM LesAthRole l")
public class LesAthRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ROLE_ID")
	private String roleId;

	@Column(name="ADJ_THR_CST")
	private BigDecimal adjThrCst;

	@Column(name="ADJ_THR_UNIT")
	private BigDecimal adjThrUnit;

	@Column(name="ATH_GRP_NAM")
	private String athGrpNam;

	@Column(name="ENA_FLG")
	private BigDecimal enaFlg;

	@Column(name="GRP_NAM")
	private String grpNam;

	@Column(name="PAR_ROLE_ID")
	private String parRoleId;

	public LesAthRole() {
	}

	public String getRoleId() {
		return this.roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public BigDecimal getAdjThrCst() {
		return this.adjThrCst;
	}

	public void setAdjThrCst(BigDecimal adjThrCst) {
		this.adjThrCst = adjThrCst;
	}

	public BigDecimal getAdjThrUnit() {
		return this.adjThrUnit;
	}

	public void setAdjThrUnit(BigDecimal adjThrUnit) {
		this.adjThrUnit = adjThrUnit;
	}

	public String getAthGrpNam() {
		return this.athGrpNam;
	}

	public void setAthGrpNam(String athGrpNam) {
		this.athGrpNam = athGrpNam;
	}

	public BigDecimal getEnaFlg() {
		return this.enaFlg;
	}

	public void setEnaFlg(BigDecimal enaFlg) {
		this.enaFlg = enaFlg;
	}

	public String getGrpNam() {
		return this.grpNam;
	}

	public void setGrpNam(String grpNam) {
		this.grpNam = grpNam;
	}

	public String getParRoleId() {
		return this.parRoleId;
	}

	public void setParRoleId(String parRoleId) {
		this.parRoleId = parRoleId;
	}

}