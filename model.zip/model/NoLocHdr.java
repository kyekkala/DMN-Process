package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the NO_LOC_HDR database table.
 * 
 */
@Entity
@Table(name="NO_LOC_HDR")
@NamedQuery(name="NoLocHdr.findAll", query="SELECT n FROM NoLocHdr n")
public class NoLocHdr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="NO_LOC_HDR_ID")
	private String noLocHdrId;

	@Column(name="ALLOC_STATS_ID")
	private String allocStatsId;

	@Column(name="ASGN_LOC_FLG")
	private BigDecimal asgnLocFlg;

	@Column(name="DEF_FTP_FLG")
	private BigDecimal defFtpFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Column(name="KEEP_ZONE_FLG")
	private BigDecimal keepZoneFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private String lodnum;

	public NoLocHdr() {
	}

	public String getNoLocHdrId() {
		return this.noLocHdrId;
	}

	public void setNoLocHdrId(String noLocHdrId) {
		this.noLocHdrId = noLocHdrId;
	}

	public String getAllocStatsId() {
		return this.allocStatsId;
	}

	public void setAllocStatsId(String allocStatsId) {
		this.allocStatsId = allocStatsId;
	}

	public BigDecimal getAsgnLocFlg() {
		return this.asgnLocFlg;
	}

	public void setAsgnLocFlg(BigDecimal asgnLocFlg) {
		this.asgnLocFlg = asgnLocFlg;
	}

	public BigDecimal getDefFtpFlg() {
		return this.defFtpFlg;
	}

	public void setDefFtpFlg(BigDecimal defFtpFlg) {
		this.defFtpFlg = defFtpFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public BigDecimal getKeepZoneFlg() {
		return this.keepZoneFlg;
	}

	public void setKeepZoneFlg(BigDecimal keepZoneFlg) {
		this.keepZoneFlg = keepZoneFlg;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getLodnum() {
		return this.lodnum;
	}

	public void setLodnum(String lodnum) {
		this.lodnum = lodnum;
	}

}