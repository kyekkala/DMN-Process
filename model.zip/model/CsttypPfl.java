package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CSTTYP_PFL database table.
 * 
 */
@Entity
@Table(name="CSTTYP_PFL")
@NamedQuery(name="CsttypPfl.findAll", query="SELECT c FROM CsttypPfl c")
public class CsttypPfl implements Serializable {
	private static final long serialVersionUID = 1L;

	public CsttypPfl() {
	}

}