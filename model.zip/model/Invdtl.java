package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the INVDTL database table.
 * 
 */
@Entity
@NamedQuery(name="Invdtl.findAll", query="SELECT i FROM Invdtl i")
public class Invdtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String dtlnum;

	@Temporal(TemporalType.DATE)
	private Date adddte;

	@Column(name="AGE_PFLNAM")
	private String agePflnam;

	private BigDecimal alcflg;

	private BigDecimal asnflg;

	@Temporal(TemporalType.DATE)
	@Column(name="BILL_THROUGH_DTE")
	private Date billThroughDte;

	@Column(name="CATCH_QTY")
	private BigDecimal catchQty;

	private String cmpkey;

	@Column(name="CNSG_FLG")
	private BigDecimal cnsgFlg;

	private String condcod;

	@Column(name="CSTMS_BOND_FLG")
	private BigDecimal cstmsBondFlg;

	@Column(name="CSTMS_CMMDTY_COD")
	private String cstmsCmmdtyCod;

	@Column(name="CSTMS_CNSGNMNT_ID")
	private String cstmsCnsgnmntId;

	@Column(name="CSTMS_CRNCY")
	private String cstmsCrncy;

	@Column(name="CSTMS_CST")
	private BigDecimal cstmsCst;

	@Column(name="CSTMS_TYP")
	private String cstmsTyp;

	@Column(name="CSTMS_VAT_COD")
	private String cstmsVatCod;

	@Column(name="DFLT_ORGCOD")
	private String dfltOrgcod;

	@Column(name="DISTRO_FLG")
	private BigDecimal distroFlg;

	@Column(name="DISTRO_ID")
	private String distroId;

	@Column(name="DTY_STMP_FLG")
	private BigDecimal dtyStmpFlg;

	@Column(name="DTY_STMP_TRK_FLG")
	private BigDecimal dtyStmpTrkFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="EXPIRE_DTE")
	private Date expireDte;

	@Temporal(TemporalType.DATE)
	private Date fifdte;

	private String ftpcod;

	@Column(name="HLD_FLG")
	private BigDecimal hldFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="INV_ATTR_DTE1")
	private Date invAttrDte1;

	@Temporal(TemporalType.DATE)
	@Column(name="INV_ATTR_DTE2")
	private Date invAttrDte2;

	@Column(name="INV_ATTR_FLT1")
	private BigDecimal invAttrFlt1;

	@Column(name="INV_ATTR_FLT2")
	private BigDecimal invAttrFlt2;

	@Column(name="INV_ATTR_FLT3")
	private BigDecimal invAttrFlt3;

	@Column(name="INV_ATTR_INT1")
	private BigDecimal invAttrInt1;

	@Column(name="INV_ATTR_INT2")
	private BigDecimal invAttrInt2;

	@Column(name="INV_ATTR_INT3")
	private BigDecimal invAttrInt3;

	@Column(name="INV_ATTR_INT4")
	private BigDecimal invAttrInt4;

	@Column(name="INV_ATTR_INT5")
	private BigDecimal invAttrInt5;

	@Column(name="INV_ATTR_STR1")
	private String invAttrStr1;

	@Column(name="INV_ATTR_STR10")
	private String invAttrStr10;

	@Column(name="INV_ATTR_STR11")
	private String invAttrStr11;

	@Column(name="INV_ATTR_STR12")
	private String invAttrStr12;

	@Column(name="INV_ATTR_STR13")
	private String invAttrStr13;

	@Column(name="INV_ATTR_STR14")
	private String invAttrStr14;

	@Column(name="INV_ATTR_STR15")
	private String invAttrStr15;

	@Column(name="INV_ATTR_STR16")
	private String invAttrStr16;

	@Column(name="INV_ATTR_STR17")
	private String invAttrStr17;

	@Column(name="INV_ATTR_STR18")
	private String invAttrStr18;

	@Column(name="INV_ATTR_STR2")
	private String invAttrStr2;

	@Column(name="INV_ATTR_STR3")
	private String invAttrStr3;

	@Column(name="INV_ATTR_STR4")
	private String invAttrStr4;

	@Column(name="INV_ATTR_STR5")
	private String invAttrStr5;

	@Column(name="INV_ATTR_STR6")
	private String invAttrStr6;

	@Column(name="INV_ATTR_STR7")
	private String invAttrStr7;

	@Column(name="INV_ATTR_STR8")
	private String invAttrStr8;

	@Column(name="INV_ATTR_STR9")
	private String invAttrStr9;

	private String invsts;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private String lotnum;

	@Column(name="LST_MOV_ZONE_ID")
	private BigDecimal lstMovZoneId;

	@Column(name="LST_USR_ID")
	private String lstUsrId;

	private String lstcod;

	@Temporal(TemporalType.DATE)
	private Date lstdte;

	@Temporal(TemporalType.DATE)
	private Date lstmov;

	@Temporal(TemporalType.DATE)
	private Date mandte;

	private String orgcod;

	private BigDecimal phdflg;

	@Column(name="PRT_CLIENT_ID")
	private String prtClientId;

	private String prtnum;

	@Temporal(TemporalType.DATE)
	private Date rcvdte;

	private String rcvkey;

	private String revlvl;

	@Column(name="RTTN_ID")
	private String rttnId;

	@Column(name="SHIP_LINE_ID")
	private String shipLineId;

	private String subnum;

	@Column(name="SUP_LOTNUM")
	private String supLotnum;

	private String supnum;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	private BigDecimal untcas;

	private BigDecimal untpak;

	private BigDecimal untqty;

	private String wrkref;

	@Column(name="WRKREF_DTL")
	private String wrkrefDtl;

	public Invdtl() {
	}

	public String getDtlnum() {
		return this.dtlnum;
	}

	public void setDtlnum(String dtlnum) {
		this.dtlnum = dtlnum;
	}

	public Date getAdddte() {
		return this.adddte;
	}

	public void setAdddte(Date adddte) {
		this.adddte = adddte;
	}

	public String getAgePflnam() {
		return this.agePflnam;
	}

	public void setAgePflnam(String agePflnam) {
		this.agePflnam = agePflnam;
	}

	public BigDecimal getAlcflg() {
		return this.alcflg;
	}

	public void setAlcflg(BigDecimal alcflg) {
		this.alcflg = alcflg;
	}

	public BigDecimal getAsnflg() {
		return this.asnflg;
	}

	public void setAsnflg(BigDecimal asnflg) {
		this.asnflg = asnflg;
	}

	public Date getBillThroughDte() {
		return this.billThroughDte;
	}

	public void setBillThroughDte(Date billThroughDte) {
		this.billThroughDte = billThroughDte;
	}

	public BigDecimal getCatchQty() {
		return this.catchQty;
	}

	public void setCatchQty(BigDecimal catchQty) {
		this.catchQty = catchQty;
	}

	public String getCmpkey() {
		return this.cmpkey;
	}

	public void setCmpkey(String cmpkey) {
		this.cmpkey = cmpkey;
	}

	public BigDecimal getCnsgFlg() {
		return this.cnsgFlg;
	}

	public void setCnsgFlg(BigDecimal cnsgFlg) {
		this.cnsgFlg = cnsgFlg;
	}

	public String getCondcod() {
		return this.condcod;
	}

	public void setCondcod(String condcod) {
		this.condcod = condcod;
	}

	public BigDecimal getCstmsBondFlg() {
		return this.cstmsBondFlg;
	}

	public void setCstmsBondFlg(BigDecimal cstmsBondFlg) {
		this.cstmsBondFlg = cstmsBondFlg;
	}

	public String getCstmsCmmdtyCod() {
		return this.cstmsCmmdtyCod;
	}

	public void setCstmsCmmdtyCod(String cstmsCmmdtyCod) {
		this.cstmsCmmdtyCod = cstmsCmmdtyCod;
	}

	public String getCstmsCnsgnmntId() {
		return this.cstmsCnsgnmntId;
	}

	public void setCstmsCnsgnmntId(String cstmsCnsgnmntId) {
		this.cstmsCnsgnmntId = cstmsCnsgnmntId;
	}

	public String getCstmsCrncy() {
		return this.cstmsCrncy;
	}

	public void setCstmsCrncy(String cstmsCrncy) {
		this.cstmsCrncy = cstmsCrncy;
	}

	public BigDecimal getCstmsCst() {
		return this.cstmsCst;
	}

	public void setCstmsCst(BigDecimal cstmsCst) {
		this.cstmsCst = cstmsCst;
	}

	public String getCstmsTyp() {
		return this.cstmsTyp;
	}

	public void setCstmsTyp(String cstmsTyp) {
		this.cstmsTyp = cstmsTyp;
	}

	public String getCstmsVatCod() {
		return this.cstmsVatCod;
	}

	public void setCstmsVatCod(String cstmsVatCod) {
		this.cstmsVatCod = cstmsVatCod;
	}

	public String getDfltOrgcod() {
		return this.dfltOrgcod;
	}

	public void setDfltOrgcod(String dfltOrgcod) {
		this.dfltOrgcod = dfltOrgcod;
	}

	public BigDecimal getDistroFlg() {
		return this.distroFlg;
	}

	public void setDistroFlg(BigDecimal distroFlg) {
		this.distroFlg = distroFlg;
	}

	public String getDistroId() {
		return this.distroId;
	}

	public void setDistroId(String distroId) {
		this.distroId = distroId;
	}

	public BigDecimal getDtyStmpFlg() {
		return this.dtyStmpFlg;
	}

	public void setDtyStmpFlg(BigDecimal dtyStmpFlg) {
		this.dtyStmpFlg = dtyStmpFlg;
	}

	public BigDecimal getDtyStmpTrkFlg() {
		return this.dtyStmpTrkFlg;
	}

	public void setDtyStmpTrkFlg(BigDecimal dtyStmpTrkFlg) {
		this.dtyStmpTrkFlg = dtyStmpTrkFlg;
	}

	public Date getExpireDte() {
		return this.expireDte;
	}

	public void setExpireDte(Date expireDte) {
		this.expireDte = expireDte;
	}

	public Date getFifdte() {
		return this.fifdte;
	}

	public void setFifdte(Date fifdte) {
		this.fifdte = fifdte;
	}

	public String getFtpcod() {
		return this.ftpcod;
	}

	public void setFtpcod(String ftpcod) {
		this.ftpcod = ftpcod;
	}

	public BigDecimal getHldFlg() {
		return this.hldFlg;
	}

	public void setHldFlg(BigDecimal hldFlg) {
		this.hldFlg = hldFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getInvAttrDte1() {
		return this.invAttrDte1;
	}

	public void setInvAttrDte1(Date invAttrDte1) {
		this.invAttrDte1 = invAttrDte1;
	}

	public Date getInvAttrDte2() {
		return this.invAttrDte2;
	}

	public void setInvAttrDte2(Date invAttrDte2) {
		this.invAttrDte2 = invAttrDte2;
	}

	public BigDecimal getInvAttrFlt1() {
		return this.invAttrFlt1;
	}

	public void setInvAttrFlt1(BigDecimal invAttrFlt1) {
		this.invAttrFlt1 = invAttrFlt1;
	}

	public BigDecimal getInvAttrFlt2() {
		return this.invAttrFlt2;
	}

	public void setInvAttrFlt2(BigDecimal invAttrFlt2) {
		this.invAttrFlt2 = invAttrFlt2;
	}

	public BigDecimal getInvAttrFlt3() {
		return this.invAttrFlt3;
	}

	public void setInvAttrFlt3(BigDecimal invAttrFlt3) {
		this.invAttrFlt3 = invAttrFlt3;
	}

	public BigDecimal getInvAttrInt1() {
		return this.invAttrInt1;
	}

	public void setInvAttrInt1(BigDecimal invAttrInt1) {
		this.invAttrInt1 = invAttrInt1;
	}

	public BigDecimal getInvAttrInt2() {
		return this.invAttrInt2;
	}

	public void setInvAttrInt2(BigDecimal invAttrInt2) {
		this.invAttrInt2 = invAttrInt2;
	}

	public BigDecimal getInvAttrInt3() {
		return this.invAttrInt3;
	}

	public void setInvAttrInt3(BigDecimal invAttrInt3) {
		this.invAttrInt3 = invAttrInt3;
	}

	public BigDecimal getInvAttrInt4() {
		return this.invAttrInt4;
	}

	public void setInvAttrInt4(BigDecimal invAttrInt4) {
		this.invAttrInt4 = invAttrInt4;
	}

	public BigDecimal getInvAttrInt5() {
		return this.invAttrInt5;
	}

	public void setInvAttrInt5(BigDecimal invAttrInt5) {
		this.invAttrInt5 = invAttrInt5;
	}

	public String getInvAttrStr1() {
		return this.invAttrStr1;
	}

	public void setInvAttrStr1(String invAttrStr1) {
		this.invAttrStr1 = invAttrStr1;
	}

	public String getInvAttrStr10() {
		return this.invAttrStr10;
	}

	public void setInvAttrStr10(String invAttrStr10) {
		this.invAttrStr10 = invAttrStr10;
	}

	public String getInvAttrStr11() {
		return this.invAttrStr11;
	}

	public void setInvAttrStr11(String invAttrStr11) {
		this.invAttrStr11 = invAttrStr11;
	}

	public String getInvAttrStr12() {
		return this.invAttrStr12;
	}

	public void setInvAttrStr12(String invAttrStr12) {
		this.invAttrStr12 = invAttrStr12;
	}

	public String getInvAttrStr13() {
		return this.invAttrStr13;
	}

	public void setInvAttrStr13(String invAttrStr13) {
		this.invAttrStr13 = invAttrStr13;
	}

	public String getInvAttrStr14() {
		return this.invAttrStr14;
	}

	public void setInvAttrStr14(String invAttrStr14) {
		this.invAttrStr14 = invAttrStr14;
	}

	public String getInvAttrStr15() {
		return this.invAttrStr15;
	}

	public void setInvAttrStr15(String invAttrStr15) {
		this.invAttrStr15 = invAttrStr15;
	}

	public String getInvAttrStr16() {
		return this.invAttrStr16;
	}

	public void setInvAttrStr16(String invAttrStr16) {
		this.invAttrStr16 = invAttrStr16;
	}

	public String getInvAttrStr17() {
		return this.invAttrStr17;
	}

	public void setInvAttrStr17(String invAttrStr17) {
		this.invAttrStr17 = invAttrStr17;
	}

	public String getInvAttrStr18() {
		return this.invAttrStr18;
	}

	public void setInvAttrStr18(String invAttrStr18) {
		this.invAttrStr18 = invAttrStr18;
	}

	public String getInvAttrStr2() {
		return this.invAttrStr2;
	}

	public void setInvAttrStr2(String invAttrStr2) {
		this.invAttrStr2 = invAttrStr2;
	}

	public String getInvAttrStr3() {
		return this.invAttrStr3;
	}

	public void setInvAttrStr3(String invAttrStr3) {
		this.invAttrStr3 = invAttrStr3;
	}

	public String getInvAttrStr4() {
		return this.invAttrStr4;
	}

	public void setInvAttrStr4(String invAttrStr4) {
		this.invAttrStr4 = invAttrStr4;
	}

	public String getInvAttrStr5() {
		return this.invAttrStr5;
	}

	public void setInvAttrStr5(String invAttrStr5) {
		this.invAttrStr5 = invAttrStr5;
	}

	public String getInvAttrStr6() {
		return this.invAttrStr6;
	}

	public void setInvAttrStr6(String invAttrStr6) {
		this.invAttrStr6 = invAttrStr6;
	}

	public String getInvAttrStr7() {
		return this.invAttrStr7;
	}

	public void setInvAttrStr7(String invAttrStr7) {
		this.invAttrStr7 = invAttrStr7;
	}

	public String getInvAttrStr8() {
		return this.invAttrStr8;
	}

	public void setInvAttrStr8(String invAttrStr8) {
		this.invAttrStr8 = invAttrStr8;
	}

	public String getInvAttrStr9() {
		return this.invAttrStr9;
	}

	public void setInvAttrStr9(String invAttrStr9) {
		this.invAttrStr9 = invAttrStr9;
	}

	public String getInvsts() {
		return this.invsts;
	}

	public void setInvsts(String invsts) {
		this.invsts = invsts;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getLotnum() {
		return this.lotnum;
	}

	public void setLotnum(String lotnum) {
		this.lotnum = lotnum;
	}

	public BigDecimal getLstMovZoneId() {
		return this.lstMovZoneId;
	}

	public void setLstMovZoneId(BigDecimal lstMovZoneId) {
		this.lstMovZoneId = lstMovZoneId;
	}

	public String getLstUsrId() {
		return this.lstUsrId;
	}

	public void setLstUsrId(String lstUsrId) {
		this.lstUsrId = lstUsrId;
	}

	public String getLstcod() {
		return this.lstcod;
	}

	public void setLstcod(String lstcod) {
		this.lstcod = lstcod;
	}

	public Date getLstdte() {
		return this.lstdte;
	}

	public void setLstdte(Date lstdte) {
		this.lstdte = lstdte;
	}

	public Date getLstmov() {
		return this.lstmov;
	}

	public void setLstmov(Date lstmov) {
		this.lstmov = lstmov;
	}

	public Date getMandte() {
		return this.mandte;
	}

	public void setMandte(Date mandte) {
		this.mandte = mandte;
	}

	public String getOrgcod() {
		return this.orgcod;
	}

	public void setOrgcod(String orgcod) {
		this.orgcod = orgcod;
	}

	public BigDecimal getPhdflg() {
		return this.phdflg;
	}

	public void setPhdflg(BigDecimal phdflg) {
		this.phdflg = phdflg;
	}

	public String getPrtClientId() {
		return this.prtClientId;
	}

	public void setPrtClientId(String prtClientId) {
		this.prtClientId = prtClientId;
	}

	public String getPrtnum() {
		return this.prtnum;
	}

	public void setPrtnum(String prtnum) {
		this.prtnum = prtnum;
	}

	public Date getRcvdte() {
		return this.rcvdte;
	}

	public void setRcvdte(Date rcvdte) {
		this.rcvdte = rcvdte;
	}

	public String getRcvkey() {
		return this.rcvkey;
	}

	public void setRcvkey(String rcvkey) {
		this.rcvkey = rcvkey;
	}

	public String getRevlvl() {
		return this.revlvl;
	}

	public void setRevlvl(String revlvl) {
		this.revlvl = revlvl;
	}

	public String getRttnId() {
		return this.rttnId;
	}

	public void setRttnId(String rttnId) {
		this.rttnId = rttnId;
	}

	public String getShipLineId() {
		return this.shipLineId;
	}

	public void setShipLineId(String shipLineId) {
		this.shipLineId = shipLineId;
	}

	public String getSubnum() {
		return this.subnum;
	}

	public void setSubnum(String subnum) {
		this.subnum = subnum;
	}

	public String getSupLotnum() {
		return this.supLotnum;
	}

	public void setSupLotnum(String supLotnum) {
		this.supLotnum = supLotnum;
	}

	public String getSupnum() {
		return this.supnum;
	}

	public void setSupnum(String supnum) {
		this.supnum = supnum;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

	public BigDecimal getUntcas() {
		return this.untcas;
	}

	public void setUntcas(BigDecimal untcas) {
		this.untcas = untcas;
	}

	public BigDecimal getUntpak() {
		return this.untpak;
	}

	public void setUntpak(BigDecimal untpak) {
		this.untpak = untpak;
	}

	public BigDecimal getUntqty() {
		return this.untqty;
	}

	public void setUntqty(BigDecimal untqty) {
		this.untqty = untqty;
	}

	public String getWrkref() {
		return this.wrkref;
	}

	public void setWrkref(String wrkref) {
		this.wrkref = wrkref;
	}

	public String getWrkrefDtl() {
		return this.wrkrefDtl;
	}

	public void setWrkrefDtl(String wrkrefDtl) {
		this.wrkrefDtl = wrkrefDtl;
	}

}