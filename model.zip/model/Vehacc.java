package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the VEHACC database table.
 * 
 */
@Entity
@NamedQuery(name="Vehacc.findAll", query="SELECT v FROM Vehacc v")
public class Vehacc implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private VehaccPK id;

	public Vehacc() {
	}

	public VehaccPK getId() {
		return this.id;
	}

	public void setId(VehaccPK id) {
		this.id = id;
	}

}