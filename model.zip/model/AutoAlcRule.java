package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the AUTO_ALC_RULE database table.
 * 
 */
@Entity
@Table(name="AUTO_ALC_RULE")
@NamedQuery(name="AutoAlcRule.findAll", query="SELECT a FROM AutoAlcRule a")
public class AutoAlcRule implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private AutoAlcRulePK id;

	@Column(name="AUTO_ALC_MTD")
	private String autoAlcMtd;

	@Column(name="DATE_TYPE")
	private String dateType;

	@Column(name="ENA_FLG")
	private BigDecimal enaFlg;

	@Column(name="INCL_UNPLN_ORD_FLG")
	private BigDecimal inclUnplnOrdFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="PLN_RULE_NAM")
	private String plnRuleNam;

	@Column(name="RULE_TYPE")
	private String ruleType;

	@Column(name="TIME_IN_MINS")
	private BigDecimal timeInMins;

	public AutoAlcRule() {
	}

	public AutoAlcRulePK getId() {
		return this.id;
	}

	public void setId(AutoAlcRulePK id) {
		this.id = id;
	}

	public String getAutoAlcMtd() {
		return this.autoAlcMtd;
	}

	public void setAutoAlcMtd(String autoAlcMtd) {
		this.autoAlcMtd = autoAlcMtd;
	}

	public String getDateType() {
		return this.dateType;
	}

	public void setDateType(String dateType) {
		this.dateType = dateType;
	}

	public BigDecimal getEnaFlg() {
		return this.enaFlg;
	}

	public void setEnaFlg(BigDecimal enaFlg) {
		this.enaFlg = enaFlg;
	}

	public BigDecimal getInclUnplnOrdFlg() {
		return this.inclUnplnOrdFlg;
	}

	public void setInclUnplnOrdFlg(BigDecimal inclUnplnOrdFlg) {
		this.inclUnplnOrdFlg = inclUnplnOrdFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getPlnRuleNam() {
		return this.plnRuleNam;
	}

	public void setPlnRuleNam(String plnRuleNam) {
		this.plnRuleNam = plnRuleNam;
	}

	public String getRuleType() {
		return this.ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}

	public BigDecimal getTimeInMins() {
		return this.timeInMins;
	}

	public void setTimeInMins(BigDecimal timeInMins) {
		this.timeInMins = timeInMins;
	}

}