package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the INV_IDENTIFIERS database table.
 * 
 */
@Entity
@Table(name="INV_IDENTIFIERS")
@NamedQuery(name="InvIdentifier.findAll", query="SELECT i FROM InvIdentifier i")
public class InvIdentifier implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private InvIdentifierPK id;

	@Column(name="CNT_ZONE_ID")
	private BigDecimal cntZoneId;

	public InvIdentifier() {
	}

	public InvIdentifierPK getId() {
		return this.id;
	}

	public void setId(InvIdentifierPK id) {
		this.id = id;
	}

	public BigDecimal getCntZoneId() {
		return this.cntZoneId;
	}

	public void setCntZoneId(BigDecimal cntZoneId) {
		this.cntZoneId = cntZoneId;
	}

}