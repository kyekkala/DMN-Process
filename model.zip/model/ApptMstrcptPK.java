package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the APPT_MSTRCPT database table.
 * 
 */
@Embeddable
public class ApptMstrcptPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String trknum;

	@Column(name="APPT_ID")
	private String apptId;

	public ApptMstrcptPK() {
	}
	public String getTrknum() {
		return this.trknum;
	}
	public void setTrknum(String trknum) {
		this.trknum = trknum;
	}
	public String getApptId() {
		return this.apptId;
	}
	public void setApptId(String apptId) {
		this.apptId = apptId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ApptMstrcptPK)) {
			return false;
		}
		ApptMstrcptPK castOther = (ApptMstrcptPK)other;
		return 
			this.trknum.equals(castOther.trknum)
			&& this.apptId.equals(castOther.apptId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.trknum.hashCode();
		hash = hash * prime + this.apptId.hashCode();
		
		return hash;
	}
}