package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the LES_USR_PSWD_HST database table.
 * 
 */
@Embeddable
public class LesUsrPswdHstPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="USR_ID")
	private String usrId;

	@Temporal(TemporalType.DATE)
	@Column(name="CHG_DTE")
	private java.util.Date chgDte;

	public LesUsrPswdHstPK() {
	}
	public String getUsrId() {
		return this.usrId;
	}
	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}
	public java.util.Date getChgDte() {
		return this.chgDte;
	}
	public void setChgDte(java.util.Date chgDte) {
		this.chgDte = chgDte;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof LesUsrPswdHstPK)) {
			return false;
		}
		LesUsrPswdHstPK castOther = (LesUsrPswdHstPK)other;
		return 
			this.usrId.equals(castOther.usrId)
			&& this.chgDte.equals(castOther.chgDte);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.usrId.hashCode();
		hash = hash * prime + this.chgDte.hashCode();
		
		return hash;
	}
}