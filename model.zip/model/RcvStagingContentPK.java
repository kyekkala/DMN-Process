package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RCV_STAGING_CONTENTS database table.
 * 
 */
@Embeddable
public class RcvStagingContentPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String stoloc;

	@Column(name="WH_ID")
	private String whId;

	private String trknum;

	public RcvStagingContentPK() {
	}
	public String getStoloc() {
		return this.stoloc;
	}
	public void setStoloc(String stoloc) {
		this.stoloc = stoloc;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getTrknum() {
		return this.trknum;
	}
	public void setTrknum(String trknum) {
		this.trknum = trknum;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RcvStagingContentPK)) {
			return false;
		}
		RcvStagingContentPK castOther = (RcvStagingContentPK)other;
		return 
			this.stoloc.equals(castOther.stoloc)
			&& this.whId.equals(castOther.whId)
			&& this.trknum.equals(castOther.trknum);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.stoloc.hashCode();
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.trknum.hashCode();
		
		return hash;
	}
}