package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the LOC_PRT_CLS_LVL database table.
 * 
 */
@Entity
@Table(name="LOC_PRT_CLS_LVL")
@NamedQuery(name="LocPrtClsLvl.findAll", query="SELECT l FROM LocPrtClsLvl l")
public class LocPrtClsLvl implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private LocPrtClsLvlPK id;

	@Column(name="AISLE_ID")
	private String aisleId;

	private String bay;

	private String lvl;

	@Column(name="PRT_CLASS_NAME")
	private String prtClassName;

	@Column(name="PRT_CLASS_SEQ_MAX")
	private BigDecimal prtClassSeqMax;

	@Column(name="PRT_CLASS_SEQ_MIN")
	private BigDecimal prtClassSeqMin;

	public LocPrtClsLvl() {
	}

	public LocPrtClsLvlPK getId() {
		return this.id;
	}

	public void setId(LocPrtClsLvlPK id) {
		this.id = id;
	}

	public String getAisleId() {
		return this.aisleId;
	}

	public void setAisleId(String aisleId) {
		this.aisleId = aisleId;
	}

	public String getBay() {
		return this.bay;
	}

	public void setBay(String bay) {
		this.bay = bay;
	}

	public String getLvl() {
		return this.lvl;
	}

	public void setLvl(String lvl) {
		this.lvl = lvl;
	}

	public String getPrtClassName() {
		return this.prtClassName;
	}

	public void setPrtClassName(String prtClassName) {
		this.prtClassName = prtClassName;
	}

	public BigDecimal getPrtClassSeqMax() {
		return this.prtClassSeqMax;
	}

	public void setPrtClassSeqMax(BigDecimal prtClassSeqMax) {
		this.prtClassSeqMax = prtClassSeqMax;
	}

	public BigDecimal getPrtClassSeqMin() {
		return this.prtClassSeqMin;
	}

	public void setPrtClassSeqMin(BigDecimal prtClassSeqMin) {
		this.prtClassSeqMin = prtClassSeqMin;
	}

}