package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PRTSTYLE_ATTR database table.
 * 
 */
@Embeddable
public class PrtstyleAttrPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ATTR_COLNAM")
	private String attrColnam;

	@Column(name="ATTR_CODNAM")
	private String attrCodnam;

	public PrtstyleAttrPK() {
	}
	public String getAttrColnam() {
		return this.attrColnam;
	}
	public void setAttrColnam(String attrColnam) {
		this.attrColnam = attrColnam;
	}
	public String getAttrCodnam() {
		return this.attrCodnam;
	}
	public void setAttrCodnam(String attrCodnam) {
		this.attrCodnam = attrCodnam;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PrtstyleAttrPK)) {
			return false;
		}
		PrtstyleAttrPK castOther = (PrtstyleAttrPK)other;
		return 
			this.attrColnam.equals(castOther.attrColnam)
			&& this.attrCodnam.equals(castOther.attrCodnam);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.attrColnam.hashCode();
		hash = hash * prime + this.attrCodnam.hashCode();
		
		return hash;
	}
}