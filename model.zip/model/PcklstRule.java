package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PCKLST_RULE database table.
 * 
 */
@Entity
@Table(name="PCKLST_RULE")
@NamedQuery(name="PcklstRule.findAll", query="SELECT p FROM PcklstRule p")
public class PcklstRule implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PCKLST_RULE_ID")
	private long pcklstRuleId;

	@Column(name="ALLOW_SPLIT_FLG")
	private BigDecimal allowSplitFlg;

	@Column(name="ASSET_TYP")
	private String assetTyp;

	@Column(name="ASSIGN_SLOT_FLG")
	private BigDecimal assignSlotFlg;

	@Column(name="CLIENT_ID")
	private String clientId;

	@Column(name="CMB_LIST_FLG")
	private BigDecimal cmbListFlg;

	private String cmdtxt;

	@Column(name="CNF_MTUSED_PRT")
	private BigDecimal cnfMtusedPrt;

	@Column(name="DROP_AT_WRKZONE_CHANGE")
	private BigDecimal dropAtWrkzoneChange;

	@Column(name="FRC_PICKUP_PREV")
	private BigDecimal frcPickupPrev;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LIST_TYP")
	private String listTyp;

	@Column(name="MAX_ASSETS")
	private BigDecimal maxAssets;

	@Column(name="MAX_START_PICKS")
	private BigDecimal maxStartPicks;

	@Column(name="ONE_PASS_ONLY")
	private String onePassOnly;

	@Column(name="OPR_COD")
	private String oprCod;

	@Column(name="PCKLST_RULE_NAME")
	private String pcklstRuleName;

	@Column(name="PICK_ORD_BY")
	private String pickOrdBy;

	@Column(name="PICK_TO_LVL")
	private String pickToLvl;

	@Column(name="PREVENT_PCK_CONS")
	private BigDecimal preventPckCons;

	@Column(name="RE_LIST_FLG")
	private BigDecimal reListFlg;

	@Column(name="RSM_LST_PCK_PREV_OPR")
	private BigDecimal rsmLstPckPrevOpr;

	@Column(name="VALID_FLG")
	private BigDecimal validFlg;

	@Column(name="WA_FIT_CRI")
	private String waFitCri;

	@Column(name="WH_ID")
	private String whId;

	public PcklstRule() {
	}

	public long getPcklstRuleId() {
		return this.pcklstRuleId;
	}

	public void setPcklstRuleId(long pcklstRuleId) {
		this.pcklstRuleId = pcklstRuleId;
	}

	public BigDecimal getAllowSplitFlg() {
		return this.allowSplitFlg;
	}

	public void setAllowSplitFlg(BigDecimal allowSplitFlg) {
		this.allowSplitFlg = allowSplitFlg;
	}

	public String getAssetTyp() {
		return this.assetTyp;
	}

	public void setAssetTyp(String assetTyp) {
		this.assetTyp = assetTyp;
	}

	public BigDecimal getAssignSlotFlg() {
		return this.assignSlotFlg;
	}

	public void setAssignSlotFlg(BigDecimal assignSlotFlg) {
		this.assignSlotFlg = assignSlotFlg;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public BigDecimal getCmbListFlg() {
		return this.cmbListFlg;
	}

	public void setCmbListFlg(BigDecimal cmbListFlg) {
		this.cmbListFlg = cmbListFlg;
	}

	public String getCmdtxt() {
		return this.cmdtxt;
	}

	public void setCmdtxt(String cmdtxt) {
		this.cmdtxt = cmdtxt;
	}

	public BigDecimal getCnfMtusedPrt() {
		return this.cnfMtusedPrt;
	}

	public void setCnfMtusedPrt(BigDecimal cnfMtusedPrt) {
		this.cnfMtusedPrt = cnfMtusedPrt;
	}

	public BigDecimal getDropAtWrkzoneChange() {
		return this.dropAtWrkzoneChange;
	}

	public void setDropAtWrkzoneChange(BigDecimal dropAtWrkzoneChange) {
		this.dropAtWrkzoneChange = dropAtWrkzoneChange;
	}

	public BigDecimal getFrcPickupPrev() {
		return this.frcPickupPrev;
	}

	public void setFrcPickupPrev(BigDecimal frcPickupPrev) {
		this.frcPickupPrev = frcPickupPrev;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getListTyp() {
		return this.listTyp;
	}

	public void setListTyp(String listTyp) {
		this.listTyp = listTyp;
	}

	public BigDecimal getMaxAssets() {
		return this.maxAssets;
	}

	public void setMaxAssets(BigDecimal maxAssets) {
		this.maxAssets = maxAssets;
	}

	public BigDecimal getMaxStartPicks() {
		return this.maxStartPicks;
	}

	public void setMaxStartPicks(BigDecimal maxStartPicks) {
		this.maxStartPicks = maxStartPicks;
	}

	public String getOnePassOnly() {
		return this.onePassOnly;
	}

	public void setOnePassOnly(String onePassOnly) {
		this.onePassOnly = onePassOnly;
	}

	public String getOprCod() {
		return this.oprCod;
	}

	public void setOprCod(String oprCod) {
		this.oprCod = oprCod;
	}

	public String getPcklstRuleName() {
		return this.pcklstRuleName;
	}

	public void setPcklstRuleName(String pcklstRuleName) {
		this.pcklstRuleName = pcklstRuleName;
	}

	public String getPickOrdBy() {
		return this.pickOrdBy;
	}

	public void setPickOrdBy(String pickOrdBy) {
		this.pickOrdBy = pickOrdBy;
	}

	public String getPickToLvl() {
		return this.pickToLvl;
	}

	public void setPickToLvl(String pickToLvl) {
		this.pickToLvl = pickToLvl;
	}

	public BigDecimal getPreventPckCons() {
		return this.preventPckCons;
	}

	public void setPreventPckCons(BigDecimal preventPckCons) {
		this.preventPckCons = preventPckCons;
	}

	public BigDecimal getReListFlg() {
		return this.reListFlg;
	}

	public void setReListFlg(BigDecimal reListFlg) {
		this.reListFlg = reListFlg;
	}

	public BigDecimal getRsmLstPckPrevOpr() {
		return this.rsmLstPckPrevOpr;
	}

	public void setRsmLstPckPrevOpr(BigDecimal rsmLstPckPrevOpr) {
		this.rsmLstPckPrevOpr = rsmLstPckPrevOpr;
	}

	public BigDecimal getValidFlg() {
		return this.validFlg;
	}

	public void setValidFlg(BigDecimal validFlg) {
		this.validFlg = validFlg;
	}

	public String getWaFitCri() {
		return this.waFitCri;
	}

	public void setWaFitCri(String waFitCri) {
		this.waFitCri = waFitCri;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}