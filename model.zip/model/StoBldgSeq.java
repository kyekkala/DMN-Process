package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the STO_BLDG_SEQ database table.
 * 
 */
@Entity
@Table(name="STO_BLDG_SEQ")
@NamedQuery(name="StoBldgSeq.findAll", query="SELECT s FROM StoBldgSeq s")
public class StoBldgSeq implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private StoBldgSeqPK id;

	private BigDecimal srtseq;

	public StoBldgSeq() {
	}

	public StoBldgSeqPK getId() {
		return this.id;
	}

	public void setId(StoBldgSeqPK id) {
		this.id = id;
	}

	public BigDecimal getSrtseq() {
		return this.srtseq;
	}

	public void setSrtseq(BigDecimal srtseq) {
		this.srtseq = srtseq;
	}

}