package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the RCVINV database table.
 * 
 */
@Entity
@NamedQuery(name="Rcvinv.findAll", query="SELECT r FROM Rcvinv r")
public class Rcvinv implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RcvinvPK id;

	@Temporal(TemporalType.DATE)
	@Column(name="COMPLETED_DATE")
	private Date completedDate;

	@Column(name="CSTMS_TYP")
	private String cstmsTyp;

	@Column(name="DOC_NUM")
	private String docNum;

	@Temporal(TemporalType.DATE)
	private Date invdte;

	private String invtyp;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private String orgref;

	@Column(name="PO_NUM")
	private String poNum;

	@Column(name="RET_REF1")
	private String retRef1;

	@Column(name="RET_REF2")
	private String retRef2;

	@Column(name="RET_REF3")
	private String retRef3;

	private String sadnum;

	@Column(name="SHIP_ID")
	private String shipId;

	@Column(name="SRC_HOST")
	private String srcHost;

	@Column(name="TRACK_NUM")
	private String trackNum;

	private String waybil;

	public Rcvinv() {
	}

	public RcvinvPK getId() {
		return this.id;
	}

	public void setId(RcvinvPK id) {
		this.id = id;
	}

	public Date getCompletedDate() {
		return this.completedDate;
	}

	public void setCompletedDate(Date completedDate) {
		this.completedDate = completedDate;
	}

	public String getCstmsTyp() {
		return this.cstmsTyp;
	}

	public void setCstmsTyp(String cstmsTyp) {
		this.cstmsTyp = cstmsTyp;
	}

	public String getDocNum() {
		return this.docNum;
	}

	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	public Date getInvdte() {
		return this.invdte;
	}

	public void setInvdte(Date invdte) {
		this.invdte = invdte;
	}

	public String getInvtyp() {
		return this.invtyp;
	}

	public void setInvtyp(String invtyp) {
		this.invtyp = invtyp;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getOrgref() {
		return this.orgref;
	}

	public void setOrgref(String orgref) {
		this.orgref = orgref;
	}

	public String getPoNum() {
		return this.poNum;
	}

	public void setPoNum(String poNum) {
		this.poNum = poNum;
	}

	public String getRetRef1() {
		return this.retRef1;
	}

	public void setRetRef1(String retRef1) {
		this.retRef1 = retRef1;
	}

	public String getRetRef2() {
		return this.retRef2;
	}

	public void setRetRef2(String retRef2) {
		this.retRef2 = retRef2;
	}

	public String getRetRef3() {
		return this.retRef3;
	}

	public void setRetRef3(String retRef3) {
		this.retRef3 = retRef3;
	}

	public String getSadnum() {
		return this.sadnum;
	}

	public void setSadnum(String sadnum) {
		this.sadnum = sadnum;
	}

	public String getShipId() {
		return this.shipId;
	}

	public void setShipId(String shipId) {
		this.shipId = shipId;
	}

	public String getSrcHost() {
		return this.srcHost;
	}

	public void setSrcHost(String srcHost) {
		this.srcHost = srcHost;
	}

	public String getTrackNum() {
		return this.trackNum;
	}

	public void setTrackNum(String trackNum) {
		this.trackNum = trackNum;
	}

	public String getWaybil() {
		return this.waybil;
	}

	public void setWaybil(String waybil) {
		this.waybil = waybil;
	}

}