package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the ALLOC_SEARCH_PATH_RULE database table.
 * 
 */
@Entity
@Table(name="ALLOC_SEARCH_PATH_RULE")
@NamedQuery(name="AllocSearchPathRule.findAll", query="SELECT a FROM AllocSearchPathRule a")
public class AllocSearchPathRule implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ALLOC_SEARCH_PATH_RULE_ID")
	private String allocSearchPathRuleId;

	@Column(name="ALLOC_GRP_NAM")
	private String allocGrpNam;

	@Column(name="ALLOC_SEARCH_PATH_ID")
	private String allocSearchPathId;

	@Column(name="BLDG_ID")
	private String bldgId;

	@Column(name="CSTMS_BOND_FLG")
	private BigDecimal cstmsBondFlg;

	@Column(name="DTY_STMP_FLG")
	private BigDecimal dtyStmpFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LOC_CAP_PCK_PCT")
	private BigDecimal locCapPckPct;

	private String lodlvl;

	@Column(name="PCK_MTHD_ID")
	private BigDecimal pckMthdId;

	@Column(name="PCK_ZONE_ID")
	private BigDecimal pckZoneId;

	@Column(name="REG_UOM")
	private String regUom;

	private BigDecimal srtseq;

	@Column(name="THRESH_FLG")
	private BigDecimal threshFlg;

	private String uomcod;

	public AllocSearchPathRule() {
	}

	public String getAllocSearchPathRuleId() {
		return this.allocSearchPathRuleId;
	}

	public void setAllocSearchPathRuleId(String allocSearchPathRuleId) {
		this.allocSearchPathRuleId = allocSearchPathRuleId;
	}

	public String getAllocGrpNam() {
		return this.allocGrpNam;
	}

	public void setAllocGrpNam(String allocGrpNam) {
		this.allocGrpNam = allocGrpNam;
	}

	public String getAllocSearchPathId() {
		return this.allocSearchPathId;
	}

	public void setAllocSearchPathId(String allocSearchPathId) {
		this.allocSearchPathId = allocSearchPathId;
	}

	public String getBldgId() {
		return this.bldgId;
	}

	public void setBldgId(String bldgId) {
		this.bldgId = bldgId;
	}

	public BigDecimal getCstmsBondFlg() {
		return this.cstmsBondFlg;
	}

	public void setCstmsBondFlg(BigDecimal cstmsBondFlg) {
		this.cstmsBondFlg = cstmsBondFlg;
	}

	public BigDecimal getDtyStmpFlg() {
		return this.dtyStmpFlg;
	}

	public void setDtyStmpFlg(BigDecimal dtyStmpFlg) {
		this.dtyStmpFlg = dtyStmpFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getLocCapPckPct() {
		return this.locCapPckPct;
	}

	public void setLocCapPckPct(BigDecimal locCapPckPct) {
		this.locCapPckPct = locCapPckPct;
	}

	public String getLodlvl() {
		return this.lodlvl;
	}

	public void setLodlvl(String lodlvl) {
		this.lodlvl = lodlvl;
	}

	public BigDecimal getPckMthdId() {
		return this.pckMthdId;
	}

	public void setPckMthdId(BigDecimal pckMthdId) {
		this.pckMthdId = pckMthdId;
	}

	public BigDecimal getPckZoneId() {
		return this.pckZoneId;
	}

	public void setPckZoneId(BigDecimal pckZoneId) {
		this.pckZoneId = pckZoneId;
	}

	public String getRegUom() {
		return this.regUom;
	}

	public void setRegUom(String regUom) {
		this.regUom = regUom;
	}

	public BigDecimal getSrtseq() {
		return this.srtseq;
	}

	public void setSrtseq(BigDecimal srtseq) {
		this.srtseq = srtseq;
	}

	public BigDecimal getThreshFlg() {
		return this.threshFlg;
	}

	public void setThreshFlg(BigDecimal threshFlg) {
		this.threshFlg = threshFlg;
	}

	public String getUomcod() {
		return this.uomcod;
	}

	public void setUomcod(String uomcod) {
		this.uomcod = uomcod;
	}

}