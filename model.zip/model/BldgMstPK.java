package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the BLDG_MST database table.
 * 
 */
@Embeddable
public class BldgMstPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="BLDG_ID")
	private String bldgId;

	@Column(name="WH_ID")
	private String whId;

	public BldgMstPK() {
	}
	public String getBldgId() {
		return this.bldgId;
	}
	public void setBldgId(String bldgId) {
		this.bldgId = bldgId;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof BldgMstPK)) {
			return false;
		}
		BldgMstPK castOther = (BldgMstPK)other;
		return 
			this.bldgId.equals(castOther.bldgId)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.bldgId.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}