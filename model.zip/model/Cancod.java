package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CANCOD database table.
 * 
 */
@Entity
@NamedQuery(name="Cancod.findAll", query="SELECT c FROM Cancod c")
public class Cancod implements Serializable {
	private static final long serialVersionUID = 1L;

	public Cancod() {
	}

}