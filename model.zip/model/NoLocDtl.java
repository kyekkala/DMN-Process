package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the NO_LOC_DTL database table.
 * 
 */
@Entity
@Table(name="NO_LOC_DTL")
@NamedQuery(name="NoLocDtl.findAll", query="SELECT n FROM NoLocDtl n")
public class NoLocDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="NO_LOC_DTL_ID")
	private String noLocDtlId;

	@Column(name="BLDG_ID")
	private String bldgId;

	@Column(name="COMP_VAL")
	private String compVal;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LOC_VAL")
	private String locVal;

	@Column(name="LOD_VAL")
	private String lodVal;

	@Column(name="NO_LOC_HDR_ID")
	private String noLocHdrId;

	private String reason;

	private String stoloc;

	@Column(name="WH_ID")
	private String whId;

	public NoLocDtl() {
	}

	public String getNoLocDtlId() {
		return this.noLocDtlId;
	}

	public void setNoLocDtlId(String noLocDtlId) {
		this.noLocDtlId = noLocDtlId;
	}

	public String getBldgId() {
		return this.bldgId;
	}

	public void setBldgId(String bldgId) {
		this.bldgId = bldgId;
	}

	public String getCompVal() {
		return this.compVal;
	}

	public void setCompVal(String compVal) {
		this.compVal = compVal;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getLocVal() {
		return this.locVal;
	}

	public void setLocVal(String locVal) {
		this.locVal = locVal;
	}

	public String getLodVal() {
		return this.lodVal;
	}

	public void setLodVal(String lodVal) {
		this.lodVal = lodVal;
	}

	public String getNoLocHdrId() {
		return this.noLocHdrId;
	}

	public void setNoLocHdrId(String noLocHdrId) {
		this.noLocHdrId = noLocHdrId;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getStoloc() {
		return this.stoloc;
	}

	public void setStoloc(String stoloc) {
		this.stoloc = stoloc;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}