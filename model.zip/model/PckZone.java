package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PCK_ZONE database table.
 * 
 */
@Entity
@Table(name="PCK_ZONE")
@NamedQuery(name="PckZone.findAll", query="SELECT p FROM PckZone p")
public class PckZone implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PCK_ZONE_ID")
	private long pckZoneId;

	private String atecod;

	@Column(name="BLDG_ID")
	private String bldgId;

	private String ctngrp;

	private BigDecimal dtlflg;

	@Column(name="ERR_LOC_INVSTS_FLG")
	private BigDecimal errLocInvstsFlg;

	@Column(name="GRP_PCK")
	private BigDecimal grpPck;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LOC_COUNT_BACK_FLG")
	private BigDecimal locCountBackFlg;

	private BigDecimal lodflg;

	private BigDecimal maxpck;

	@Column(name="MIX_LOTSTS_ALLOC_FLG")
	private BigDecimal mixLotstsAllocFlg;

	@Column(name="PCK_STEAL_FLG")
	private BigDecimal pckStealFlg;

	@Column(name="PCK_ZONE_COD")
	private String pckZoneCod;

	private BigDecimal pipflg;

	@Column(name="RF_PCKLST_DSP")
	private BigDecimal rfPcklstDsp;

	@Column(name="RF_SUPPRESS_QTY")
	private BigDecimal rfSuppressQty;

	@Column(name="START_PAL_FLG")
	private BigDecimal startPalFlg;

	private BigDecimal subflg;

	@Column(name="SUM_COUNT_BCK_FLG")
	private BigDecimal sumCountBckFlg;

	@Column(name="VALIDATION_SIZE")
	private BigDecimal validationSize;

	@Column(name="WH_ID")
	private String whId;

	public PckZone() {
	}

	public long getPckZoneId() {
		return this.pckZoneId;
	}

	public void setPckZoneId(long pckZoneId) {
		this.pckZoneId = pckZoneId;
	}

	public String getAtecod() {
		return this.atecod;
	}

	public void setAtecod(String atecod) {
		this.atecod = atecod;
	}

	public String getBldgId() {
		return this.bldgId;
	}

	public void setBldgId(String bldgId) {
		this.bldgId = bldgId;
	}

	public String getCtngrp() {
		return this.ctngrp;
	}

	public void setCtngrp(String ctngrp) {
		this.ctngrp = ctngrp;
	}

	public BigDecimal getDtlflg() {
		return this.dtlflg;
	}

	public void setDtlflg(BigDecimal dtlflg) {
		this.dtlflg = dtlflg;
	}

	public BigDecimal getErrLocInvstsFlg() {
		return this.errLocInvstsFlg;
	}

	public void setErrLocInvstsFlg(BigDecimal errLocInvstsFlg) {
		this.errLocInvstsFlg = errLocInvstsFlg;
	}

	public BigDecimal getGrpPck() {
		return this.grpPck;
	}

	public void setGrpPck(BigDecimal grpPck) {
		this.grpPck = grpPck;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getLocCountBackFlg() {
		return this.locCountBackFlg;
	}

	public void setLocCountBackFlg(BigDecimal locCountBackFlg) {
		this.locCountBackFlg = locCountBackFlg;
	}

	public BigDecimal getLodflg() {
		return this.lodflg;
	}

	public void setLodflg(BigDecimal lodflg) {
		this.lodflg = lodflg;
	}

	public BigDecimal getMaxpck() {
		return this.maxpck;
	}

	public void setMaxpck(BigDecimal maxpck) {
		this.maxpck = maxpck;
	}

	public BigDecimal getMixLotstsAllocFlg() {
		return this.mixLotstsAllocFlg;
	}

	public void setMixLotstsAllocFlg(BigDecimal mixLotstsAllocFlg) {
		this.mixLotstsAllocFlg = mixLotstsAllocFlg;
	}

	public BigDecimal getPckStealFlg() {
		return this.pckStealFlg;
	}

	public void setPckStealFlg(BigDecimal pckStealFlg) {
		this.pckStealFlg = pckStealFlg;
	}

	public String getPckZoneCod() {
		return this.pckZoneCod;
	}

	public void setPckZoneCod(String pckZoneCod) {
		this.pckZoneCod = pckZoneCod;
	}

	public BigDecimal getPipflg() {
		return this.pipflg;
	}

	public void setPipflg(BigDecimal pipflg) {
		this.pipflg = pipflg;
	}

	public BigDecimal getRfPcklstDsp() {
		return this.rfPcklstDsp;
	}

	public void setRfPcklstDsp(BigDecimal rfPcklstDsp) {
		this.rfPcklstDsp = rfPcklstDsp;
	}

	public BigDecimal getRfSuppressQty() {
		return this.rfSuppressQty;
	}

	public void setRfSuppressQty(BigDecimal rfSuppressQty) {
		this.rfSuppressQty = rfSuppressQty;
	}

	public BigDecimal getStartPalFlg() {
		return this.startPalFlg;
	}

	public void setStartPalFlg(BigDecimal startPalFlg) {
		this.startPalFlg = startPalFlg;
	}

	public BigDecimal getSubflg() {
		return this.subflg;
	}

	public void setSubflg(BigDecimal subflg) {
		this.subflg = subflg;
	}

	public BigDecimal getSumCountBckFlg() {
		return this.sumCountBckFlg;
	}

	public void setSumCountBckFlg(BigDecimal sumCountBckFlg) {
		this.sumCountBckFlg = sumCountBckFlg;
	}

	public BigDecimal getValidationSize() {
		return this.validationSize;
	}

	public void setValidationSize(BigDecimal validationSize) {
		this.validationSize = validationSize;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}