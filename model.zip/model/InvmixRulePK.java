package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the INVMIX_RULE database table.
 * 
 */
@Embeddable
public class InvmixRulePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String tblnme;

	@Column(name="COLUMN_NAME")
	private String columnName;

	@Column(name="WH_ID")
	private String whId;

	public InvmixRulePK() {
	}
	public String getTblnme() {
		return this.tblnme;
	}
	public void setTblnme(String tblnme) {
		this.tblnme = tblnme;
	}
	public String getColumnName() {
		return this.columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof InvmixRulePK)) {
			return false;
		}
		InvmixRulePK castOther = (InvmixRulePK)other;
		return 
			this.tblnme.equals(castOther.tblnme)
			&& this.columnName.equals(castOther.columnName)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.tblnme.hashCode();
		hash = hash * prime + this.columnName.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}