package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the ABC_ESTIMATE database table.
 * 
 */
@Entity
@Table(name="ABC_ESTIMATE")
@NamedQuery(name="AbcEstimate.findAll", query="SELECT a FROM AbcEstimate a")
public class AbcEstimate implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private AbcEstimatePK id;

	private BigDecimal cntquota;

	public AbcEstimate() {
	}

	public AbcEstimatePK getId() {
		return this.id;
	}

	public void setId(AbcEstimatePK id) {
		this.id = id;
	}

	public BigDecimal getCntquota() {
		return this.cntquota;
	}

	public void setCntquota(BigDecimal cntquota) {
		this.cntquota = cntquota;
	}

}