package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the MOV_ZONE database table.
 * 
 */
@Entity
@Table(name="MOV_ZONE")
@NamedQuery(name="MovZone.findAll", query="SELECT m FROM MovZone m")
public class MovZone implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MOV_ZONE_ID")
	private long movZoneId;

	@Column(name="ALLOC_MAX_UOM_RPL_FLG")
	private BigDecimal allocMaxUomRplFlg;

	@Column(name="AUTO_CANCEL_PICK")
	private BigDecimal autoCancelPick;

	@Column(name="AUTO_CLOSE_FLG")
	private BigDecimal autoCloseFlg;

	@Column(name="AUTOCLS_SHIP_FLG")
	private BigDecimal autoclsShipFlg;

	@Column(name="BLDG_ID")
	private String bldgId;

	@Column(name="BTO_KIT_DEP_FLG")
	private BigDecimal btoKitDepFlg;

	@Column(name="CAP_FILL_FLG")
	private BigDecimal capFillFlg;

	@Column(name="CLR_DSTLOC_FLG")
	private BigDecimal clrDstlocFlg;

	@Column(name="DEF_RPLCFG_INVSTS")
	private String defRplcfgInvsts;

	@Column(name="DEF_RPLCFG_MAXUNT")
	private BigDecimal defRplcfgMaxunt;

	@Column(name="DEF_RPLCFG_MINUNT")
	private BigDecimal defRplcfgMinunt;

	@Column(name="DEF_RPLCFG_PCTFLG")
	private BigDecimal defRplcfgPctflg;

	@Column(name="DSTR_AUDIT")
	private BigDecimal dstrAudit;

	@Column(name="DSTR_EXCP_LOC")
	private String dstrExcpLoc;

	@Column(name="DYN_RPLCFG_FLG")
	private BigDecimal dynRplcfgFlg;

	@Column(name="DYN_SLOT_FLG")
	private BigDecimal dynSlotFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LBL_ON_SPLIT")
	private BigDecimal lblOnSplit;

	@Column(name="MAX_MHU_DEPOSIT")
	private String maxMhuDeposit;

	@Column(name="MIX_ON_UNLOCK_FLG")
	private BigDecimal mixOnUnlockFlg;

	@Column(name="MOV_ZONE_COD")
	private String movZoneCod;

	@Column(name="OVRPCK_RPL_FLG")
	private BigDecimal ovrpckRplFlg;

	@Column(name="PRE_STAGE_FLG")
	private BigDecimal preStageFlg;

	@Column(name="PROMPT_FOR_PART_DISTR")
	private BigDecimal promptForPartDistr;

	@Column(name="QTY_VER_ONLY_FLG")
	private BigDecimal qtyVerOnlyFlg;

	@Column(name="RCV_PLTBLD_FLG")
	private BigDecimal rcvPltbldFlg;

	private BigDecimal rdtflg;

	@Column(name="RECALC_PUTAWAY")
	private BigDecimal recalcPutaway;

	@Column(name="RPL_SPLIT_DISP_CAS_FLG")
	private BigDecimal rplSplitDispCasFlg;

	@Column(name="SPLIT_TRN")
	private BigDecimal splitTrn;

	@Column(name="THRESH_SPLIT_FLG")
	private BigDecimal threshSplitFlg;

	@Column(name="WH_ID")
	private String whId;

	public MovZone() {
	}

	public long getMovZoneId() {
		return this.movZoneId;
	}

	public void setMovZoneId(long movZoneId) {
		this.movZoneId = movZoneId;
	}

	public BigDecimal getAllocMaxUomRplFlg() {
		return this.allocMaxUomRplFlg;
	}

	public void setAllocMaxUomRplFlg(BigDecimal allocMaxUomRplFlg) {
		this.allocMaxUomRplFlg = allocMaxUomRplFlg;
	}

	public BigDecimal getAutoCancelPick() {
		return this.autoCancelPick;
	}

	public void setAutoCancelPick(BigDecimal autoCancelPick) {
		this.autoCancelPick = autoCancelPick;
	}

	public BigDecimal getAutoCloseFlg() {
		return this.autoCloseFlg;
	}

	public void setAutoCloseFlg(BigDecimal autoCloseFlg) {
		this.autoCloseFlg = autoCloseFlg;
	}

	public BigDecimal getAutoclsShipFlg() {
		return this.autoclsShipFlg;
	}

	public void setAutoclsShipFlg(BigDecimal autoclsShipFlg) {
		this.autoclsShipFlg = autoclsShipFlg;
	}

	public String getBldgId() {
		return this.bldgId;
	}

	public void setBldgId(String bldgId) {
		this.bldgId = bldgId;
	}

	public BigDecimal getBtoKitDepFlg() {
		return this.btoKitDepFlg;
	}

	public void setBtoKitDepFlg(BigDecimal btoKitDepFlg) {
		this.btoKitDepFlg = btoKitDepFlg;
	}

	public BigDecimal getCapFillFlg() {
		return this.capFillFlg;
	}

	public void setCapFillFlg(BigDecimal capFillFlg) {
		this.capFillFlg = capFillFlg;
	}

	public BigDecimal getClrDstlocFlg() {
		return this.clrDstlocFlg;
	}

	public void setClrDstlocFlg(BigDecimal clrDstlocFlg) {
		this.clrDstlocFlg = clrDstlocFlg;
	}

	public String getDefRplcfgInvsts() {
		return this.defRplcfgInvsts;
	}

	public void setDefRplcfgInvsts(String defRplcfgInvsts) {
		this.defRplcfgInvsts = defRplcfgInvsts;
	}

	public BigDecimal getDefRplcfgMaxunt() {
		return this.defRplcfgMaxunt;
	}

	public void setDefRplcfgMaxunt(BigDecimal defRplcfgMaxunt) {
		this.defRplcfgMaxunt = defRplcfgMaxunt;
	}

	public BigDecimal getDefRplcfgMinunt() {
		return this.defRplcfgMinunt;
	}

	public void setDefRplcfgMinunt(BigDecimal defRplcfgMinunt) {
		this.defRplcfgMinunt = defRplcfgMinunt;
	}

	public BigDecimal getDefRplcfgPctflg() {
		return this.defRplcfgPctflg;
	}

	public void setDefRplcfgPctflg(BigDecimal defRplcfgPctflg) {
		this.defRplcfgPctflg = defRplcfgPctflg;
	}

	public BigDecimal getDstrAudit() {
		return this.dstrAudit;
	}

	public void setDstrAudit(BigDecimal dstrAudit) {
		this.dstrAudit = dstrAudit;
	}

	public String getDstrExcpLoc() {
		return this.dstrExcpLoc;
	}

	public void setDstrExcpLoc(String dstrExcpLoc) {
		this.dstrExcpLoc = dstrExcpLoc;
	}

	public BigDecimal getDynRplcfgFlg() {
		return this.dynRplcfgFlg;
	}

	public void setDynRplcfgFlg(BigDecimal dynRplcfgFlg) {
		this.dynRplcfgFlg = dynRplcfgFlg;
	}

	public BigDecimal getDynSlotFlg() {
		return this.dynSlotFlg;
	}

	public void setDynSlotFlg(BigDecimal dynSlotFlg) {
		this.dynSlotFlg = dynSlotFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getLblOnSplit() {
		return this.lblOnSplit;
	}

	public void setLblOnSplit(BigDecimal lblOnSplit) {
		this.lblOnSplit = lblOnSplit;
	}

	public String getMaxMhuDeposit() {
		return this.maxMhuDeposit;
	}

	public void setMaxMhuDeposit(String maxMhuDeposit) {
		this.maxMhuDeposit = maxMhuDeposit;
	}

	public BigDecimal getMixOnUnlockFlg() {
		return this.mixOnUnlockFlg;
	}

	public void setMixOnUnlockFlg(BigDecimal mixOnUnlockFlg) {
		this.mixOnUnlockFlg = mixOnUnlockFlg;
	}

	public String getMovZoneCod() {
		return this.movZoneCod;
	}

	public void setMovZoneCod(String movZoneCod) {
		this.movZoneCod = movZoneCod;
	}

	public BigDecimal getOvrpckRplFlg() {
		return this.ovrpckRplFlg;
	}

	public void setOvrpckRplFlg(BigDecimal ovrpckRplFlg) {
		this.ovrpckRplFlg = ovrpckRplFlg;
	}

	public BigDecimal getPreStageFlg() {
		return this.preStageFlg;
	}

	public void setPreStageFlg(BigDecimal preStageFlg) {
		this.preStageFlg = preStageFlg;
	}

	public BigDecimal getPromptForPartDistr() {
		return this.promptForPartDistr;
	}

	public void setPromptForPartDistr(BigDecimal promptForPartDistr) {
		this.promptForPartDistr = promptForPartDistr;
	}

	public BigDecimal getQtyVerOnlyFlg() {
		return this.qtyVerOnlyFlg;
	}

	public void setQtyVerOnlyFlg(BigDecimal qtyVerOnlyFlg) {
		this.qtyVerOnlyFlg = qtyVerOnlyFlg;
	}

	public BigDecimal getRcvPltbldFlg() {
		return this.rcvPltbldFlg;
	}

	public void setRcvPltbldFlg(BigDecimal rcvPltbldFlg) {
		this.rcvPltbldFlg = rcvPltbldFlg;
	}

	public BigDecimal getRdtflg() {
		return this.rdtflg;
	}

	public void setRdtflg(BigDecimal rdtflg) {
		this.rdtflg = rdtflg;
	}

	public BigDecimal getRecalcPutaway() {
		return this.recalcPutaway;
	}

	public void setRecalcPutaway(BigDecimal recalcPutaway) {
		this.recalcPutaway = recalcPutaway;
	}

	public BigDecimal getRplSplitDispCasFlg() {
		return this.rplSplitDispCasFlg;
	}

	public void setRplSplitDispCasFlg(BigDecimal rplSplitDispCasFlg) {
		this.rplSplitDispCasFlg = rplSplitDispCasFlg;
	}

	public BigDecimal getSplitTrn() {
		return this.splitTrn;
	}

	public void setSplitTrn(BigDecimal splitTrn) {
		this.splitTrn = splitTrn;
	}

	public BigDecimal getThreshSplitFlg() {
		return this.threshSplitFlg;
	}

	public void setThreshSplitFlg(BigDecimal threshSplitFlg) {
		this.threshSplitFlg = threshSplitFlg;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}