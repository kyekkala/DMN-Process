package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PMSN_ROLE_ASSOC database table.
 * 
 */
@Embeddable
public class PmsnRoleAssocPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PMSN_ID")
	private String pmsnId;

	@Column(name="ROLE_ID")
	private String roleId;

	public PmsnRoleAssocPK() {
	}
	public String getPmsnId() {
		return this.pmsnId;
	}
	public void setPmsnId(String pmsnId) {
		this.pmsnId = pmsnId;
	}
	public String getRoleId() {
		return this.roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PmsnRoleAssocPK)) {
			return false;
		}
		PmsnRoleAssocPK castOther = (PmsnRoleAssocPK)other;
		return 
			this.pmsnId.equals(castOther.pmsnId)
			&& this.roleId.equals(castOther.roleId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.pmsnId.hashCode();
		hash = hash * prime + this.roleId.hashCode();
		
		return hash;
	}
}