package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CATCH_QTY_CFG database table.
 * 
 */
@Entity
@Table(name="CATCH_QTY_CFG")
@NamedQuery(name="CatchQtyCfg.findAll", query="SELECT c FROM CatchQtyCfg c")
public class CatchQtyCfg implements Serializable {
	private static final long serialVersionUID = 1L;

	public CatchQtyCfg() {
	}

}