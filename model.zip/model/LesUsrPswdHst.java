package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the LES_USR_PSWD_HST database table.
 * 
 */
@Entity
@Table(name="LES_USR_PSWD_HST")
@NamedQuery(name="LesUsrPswdHst.findAll", query="SELECT l FROM LesUsrPswdHst l")
public class LesUsrPswdHst implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private LesUsrPswdHstPK id;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Column(name="USR_PSWD")
	private String usrPswd;

	public LesUsrPswdHst() {
	}

	public LesUsrPswdHstPK getId() {
		return this.id;
	}

	public void setId(LesUsrPswdHstPK id) {
		this.id = id;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public String getUsrPswd() {
		return this.usrPswd;
	}

	public void setUsrPswd(String usrPswd) {
		this.usrPswd = usrPswd;
	}

}