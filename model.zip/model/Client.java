package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the CLIENT database table.
 * 
 */
@Entity
@NamedQuery(name="Client.findAll", query="SELECT c FROM Client c")
public class Client implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CLIENT_ID")
	private String clientId;

	@Column(name="ADJ_THR_CST")
	private BigDecimal adjThrCst;

	@Column(name="ADJ_THR_UNIT")
	private BigDecimal adjThrUnit;

	@Column(name="ADR_ID")
	private String adrId;

	@Column(name="AUTO_ADD_SERV")
	private BigDecimal autoAddServ;

	@Column(name="BOLA_FRM_RNG")
	private String bolaFrmRng;

	@Column(name="BOLA_NXT_NUM")
	private String bolaNxtNum;

	@Column(name="BOLA_PFX")
	private String bolaPfx;

	@Column(name="BOLA_SFX")
	private String bolaSfx;

	@Column(name="BOLA_TO_RNG")
	private String bolaToRng;

	@Column(name="BT_LOCALE_ID")
	private String btLocaleId;

	@Column(name="FREE_DAYS")
	private BigDecimal freeDays;

	@Column(name="GRP_NAM")
	private String grpNam;

	@Column(name="ISO_CRNCY_FLG")
	private BigDecimal isoCrncyFlg;

	@Column(name="LOT_ANNIV_FLG")
	private BigDecimal lotAnnivFlg;

	@Column(name="LOT_FMT_ID")
	private String lotFmtId;

	@Column(name="RCPT_CONFIRM_LVL")
	private String rcptConfirmLvl;

	@Column(name="SPLIT_STG_COD")
	private String splitStgCod;

	@Column(name="STO_BLNG_TYP")
	private String stoBlngTyp;

	@Column(name="STS_OVR_FLG")
	private BigDecimal stsOvrFlg;

	public Client() {
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public BigDecimal getAdjThrCst() {
		return this.adjThrCst;
	}

	public void setAdjThrCst(BigDecimal adjThrCst) {
		this.adjThrCst = adjThrCst;
	}

	public BigDecimal getAdjThrUnit() {
		return this.adjThrUnit;
	}

	public void setAdjThrUnit(BigDecimal adjThrUnit) {
		this.adjThrUnit = adjThrUnit;
	}

	public String getAdrId() {
		return this.adrId;
	}

	public void setAdrId(String adrId) {
		this.adrId = adrId;
	}

	public BigDecimal getAutoAddServ() {
		return this.autoAddServ;
	}

	public void setAutoAddServ(BigDecimal autoAddServ) {
		this.autoAddServ = autoAddServ;
	}

	public String getBolaFrmRng() {
		return this.bolaFrmRng;
	}

	public void setBolaFrmRng(String bolaFrmRng) {
		this.bolaFrmRng = bolaFrmRng;
	}

	public String getBolaNxtNum() {
		return this.bolaNxtNum;
	}

	public void setBolaNxtNum(String bolaNxtNum) {
		this.bolaNxtNum = bolaNxtNum;
	}

	public String getBolaPfx() {
		return this.bolaPfx;
	}

	public void setBolaPfx(String bolaPfx) {
		this.bolaPfx = bolaPfx;
	}

	public String getBolaSfx() {
		return this.bolaSfx;
	}

	public void setBolaSfx(String bolaSfx) {
		this.bolaSfx = bolaSfx;
	}

	public String getBolaToRng() {
		return this.bolaToRng;
	}

	public void setBolaToRng(String bolaToRng) {
		this.bolaToRng = bolaToRng;
	}

	public String getBtLocaleId() {
		return this.btLocaleId;
	}

	public void setBtLocaleId(String btLocaleId) {
		this.btLocaleId = btLocaleId;
	}

	public BigDecimal getFreeDays() {
		return this.freeDays;
	}

	public void setFreeDays(BigDecimal freeDays) {
		this.freeDays = freeDays;
	}

	public String getGrpNam() {
		return this.grpNam;
	}

	public void setGrpNam(String grpNam) {
		this.grpNam = grpNam;
	}

	public BigDecimal getIsoCrncyFlg() {
		return this.isoCrncyFlg;
	}

	public void setIsoCrncyFlg(BigDecimal isoCrncyFlg) {
		this.isoCrncyFlg = isoCrncyFlg;
	}

	public BigDecimal getLotAnnivFlg() {
		return this.lotAnnivFlg;
	}

	public void setLotAnnivFlg(BigDecimal lotAnnivFlg) {
		this.lotAnnivFlg = lotAnnivFlg;
	}

	public String getLotFmtId() {
		return this.lotFmtId;
	}

	public void setLotFmtId(String lotFmtId) {
		this.lotFmtId = lotFmtId;
	}

	public String getRcptConfirmLvl() {
		return this.rcptConfirmLvl;
	}

	public void setRcptConfirmLvl(String rcptConfirmLvl) {
		this.rcptConfirmLvl = rcptConfirmLvl;
	}

	public String getSplitStgCod() {
		return this.splitStgCod;
	}

	public void setSplitStgCod(String splitStgCod) {
		this.splitStgCod = splitStgCod;
	}

	public String getStoBlngTyp() {
		return this.stoBlngTyp;
	}

	public void setStoBlngTyp(String stoBlngTyp) {
		this.stoBlngTyp = stoBlngTyp;
	}

	public BigDecimal getStsOvrFlg() {
		return this.stsOvrFlg;
	}

	public void setStsOvrFlg(BigDecimal stsOvrFlg) {
		this.stsOvrFlg = stsOvrFlg;
	}

}