package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PCK_MTHD database table.
 * 
 */
@Entity
@Table(name="PCK_MTHD")
@NamedQuery(name="PckMthd.findAll", query="SELECT p FROM PckMthd p")
public class PckMthd implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PCK_MTHD_ID")
	private long pckMthdId;

	@Column(name="CTN_FLG")
	private BigDecimal ctnFlg;

	@Column(name="INLINE_RPL_FLG")
	private BigDecimal inlineRplFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LIST_FLG")
	private BigDecimal listFlg;

	@Column(name="MIX_CS_FLG")
	private BigDecimal mixCsFlg;

	@Column(name="PCK_MTHD_NAM")
	private String pckMthdNam;

	@Column(name="RSV_PCK_REL")
	private BigDecimal rsvPckRel;

	@Column(name="SKIP_PICK_VALDT")
	private String skipPickValdt;

	@Column(name="SPCFC_CS_FLG")
	private BigDecimal spcfcCsFlg;

	@Column(name="WH_ID")
	private String whId;

	public PckMthd() {
	}

	public long getPckMthdId() {
		return this.pckMthdId;
	}

	public void setPckMthdId(long pckMthdId) {
		this.pckMthdId = pckMthdId;
	}

	public BigDecimal getCtnFlg() {
		return this.ctnFlg;
	}

	public void setCtnFlg(BigDecimal ctnFlg) {
		this.ctnFlg = ctnFlg;
	}

	public BigDecimal getInlineRplFlg() {
		return this.inlineRplFlg;
	}

	public void setInlineRplFlg(BigDecimal inlineRplFlg) {
		this.inlineRplFlg = inlineRplFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getListFlg() {
		return this.listFlg;
	}

	public void setListFlg(BigDecimal listFlg) {
		this.listFlg = listFlg;
	}

	public BigDecimal getMixCsFlg() {
		return this.mixCsFlg;
	}

	public void setMixCsFlg(BigDecimal mixCsFlg) {
		this.mixCsFlg = mixCsFlg;
	}

	public String getPckMthdNam() {
		return this.pckMthdNam;
	}

	public void setPckMthdNam(String pckMthdNam) {
		this.pckMthdNam = pckMthdNam;
	}

	public BigDecimal getRsvPckRel() {
		return this.rsvPckRel;
	}

	public void setRsvPckRel(BigDecimal rsvPckRel) {
		this.rsvPckRel = rsvPckRel;
	}

	public String getSkipPickValdt() {
		return this.skipPickValdt;
	}

	public void setSkipPickValdt(String skipPickValdt) {
		this.skipPickValdt = skipPickValdt;
	}

	public BigDecimal getSpcfcCsFlg() {
		return this.spcfcCsFlg;
	}

	public void setSpcfcCsFlg(BigDecimal spcfcCsFlg) {
		this.spcfcCsFlg = spcfcCsFlg;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}