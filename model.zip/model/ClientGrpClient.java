package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CLIENT_GRP_CLIENT database table.
 * 
 */
@Entity
@Table(name="CLIENT_GRP_CLIENT")
@NamedQuery(name="ClientGrpClient.findAll", query="SELECT c FROM ClientGrpClient c")
public class ClientGrpClient implements Serializable {
	private static final long serialVersionUID = 1L;

	public ClientGrpClient() {
	}

}