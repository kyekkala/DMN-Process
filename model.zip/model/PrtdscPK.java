package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PRTDSC database table.
 * 
 */
@Embeddable
public class PrtdscPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String colval;

	@Column(name="LOCALE_ID")
	private String localeId;

	private String colnam;

	public PrtdscPK() {
	}
	public String getColval() {
		return this.colval;
	}
	public void setColval(String colval) {
		this.colval = colval;
	}
	public String getLocaleId() {
		return this.localeId;
	}
	public void setLocaleId(String localeId) {
		this.localeId = localeId;
	}
	public String getColnam() {
		return this.colnam;
	}
	public void setColnam(String colnam) {
		this.colnam = colnam;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PrtdscPK)) {
			return false;
		}
		PrtdscPK castOther = (PrtdscPK)other;
		return 
			this.colval.equals(castOther.colval)
			&& this.localeId.equals(castOther.localeId)
			&& this.colnam.equals(castOther.colnam);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.colval.hashCode();
		hash = hash * prime + this.localeId.hashCode();
		hash = hash * prime + this.colnam.hashCode();
		
		return hash;
	}
}