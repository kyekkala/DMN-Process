package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the MOV_PATH database table.
 * 
 */
@Embeddable
public class MovPathPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SRC_MOV_ZONE_ID")
	private long srcMovZoneId;

	@Column(name="DST_MOV_ZONE_ID")
	private long dstMovZoneId;

	private String lodlvl;

	public MovPathPK() {
	}
	public long getSrcMovZoneId() {
		return this.srcMovZoneId;
	}
	public void setSrcMovZoneId(long srcMovZoneId) {
		this.srcMovZoneId = srcMovZoneId;
	}
	public long getDstMovZoneId() {
		return this.dstMovZoneId;
	}
	public void setDstMovZoneId(long dstMovZoneId) {
		this.dstMovZoneId = dstMovZoneId;
	}
	public String getLodlvl() {
		return this.lodlvl;
	}
	public void setLodlvl(String lodlvl) {
		this.lodlvl = lodlvl;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof MovPathPK)) {
			return false;
		}
		MovPathPK castOther = (MovPathPK)other;
		return 
			(this.srcMovZoneId == castOther.srcMovZoneId)
			&& (this.dstMovZoneId == castOther.dstMovZoneId)
			&& this.lodlvl.equals(castOther.lodlvl);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.srcMovZoneId ^ (this.srcMovZoneId >>> 32)));
		hash = hash * prime + ((int) (this.dstMovZoneId ^ (this.dstMovZoneId >>> 32)));
		hash = hash * prime + this.lodlvl.hashCode();
		
		return hash;
	}
}