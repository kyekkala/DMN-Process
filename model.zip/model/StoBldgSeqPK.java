package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the STO_BLDG_SEQ database table.
 * 
 */
@Embeddable
public class StoBldgSeqPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SRC_BLDG_ID")
	private String srcBldgId;

	@Column(name="DST_BLDG_ID")
	private String dstBldgId;

	@Column(name="WH_ID")
	private String whId;

	public StoBldgSeqPK() {
	}
	public String getSrcBldgId() {
		return this.srcBldgId;
	}
	public void setSrcBldgId(String srcBldgId) {
		this.srcBldgId = srcBldgId;
	}
	public String getDstBldgId() {
		return this.dstBldgId;
	}
	public void setDstBldgId(String dstBldgId) {
		this.dstBldgId = dstBldgId;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof StoBldgSeqPK)) {
			return false;
		}
		StoBldgSeqPK castOther = (StoBldgSeqPK)other;
		return 
			this.srcBldgId.equals(castOther.srcBldgId)
			&& this.dstBldgId.equals(castOther.dstBldgId)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.srcBldgId.hashCode();
		hash = hash * prime + this.dstBldgId.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}