package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PCK_BLDG_SEQ database table.
 * 
 */
@Embeddable
public class PckBldgSeqPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="DST_BLDG_ID")
	private String dstBldgId;

	@Column(name="SRC_BLDG_ID")
	private String srcBldgId;

	@Column(name="WH_ID")
	private String whId;

	public PckBldgSeqPK() {
	}
	public String getDstBldgId() {
		return this.dstBldgId;
	}
	public void setDstBldgId(String dstBldgId) {
		this.dstBldgId = dstBldgId;
	}
	public String getSrcBldgId() {
		return this.srcBldgId;
	}
	public void setSrcBldgId(String srcBldgId) {
		this.srcBldgId = srcBldgId;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PckBldgSeqPK)) {
			return false;
		}
		PckBldgSeqPK castOther = (PckBldgSeqPK)other;
		return 
			this.dstBldgId.equals(castOther.dstBldgId)
			&& this.srcBldgId.equals(castOther.srcBldgId)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.dstBldgId.hashCode();
		hash = hash * prime + this.srcBldgId.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}