package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PCKBAT database table.
 * 
 */
@Entity
@NamedQuery(name="Pckbat.findAll", query="SELECT p FROM Pckbat p")
public class Pckbat implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String schbat;

	@Temporal(TemporalType.DATE)
	private Date adddte;

	private String batcod;

	private String batsts;

	@Temporal(TemporalType.DATE)
	private Date cmpdte;

	private BigDecimal estpal;

	private BigDecimal estwgt;

	private String lblsst;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private BigDecimal numcpk;

	private BigDecimal numpck;

	private BigDecimal numppk;

	private BigDecimal numsls;

	private BigDecimal numstc;

	private BigDecimal palvol;

	private String pricod;

	@Temporal(TemporalType.DATE)
	private Date reldte;

	@Temporal(TemporalType.DATE)
	private Date rpldte;

	@Column(name="RULE_NAM")
	private String ruleNam;

	private BigDecimal totpcs;

	@Column(name="WAVE_PRC_FLG")
	private BigDecimal wavePrcFlg;

	@Column(name="WH_ID")
	private String whId;

	public Pckbat() {
	}

	public String getSchbat() {
		return this.schbat;
	}

	public void setSchbat(String schbat) {
		this.schbat = schbat;
	}

	public Date getAdddte() {
		return this.adddte;
	}

	public void setAdddte(Date adddte) {
		this.adddte = adddte;
	}

	public String getBatcod() {
		return this.batcod;
	}

	public void setBatcod(String batcod) {
		this.batcod = batcod;
	}

	public String getBatsts() {
		return this.batsts;
	}

	public void setBatsts(String batsts) {
		this.batsts = batsts;
	}

	public Date getCmpdte() {
		return this.cmpdte;
	}

	public void setCmpdte(Date cmpdte) {
		this.cmpdte = cmpdte;
	}

	public BigDecimal getEstpal() {
		return this.estpal;
	}

	public void setEstpal(BigDecimal estpal) {
		this.estpal = estpal;
	}

	public BigDecimal getEstwgt() {
		return this.estwgt;
	}

	public void setEstwgt(BigDecimal estwgt) {
		this.estwgt = estwgt;
	}

	public String getLblsst() {
		return this.lblsst;
	}

	public void setLblsst(String lblsst) {
		this.lblsst = lblsst;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getNumcpk() {
		return this.numcpk;
	}

	public void setNumcpk(BigDecimal numcpk) {
		this.numcpk = numcpk;
	}

	public BigDecimal getNumpck() {
		return this.numpck;
	}

	public void setNumpck(BigDecimal numpck) {
		this.numpck = numpck;
	}

	public BigDecimal getNumppk() {
		return this.numppk;
	}

	public void setNumppk(BigDecimal numppk) {
		this.numppk = numppk;
	}

	public BigDecimal getNumsls() {
		return this.numsls;
	}

	public void setNumsls(BigDecimal numsls) {
		this.numsls = numsls;
	}

	public BigDecimal getNumstc() {
		return this.numstc;
	}

	public void setNumstc(BigDecimal numstc) {
		this.numstc = numstc;
	}

	public BigDecimal getPalvol() {
		return this.palvol;
	}

	public void setPalvol(BigDecimal palvol) {
		this.palvol = palvol;
	}

	public String getPricod() {
		return this.pricod;
	}

	public void setPricod(String pricod) {
		this.pricod = pricod;
	}

	public Date getReldte() {
		return this.reldte;
	}

	public void setReldte(Date reldte) {
		this.reldte = reldte;
	}

	public Date getRpldte() {
		return this.rpldte;
	}

	public void setRpldte(Date rpldte) {
		this.rpldte = rpldte;
	}

	public String getRuleNam() {
		return this.ruleNam;
	}

	public void setRuleNam(String ruleNam) {
		this.ruleNam = ruleNam;
	}

	public BigDecimal getTotpcs() {
		return this.totpcs;
	}

	public void setTotpcs(BigDecimal totpcs) {
		this.totpcs = totpcs;
	}

	public BigDecimal getWavePrcFlg() {
		return this.wavePrcFlg;
	}

	public void setWavePrcFlg(BigDecimal wavePrcFlg) {
		this.wavePrcFlg = wavePrcFlg;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}