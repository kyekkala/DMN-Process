package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the ORD_LINE database table.
 * 
 */
@Entity
@Table(name="ORD_LINE")
@NamedQuery(name="OrdLine.findAll", query="SELECT o FROM OrdLine o")
public class OrdLine implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrdLinePK id;

	@Column(name="ABS_ORDINV_CODE")
	private String absOrdinvCode;

	@Column(name="ABS_ORDINV_WIN")
	private BigDecimal absOrdinvWin;

	private String accnum;

	@Column(name="ALC_SEARCH_PATH")
	private String alcSearchPath;

	@Temporal(TemporalType.DATE)
	@Column(name="APPT_DTE")
	private Date apptDte;

	@Column(name="ASSET_TYP")
	private String assetTyp;

	private BigDecimal atoflg;

	@Column(name="AUT_GEN_FLG")
	private BigDecimal autGenFlg;

	private BigDecimal bckflg;

	@Column(name="BLK_SLOT_ONLY_FLG")
	private BigDecimal blkSlotOnlyFlg;

	@Column(name="BLK_SLOT_USED_FLG")
	private BigDecimal blkSlotUsedFlg;

	@Column(name="BTO_BAY")
	private String btoBay;

	@Column(name="BTO_COMCOD")
	private String btoComcod;

	@Column(name="BTO_DLV_SEQ")
	private String btoDlvSeq;

	@Column(name="BTO_SIDE")
	private String btoSide;

	@Column(name="BTO_STATION")
	private String btoStation;

	@Column(name="CANCELLED_FLG")
	private BigDecimal cancelledFlg;

	private String carcod;

	private String cargrp;

	private String cooinc;

	private String coolst;

	private String coonum;

	private String cootyp;

	@Column(name="CRNCY_CODE")
	private String crncyCode;

	@Column(name="CRNCY_NAME")
	private String crncyName;

	private String cstprt;

	@Column(name="CUST_RCV_QTY")
	private BigDecimal custRcvQty;

	private String deptno;

	@Column(name="DISTRO_ID")
	private String distroId;

	@Column(name="DSCRP_REACOD")
	private String dscrpReacod;

	@Column(name="DST_MOV_ZONE_ID")
	private BigDecimal dstMovZoneId;

	private String dstloc;

	@Temporal(TemporalType.DATE)
	@Column(name="EARLY_DLVDTE")
	private Date earlyDlvdte;

	@Temporal(TemporalType.DATE)
	@Column(name="EARLY_SHPDTE")
	private Date earlyShpdte;

	private String eccn;

	private BigDecimal edtflg;

	@Temporal(TemporalType.DATE)
	private Date entdte;

	@Column(name="EQUIP_RES_SCP")
	private String equipResScp;

	@Column(name="EST_TIME")
	private BigDecimal estTime;

	private String explicexcpt;

	@Temporal(TemporalType.DATE)
	private Date explicexpdte;

	private String explicnum;

	@Column(name="EXPORT_TYP")
	private String exportTyp;

	private BigDecimal frsflg;

	private String frtcod;

	private String ftpcod;

	@Column(name="HOST_ORDQTY")
	private BigDecimal hostOrdqty;

	private String implicexcpt;

	@Temporal(TemporalType.DATE)
	private Date implicexpdte;

	private String implicnum;

	@Column(name="INVSTS_PRG")
	private String invstsPrg;

	@Temporal(TemporalType.DATE)
	@Column(name="LATE_DLVDTE")
	private Date lateDlvdte;

	@Temporal(TemporalType.DATE)
	@Column(name="LATE_SHPDTE")
	private Date lateShpdte;

	@Column(name="LOAD_ATTR1_CFG")
	private String loadAttr1Cfg;

	@Column(name="LOAD_ATTR2_CFG")
	private String loadAttr2Cfg;

	@Column(name="LOAD_ATTR3_CFG")
	private String loadAttr3Cfg;

	@Column(name="LOAD_ATTR4_CFG")
	private String loadAttr4Cfg;

	@Column(name="LOAD_ATTR5_CFG")
	private String loadAttr5Cfg;

	private String manfid;

	private String marcod;

	private String marksnumbers;

	@Column(name="MEASUREMENT_TO_TMS")
	private BigDecimal measurementToTms;

	@Column(name="MIN_SHELF_HRS")
	private BigDecimal minShelfHrs;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="NAFTA_PREF_CRIT")
	private String naftaPrefCrit;

	@Column(name="NAFTA_PRODUCER")
	private String naftaProducer;

	@Temporal(TemporalType.DATE)
	private Date naftabegdte;

	@Temporal(TemporalType.DATE)
	private Date naftaenddte;

	@Column(name="NON_ALC_FLG")
	private BigDecimal nonAlcFlg;

	private String ordinv;

	@Column(name="ORDLIN_CHG_REACOD")
	private String ordlinChgReacod;

	private BigDecimal ordqty;

	@Column(name="ORG_DISTRO_ID")
	private String orgDistroId;

	private BigDecimal ovaflg;

	private BigDecimal ovpflg;

	private BigDecimal ovramt;

	private String ovrcod;

	private BigDecimal parflg;

	private String paytrm;

	private String pckgr1;

	private String pckgr2;

	private String pckgr3;

	private String pckgr4;

	private BigDecimal pckqty;

	private String prcpri;

	private String prjnum;

	@Column(name="PRT_CLIENT_ID")
	private String prtClientId;

	private String prtnum;

	@Column(name="REACOD_CMNT")
	private String reacodCmnt;

	@Column(name="REL_VAL")
	private BigDecimal relVal;

	@Column(name="REL_VAL_UNT_TYP")
	private String relValUntTyp;

	private BigDecimal rpqflg;

	private String rsvpri;

	private BigDecimal rsvqty;

	@Column(name="RT_ADR_ID")
	private String rtAdrId;

	@Column(name="RULE_NAM")
	private String ruleNam;

	@Column(name="SALES_ORDLIN")
	private String salesOrdlin;

	@Column(name="SALES_ORDNUM")
	private String salesOrdnum;

	private BigDecimal sddflg;

	@Column(name="SED_EXPORT_TYP")
	private String sedExportTyp;

	private BigDecimal sedflg;

	@Column(name="SF_ADR_ID")
	private String sfAdrId;

	private BigDecimal shpqty;

	private BigDecimal splflg;

	private String srvlvl;

	@Column(name="ST_ADR_ID")
	private String stAdrId;

	private BigDecimal stdflg;

	@Column(name="SUPER_RULE_NAM")
	private String superRuleNam;

	private String supnum;

	@Temporal(TemporalType.DATE)
	@Column(name="TMS_DTE_SNT")
	private Date tmsDteSnt;

	@Column(name="TMS_ORD_STAT")
	private String tmsOrdStat;

	@Column(name="TMS_PLN_STS")
	private String tmsPlnSts;

	@Column(name="TMS_SNT_FLG")
	private BigDecimal tmsSntFlg;

	@Column(name="TOT_PLN_CAS_QTY")
	private BigDecimal totPlnCasQty;

	@Column(name="TOT_PLN_CUBE")
	private BigDecimal totPlnCube;

	@Column(name="TOT_PLN_MISC_QTY")
	private BigDecimal totPlnMiscQty;

	@Column(name="TOT_PLN_MISC2_QTY")
	private BigDecimal totPlnMisc2Qty;

	@Column(name="TOT_PLN_PAL_QTY")
	private BigDecimal totPlnPalQty;

	@Column(name="TOT_PLN_WGT")
	private BigDecimal totPlnWgt;

	private String tradeagreetyp;

	@Column(name="UNT_INS_VAL")
	private BigDecimal untInsVal;

	@Column(name="UNT_PRICE")
	private BigDecimal untPrice;

	private BigDecimal untcas;

	private BigDecimal untpak;

	private BigDecimal untpal;

	@Column(name="WAVE_SET")
	private String waveSet;

	private BigDecimal xdkflg;

	public OrdLine() {
	}

	public OrdLinePK getId() {
		return this.id;
	}

	public void setId(OrdLinePK id) {
		this.id = id;
	}

	public String getAbsOrdinvCode() {
		return this.absOrdinvCode;
	}

	public void setAbsOrdinvCode(String absOrdinvCode) {
		this.absOrdinvCode = absOrdinvCode;
	}

	public BigDecimal getAbsOrdinvWin() {
		return this.absOrdinvWin;
	}

	public void setAbsOrdinvWin(BigDecimal absOrdinvWin) {
		this.absOrdinvWin = absOrdinvWin;
	}

	public String getAccnum() {
		return this.accnum;
	}

	public void setAccnum(String accnum) {
		this.accnum = accnum;
	}

	public String getAlcSearchPath() {
		return this.alcSearchPath;
	}

	public void setAlcSearchPath(String alcSearchPath) {
		this.alcSearchPath = alcSearchPath;
	}

	public Date getApptDte() {
		return this.apptDte;
	}

	public void setApptDte(Date apptDte) {
		this.apptDte = apptDte;
	}

	public String getAssetTyp() {
		return this.assetTyp;
	}

	public void setAssetTyp(String assetTyp) {
		this.assetTyp = assetTyp;
	}

	public BigDecimal getAtoflg() {
		return this.atoflg;
	}

	public void setAtoflg(BigDecimal atoflg) {
		this.atoflg = atoflg;
	}

	public BigDecimal getAutGenFlg() {
		return this.autGenFlg;
	}

	public void setAutGenFlg(BigDecimal autGenFlg) {
		this.autGenFlg = autGenFlg;
	}

	public BigDecimal getBckflg() {
		return this.bckflg;
	}

	public void setBckflg(BigDecimal bckflg) {
		this.bckflg = bckflg;
	}

	public BigDecimal getBlkSlotOnlyFlg() {
		return this.blkSlotOnlyFlg;
	}

	public void setBlkSlotOnlyFlg(BigDecimal blkSlotOnlyFlg) {
		this.blkSlotOnlyFlg = blkSlotOnlyFlg;
	}

	public BigDecimal getBlkSlotUsedFlg() {
		return this.blkSlotUsedFlg;
	}

	public void setBlkSlotUsedFlg(BigDecimal blkSlotUsedFlg) {
		this.blkSlotUsedFlg = blkSlotUsedFlg;
	}

	public String getBtoBay() {
		return this.btoBay;
	}

	public void setBtoBay(String btoBay) {
		this.btoBay = btoBay;
	}

	public String getBtoComcod() {
		return this.btoComcod;
	}

	public void setBtoComcod(String btoComcod) {
		this.btoComcod = btoComcod;
	}

	public String getBtoDlvSeq() {
		return this.btoDlvSeq;
	}

	public void setBtoDlvSeq(String btoDlvSeq) {
		this.btoDlvSeq = btoDlvSeq;
	}

	public String getBtoSide() {
		return this.btoSide;
	}

	public void setBtoSide(String btoSide) {
		this.btoSide = btoSide;
	}

	public String getBtoStation() {
		return this.btoStation;
	}

	public void setBtoStation(String btoStation) {
		this.btoStation = btoStation;
	}

	public BigDecimal getCancelledFlg() {
		return this.cancelledFlg;
	}

	public void setCancelledFlg(BigDecimal cancelledFlg) {
		this.cancelledFlg = cancelledFlg;
	}

	public String getCarcod() {
		return this.carcod;
	}

	public void setCarcod(String carcod) {
		this.carcod = carcod;
	}

	public String getCargrp() {
		return this.cargrp;
	}

	public void setCargrp(String cargrp) {
		this.cargrp = cargrp;
	}

	public String getCooinc() {
		return this.cooinc;
	}

	public void setCooinc(String cooinc) {
		this.cooinc = cooinc;
	}

	public String getCoolst() {
		return this.coolst;
	}

	public void setCoolst(String coolst) {
		this.coolst = coolst;
	}

	public String getCoonum() {
		return this.coonum;
	}

	public void setCoonum(String coonum) {
		this.coonum = coonum;
	}

	public String getCootyp() {
		return this.cootyp;
	}

	public void setCootyp(String cootyp) {
		this.cootyp = cootyp;
	}

	public String getCrncyCode() {
		return this.crncyCode;
	}

	public void setCrncyCode(String crncyCode) {
		this.crncyCode = crncyCode;
	}

	public String getCrncyName() {
		return this.crncyName;
	}

	public void setCrncyName(String crncyName) {
		this.crncyName = crncyName;
	}

	public String getCstprt() {
		return this.cstprt;
	}

	public void setCstprt(String cstprt) {
		this.cstprt = cstprt;
	}

	public BigDecimal getCustRcvQty() {
		return this.custRcvQty;
	}

	public void setCustRcvQty(BigDecimal custRcvQty) {
		this.custRcvQty = custRcvQty;
	}

	public String getDeptno() {
		return this.deptno;
	}

	public void setDeptno(String deptno) {
		this.deptno = deptno;
	}

	public String getDistroId() {
		return this.distroId;
	}

	public void setDistroId(String distroId) {
		this.distroId = distroId;
	}

	public String getDscrpReacod() {
		return this.dscrpReacod;
	}

	public void setDscrpReacod(String dscrpReacod) {
		this.dscrpReacod = dscrpReacod;
	}

	public BigDecimal getDstMovZoneId() {
		return this.dstMovZoneId;
	}

	public void setDstMovZoneId(BigDecimal dstMovZoneId) {
		this.dstMovZoneId = dstMovZoneId;
	}

	public String getDstloc() {
		return this.dstloc;
	}

	public void setDstloc(String dstloc) {
		this.dstloc = dstloc;
	}

	public Date getEarlyDlvdte() {
		return this.earlyDlvdte;
	}

	public void setEarlyDlvdte(Date earlyDlvdte) {
		this.earlyDlvdte = earlyDlvdte;
	}

	public Date getEarlyShpdte() {
		return this.earlyShpdte;
	}

	public void setEarlyShpdte(Date earlyShpdte) {
		this.earlyShpdte = earlyShpdte;
	}

	public String getEccn() {
		return this.eccn;
	}

	public void setEccn(String eccn) {
		this.eccn = eccn;
	}

	public BigDecimal getEdtflg() {
		return this.edtflg;
	}

	public void setEdtflg(BigDecimal edtflg) {
		this.edtflg = edtflg;
	}

	public Date getEntdte() {
		return this.entdte;
	}

	public void setEntdte(Date entdte) {
		this.entdte = entdte;
	}

	public String getEquipResScp() {
		return this.equipResScp;
	}

	public void setEquipResScp(String equipResScp) {
		this.equipResScp = equipResScp;
	}

	public BigDecimal getEstTime() {
		return this.estTime;
	}

	public void setEstTime(BigDecimal estTime) {
		this.estTime = estTime;
	}

	public String getExplicexcpt() {
		return this.explicexcpt;
	}

	public void setExplicexcpt(String explicexcpt) {
		this.explicexcpt = explicexcpt;
	}

	public Date getExplicexpdte() {
		return this.explicexpdte;
	}

	public void setExplicexpdte(Date explicexpdte) {
		this.explicexpdte = explicexpdte;
	}

	public String getExplicnum() {
		return this.explicnum;
	}

	public void setExplicnum(String explicnum) {
		this.explicnum = explicnum;
	}

	public String getExportTyp() {
		return this.exportTyp;
	}

	public void setExportTyp(String exportTyp) {
		this.exportTyp = exportTyp;
	}

	public BigDecimal getFrsflg() {
		return this.frsflg;
	}

	public void setFrsflg(BigDecimal frsflg) {
		this.frsflg = frsflg;
	}

	public String getFrtcod() {
		return this.frtcod;
	}

	public void setFrtcod(String frtcod) {
		this.frtcod = frtcod;
	}

	public String getFtpcod() {
		return this.ftpcod;
	}

	public void setFtpcod(String ftpcod) {
		this.ftpcod = ftpcod;
	}

	public BigDecimal getHostOrdqty() {
		return this.hostOrdqty;
	}

	public void setHostOrdqty(BigDecimal hostOrdqty) {
		this.hostOrdqty = hostOrdqty;
	}

	public String getImplicexcpt() {
		return this.implicexcpt;
	}

	public void setImplicexcpt(String implicexcpt) {
		this.implicexcpt = implicexcpt;
	}

	public Date getImplicexpdte() {
		return this.implicexpdte;
	}

	public void setImplicexpdte(Date implicexpdte) {
		this.implicexpdte = implicexpdte;
	}

	public String getImplicnum() {
		return this.implicnum;
	}

	public void setImplicnum(String implicnum) {
		this.implicnum = implicnum;
	}

	public String getInvstsPrg() {
		return this.invstsPrg;
	}

	public void setInvstsPrg(String invstsPrg) {
		this.invstsPrg = invstsPrg;
	}

	public Date getLateDlvdte() {
		return this.lateDlvdte;
	}

	public void setLateDlvdte(Date lateDlvdte) {
		this.lateDlvdte = lateDlvdte;
	}

	public Date getLateShpdte() {
		return this.lateShpdte;
	}

	public void setLateShpdte(Date lateShpdte) {
		this.lateShpdte = lateShpdte;
	}

	public String getLoadAttr1Cfg() {
		return this.loadAttr1Cfg;
	}

	public void setLoadAttr1Cfg(String loadAttr1Cfg) {
		this.loadAttr1Cfg = loadAttr1Cfg;
	}

	public String getLoadAttr2Cfg() {
		return this.loadAttr2Cfg;
	}

	public void setLoadAttr2Cfg(String loadAttr2Cfg) {
		this.loadAttr2Cfg = loadAttr2Cfg;
	}

	public String getLoadAttr3Cfg() {
		return this.loadAttr3Cfg;
	}

	public void setLoadAttr3Cfg(String loadAttr3Cfg) {
		this.loadAttr3Cfg = loadAttr3Cfg;
	}

	public String getLoadAttr4Cfg() {
		return this.loadAttr4Cfg;
	}

	public void setLoadAttr4Cfg(String loadAttr4Cfg) {
		this.loadAttr4Cfg = loadAttr4Cfg;
	}

	public String getLoadAttr5Cfg() {
		return this.loadAttr5Cfg;
	}

	public void setLoadAttr5Cfg(String loadAttr5Cfg) {
		this.loadAttr5Cfg = loadAttr5Cfg;
	}

	public String getManfid() {
		return this.manfid;
	}

	public void setManfid(String manfid) {
		this.manfid = manfid;
	}

	public String getMarcod() {
		return this.marcod;
	}

	public void setMarcod(String marcod) {
		this.marcod = marcod;
	}

	public String getMarksnumbers() {
		return this.marksnumbers;
	}

	public void setMarksnumbers(String marksnumbers) {
		this.marksnumbers = marksnumbers;
	}

	public BigDecimal getMeasurementToTms() {
		return this.measurementToTms;
	}

	public void setMeasurementToTms(BigDecimal measurementToTms) {
		this.measurementToTms = measurementToTms;
	}

	public BigDecimal getMinShelfHrs() {
		return this.minShelfHrs;
	}

	public void setMinShelfHrs(BigDecimal minShelfHrs) {
		this.minShelfHrs = minShelfHrs;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getNaftaPrefCrit() {
		return this.naftaPrefCrit;
	}

	public void setNaftaPrefCrit(String naftaPrefCrit) {
		this.naftaPrefCrit = naftaPrefCrit;
	}

	public String getNaftaProducer() {
		return this.naftaProducer;
	}

	public void setNaftaProducer(String naftaProducer) {
		this.naftaProducer = naftaProducer;
	}

	public Date getNaftabegdte() {
		return this.naftabegdte;
	}

	public void setNaftabegdte(Date naftabegdte) {
		this.naftabegdte = naftabegdte;
	}

	public Date getNaftaenddte() {
		return this.naftaenddte;
	}

	public void setNaftaenddte(Date naftaenddte) {
		this.naftaenddte = naftaenddte;
	}

	public BigDecimal getNonAlcFlg() {
		return this.nonAlcFlg;
	}

	public void setNonAlcFlg(BigDecimal nonAlcFlg) {
		this.nonAlcFlg = nonAlcFlg;
	}

	public String getOrdinv() {
		return this.ordinv;
	}

	public void setOrdinv(String ordinv) {
		this.ordinv = ordinv;
	}

	public String getOrdlinChgReacod() {
		return this.ordlinChgReacod;
	}

	public void setOrdlinChgReacod(String ordlinChgReacod) {
		this.ordlinChgReacod = ordlinChgReacod;
	}

	public BigDecimal getOrdqty() {
		return this.ordqty;
	}

	public void setOrdqty(BigDecimal ordqty) {
		this.ordqty = ordqty;
	}

	public String getOrgDistroId() {
		return this.orgDistroId;
	}

	public void setOrgDistroId(String orgDistroId) {
		this.orgDistroId = orgDistroId;
	}

	public BigDecimal getOvaflg() {
		return this.ovaflg;
	}

	public void setOvaflg(BigDecimal ovaflg) {
		this.ovaflg = ovaflg;
	}

	public BigDecimal getOvpflg() {
		return this.ovpflg;
	}

	public void setOvpflg(BigDecimal ovpflg) {
		this.ovpflg = ovpflg;
	}

	public BigDecimal getOvramt() {
		return this.ovramt;
	}

	public void setOvramt(BigDecimal ovramt) {
		this.ovramt = ovramt;
	}

	public String getOvrcod() {
		return this.ovrcod;
	}

	public void setOvrcod(String ovrcod) {
		this.ovrcod = ovrcod;
	}

	public BigDecimal getParflg() {
		return this.parflg;
	}

	public void setParflg(BigDecimal parflg) {
		this.parflg = parflg;
	}

	public String getPaytrm() {
		return this.paytrm;
	}

	public void setPaytrm(String paytrm) {
		this.paytrm = paytrm;
	}

	public String getPckgr1() {
		return this.pckgr1;
	}

	public void setPckgr1(String pckgr1) {
		this.pckgr1 = pckgr1;
	}

	public String getPckgr2() {
		return this.pckgr2;
	}

	public void setPckgr2(String pckgr2) {
		this.pckgr2 = pckgr2;
	}

	public String getPckgr3() {
		return this.pckgr3;
	}

	public void setPckgr3(String pckgr3) {
		this.pckgr3 = pckgr3;
	}

	public String getPckgr4() {
		return this.pckgr4;
	}

	public void setPckgr4(String pckgr4) {
		this.pckgr4 = pckgr4;
	}

	public BigDecimal getPckqty() {
		return this.pckqty;
	}

	public void setPckqty(BigDecimal pckqty) {
		this.pckqty = pckqty;
	}

	public String getPrcpri() {
		return this.prcpri;
	}

	public void setPrcpri(String prcpri) {
		this.prcpri = prcpri;
	}

	public String getPrjnum() {
		return this.prjnum;
	}

	public void setPrjnum(String prjnum) {
		this.prjnum = prjnum;
	}

	public String getPrtClientId() {
		return this.prtClientId;
	}

	public void setPrtClientId(String prtClientId) {
		this.prtClientId = prtClientId;
	}

	public String getPrtnum() {
		return this.prtnum;
	}

	public void setPrtnum(String prtnum) {
		this.prtnum = prtnum;
	}

	public String getReacodCmnt() {
		return this.reacodCmnt;
	}

	public void setReacodCmnt(String reacodCmnt) {
		this.reacodCmnt = reacodCmnt;
	}

	public BigDecimal getRelVal() {
		return this.relVal;
	}

	public void setRelVal(BigDecimal relVal) {
		this.relVal = relVal;
	}

	public String getRelValUntTyp() {
		return this.relValUntTyp;
	}

	public void setRelValUntTyp(String relValUntTyp) {
		this.relValUntTyp = relValUntTyp;
	}

	public BigDecimal getRpqflg() {
		return this.rpqflg;
	}

	public void setRpqflg(BigDecimal rpqflg) {
		this.rpqflg = rpqflg;
	}

	public String getRsvpri() {
		return this.rsvpri;
	}

	public void setRsvpri(String rsvpri) {
		this.rsvpri = rsvpri;
	}

	public BigDecimal getRsvqty() {
		return this.rsvqty;
	}

	public void setRsvqty(BigDecimal rsvqty) {
		this.rsvqty = rsvqty;
	}

	public String getRtAdrId() {
		return this.rtAdrId;
	}

	public void setRtAdrId(String rtAdrId) {
		this.rtAdrId = rtAdrId;
	}

	public String getRuleNam() {
		return this.ruleNam;
	}

	public void setRuleNam(String ruleNam) {
		this.ruleNam = ruleNam;
	}

	public String getSalesOrdlin() {
		return this.salesOrdlin;
	}

	public void setSalesOrdlin(String salesOrdlin) {
		this.salesOrdlin = salesOrdlin;
	}

	public String getSalesOrdnum() {
		return this.salesOrdnum;
	}

	public void setSalesOrdnum(String salesOrdnum) {
		this.salesOrdnum = salesOrdnum;
	}

	public BigDecimal getSddflg() {
		return this.sddflg;
	}

	public void setSddflg(BigDecimal sddflg) {
		this.sddflg = sddflg;
	}

	public String getSedExportTyp() {
		return this.sedExportTyp;
	}

	public void setSedExportTyp(String sedExportTyp) {
		this.sedExportTyp = sedExportTyp;
	}

	public BigDecimal getSedflg() {
		return this.sedflg;
	}

	public void setSedflg(BigDecimal sedflg) {
		this.sedflg = sedflg;
	}

	public String getSfAdrId() {
		return this.sfAdrId;
	}

	public void setSfAdrId(String sfAdrId) {
		this.sfAdrId = sfAdrId;
	}

	public BigDecimal getShpqty() {
		return this.shpqty;
	}

	public void setShpqty(BigDecimal shpqty) {
		this.shpqty = shpqty;
	}

	public BigDecimal getSplflg() {
		return this.splflg;
	}

	public void setSplflg(BigDecimal splflg) {
		this.splflg = splflg;
	}

	public String getSrvlvl() {
		return this.srvlvl;
	}

	public void setSrvlvl(String srvlvl) {
		this.srvlvl = srvlvl;
	}

	public String getStAdrId() {
		return this.stAdrId;
	}

	public void setStAdrId(String stAdrId) {
		this.stAdrId = stAdrId;
	}

	public BigDecimal getStdflg() {
		return this.stdflg;
	}

	public void setStdflg(BigDecimal stdflg) {
		this.stdflg = stdflg;
	}

	public String getSuperRuleNam() {
		return this.superRuleNam;
	}

	public void setSuperRuleNam(String superRuleNam) {
		this.superRuleNam = superRuleNam;
	}

	public String getSupnum() {
		return this.supnum;
	}

	public void setSupnum(String supnum) {
		this.supnum = supnum;
	}

	public Date getTmsDteSnt() {
		return this.tmsDteSnt;
	}

	public void setTmsDteSnt(Date tmsDteSnt) {
		this.tmsDteSnt = tmsDteSnt;
	}

	public String getTmsOrdStat() {
		return this.tmsOrdStat;
	}

	public void setTmsOrdStat(String tmsOrdStat) {
		this.tmsOrdStat = tmsOrdStat;
	}

	public String getTmsPlnSts() {
		return this.tmsPlnSts;
	}

	public void setTmsPlnSts(String tmsPlnSts) {
		this.tmsPlnSts = tmsPlnSts;
	}

	public BigDecimal getTmsSntFlg() {
		return this.tmsSntFlg;
	}

	public void setTmsSntFlg(BigDecimal tmsSntFlg) {
		this.tmsSntFlg = tmsSntFlg;
	}

	public BigDecimal getTotPlnCasQty() {
		return this.totPlnCasQty;
	}

	public void setTotPlnCasQty(BigDecimal totPlnCasQty) {
		this.totPlnCasQty = totPlnCasQty;
	}

	public BigDecimal getTotPlnCube() {
		return this.totPlnCube;
	}

	public void setTotPlnCube(BigDecimal totPlnCube) {
		this.totPlnCube = totPlnCube;
	}

	public BigDecimal getTotPlnMiscQty() {
		return this.totPlnMiscQty;
	}

	public void setTotPlnMiscQty(BigDecimal totPlnMiscQty) {
		this.totPlnMiscQty = totPlnMiscQty;
	}

	public BigDecimal getTotPlnMisc2Qty() {
		return this.totPlnMisc2Qty;
	}

	public void setTotPlnMisc2Qty(BigDecimal totPlnMisc2Qty) {
		this.totPlnMisc2Qty = totPlnMisc2Qty;
	}

	public BigDecimal getTotPlnPalQty() {
		return this.totPlnPalQty;
	}

	public void setTotPlnPalQty(BigDecimal totPlnPalQty) {
		this.totPlnPalQty = totPlnPalQty;
	}

	public BigDecimal getTotPlnWgt() {
		return this.totPlnWgt;
	}

	public void setTotPlnWgt(BigDecimal totPlnWgt) {
		this.totPlnWgt = totPlnWgt;
	}

	public String getTradeagreetyp() {
		return this.tradeagreetyp;
	}

	public void setTradeagreetyp(String tradeagreetyp) {
		this.tradeagreetyp = tradeagreetyp;
	}

	public BigDecimal getUntInsVal() {
		return this.untInsVal;
	}

	public void setUntInsVal(BigDecimal untInsVal) {
		this.untInsVal = untInsVal;
	}

	public BigDecimal getUntPrice() {
		return this.untPrice;
	}

	public void setUntPrice(BigDecimal untPrice) {
		this.untPrice = untPrice;
	}

	public BigDecimal getUntcas() {
		return this.untcas;
	}

	public void setUntcas(BigDecimal untcas) {
		this.untcas = untcas;
	}

	public BigDecimal getUntpak() {
		return this.untpak;
	}

	public void setUntpak(BigDecimal untpak) {
		this.untpak = untpak;
	}

	public BigDecimal getUntpal() {
		return this.untpal;
	}

	public void setUntpal(BigDecimal untpal) {
		this.untpal = untpal;
	}

	public String getWaveSet() {
		return this.waveSet;
	}

	public void setWaveSet(String waveSet) {
		this.waveSet = waveSet;
	}

	public BigDecimal getXdkflg() {
		return this.xdkflg;
	}

	public void setXdkflg(BigDecimal xdkflg) {
		this.xdkflg = xdkflg;
	}

}