package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SHIPMENT database table.
 * 
 */
@Entity
@NamedQuery(name="Shipment.findAll", query="SELECT s FROM Shipment s")
public class Shipment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SHIP_ID")
	private String shipId;

	@Temporal(TemporalType.DATE)
	private Date adddte;

	@Temporal(TemporalType.DATE)
	@Column(name="AES_ACPT_DTE")
	private Date aesAcptDte;

	@Column(name="AES_TYP")
	private String aesTyp;

	private String aesitn;

	@Temporal(TemporalType.DATE)
	private Date alcdte;

	@Column(name="ARC_SRC")
	private String arcSrc;

	@Temporal(TemporalType.DATE)
	private Date arcdte;

	@Column(name="BOLA_NUM")
	private String bolaNum;

	@Column(name="BOOK_NUM")
	private String bookNum;

	private String carcod;

	private String cargrp;

	@Column(name="CRNCY_CODE")
	private String crncyCode;

	@Column(name="CTN_ROUTE_GROUP")
	private String ctnRouteGroup;

	private String descgoods;

	@Column(name="DISPATCH_CODE")
	private String dispatchCode;

	@Temporal(TemporalType.DATE)
	@Column(name="DLV_DTE")
	private Date dlvDte;

	@Column(name="DLVSEQ_LOAD_ORDER")
	private String dlvseqLoadOrder;

	@Column(name="DOC_NUM")
	private String docNum;

	private String docind;

	@Column(name="DST_MOV_ZONE_ID")
	private BigDecimal dstMovZoneId;

	private String dstloc;

	@Temporal(TemporalType.DATE)
	@Column(name="EARLY_DLVDTE")
	private Date earlyDlvdte;

	@Temporal(TemporalType.DATE)
	@Column(name="EARLY_SHPDTE")
	private Date earlyShpdte;

	@Temporal(TemporalType.DATE)
	private Date entdte;

	@Column(name="EXPORT_TYP")
	private String exportTyp;

	private String exprsntxt;

	private String frtchg;

	private String frtcod;

	private BigDecimal frtrte;

	private String ftsrnum;

	@Column(name="HOST_CLIENT_ID")
	private String hostClientId;

	@Column(name="HOST_EXT_ID")
	private String hostExtId;

	@Column(name="HUB_ADR_ID")
	private String hubAdrId;

	@Temporal(TemporalType.DATE)
	@Column(name="HUB_ARRDTE")
	private Date hubArrdte;

	@Column(name="HUB_RATE_SERV_NAM")
	private String hubRateServNam;

	@Column(name="IN_TRANSIT_FLG")
	private BigDecimal inTransitFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="LATE_DLVDTE")
	private Date lateDlvdte;

	@Temporal(TemporalType.DATE)
	@Column(name="LATE_SHPDTE")
	private Date lateShpdte;

	@Temporal(TemporalType.DATE)
	@Column(name="LBL_PRTDTE")
	private Date lblPrtdte;

	@Temporal(TemporalType.DATE)
	private Date loddte;

	@Temporal(TemporalType.DATE)
	@Column(name="LST_PRTDTE")
	private Date lstPrtdte;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="MST_WAYBILL")
	private String mstWaybill;

	@Column(name="OPTM_BASE_COST")
	private BigDecimal optmBaseCost;

	@Column(name="PACK_CODE")
	private BigDecimal packCode;

	@Column(name="PAR_SHIP_ID")
	private String parShipId;

	@Column(name="PLN_CMPL_FLG")
	private BigDecimal plnCmplFlg;

	@Column(name="PLN_SHPSTS")
	private String plnShpsts;

	@Column(name="POD_CONF_FLG")
	private BigDecimal podConfFlg;

	@Column(name="PRICE_STS")
	private String priceSts;

	@Column(name="RATE_SERV_NAM")
	private String rateServNam;

	private BigDecimal rrlflg;

	@Column(name="RT_ADR_ID")
	private String rtAdrId;

	private BigDecimal sddflg;

	@Column(name="SES_GRP_NAM")
	private String sesGrpNam;

	@Column(name="SES_TAG")
	private String sesTag;

	private String shpsts;

	@Column(name="SRC_SYS")
	private String srcSys;

	private String srvlvl;

	@Temporal(TemporalType.DATE)
	private Date stgdte;

	@Column(name="STOP_ID")
	private String stopId;

	@Column(name="SUPER_SHIP_FLG")
	private BigDecimal superShipFlg;

	@Column(name="SUPER_SHIP_ID")
	private String superShipId;

	@Column(name="TMS_GROUP_ID")
	private String tmsGroupId;

	@Column(name="TMS_MOVE_ID")
	private String tmsMoveId;

	@Column(name="TMS_MOVE_PLAN_ID")
	private String tmsMovePlanId;

	@Column(name="TOT_PKG_QTY")
	private BigDecimal totPkgQty;

	@Column(name="TRACK_NUM")
	private String trackNum;

	@Column(name="WA_RULE_REFERENCE")
	private String waRuleReference;

	@Column(name="WAVE_SET")
	private String waveSet;

	@Column(name="WH_ID")
	private String whId;

	@Column(name="ZS_LINE_HAUL_ID")
	private String zsLineHaulId;

	public Shipment() {
	}

	public String getShipId() {
		return this.shipId;
	}

	public void setShipId(String shipId) {
		this.shipId = shipId;
	}

	public Date getAdddte() {
		return this.adddte;
	}

	public void setAdddte(Date adddte) {
		this.adddte = adddte;
	}

	public Date getAesAcptDte() {
		return this.aesAcptDte;
	}

	public void setAesAcptDte(Date aesAcptDte) {
		this.aesAcptDte = aesAcptDte;
	}

	public String getAesTyp() {
		return this.aesTyp;
	}

	public void setAesTyp(String aesTyp) {
		this.aesTyp = aesTyp;
	}

	public String getAesitn() {
		return this.aesitn;
	}

	public void setAesitn(String aesitn) {
		this.aesitn = aesitn;
	}

	public Date getAlcdte() {
		return this.alcdte;
	}

	public void setAlcdte(Date alcdte) {
		this.alcdte = alcdte;
	}

	public String getArcSrc() {
		return this.arcSrc;
	}

	public void setArcSrc(String arcSrc) {
		this.arcSrc = arcSrc;
	}

	public Date getArcdte() {
		return this.arcdte;
	}

	public void setArcdte(Date arcdte) {
		this.arcdte = arcdte;
	}

	public String getBolaNum() {
		return this.bolaNum;
	}

	public void setBolaNum(String bolaNum) {
		this.bolaNum = bolaNum;
	}

	public String getBookNum() {
		return this.bookNum;
	}

	public void setBookNum(String bookNum) {
		this.bookNum = bookNum;
	}

	public String getCarcod() {
		return this.carcod;
	}

	public void setCarcod(String carcod) {
		this.carcod = carcod;
	}

	public String getCargrp() {
		return this.cargrp;
	}

	public void setCargrp(String cargrp) {
		this.cargrp = cargrp;
	}

	public String getCrncyCode() {
		return this.crncyCode;
	}

	public void setCrncyCode(String crncyCode) {
		this.crncyCode = crncyCode;
	}

	public String getCtnRouteGroup() {
		return this.ctnRouteGroup;
	}

	public void setCtnRouteGroup(String ctnRouteGroup) {
		this.ctnRouteGroup = ctnRouteGroup;
	}

	public String getDescgoods() {
		return this.descgoods;
	}

	public void setDescgoods(String descgoods) {
		this.descgoods = descgoods;
	}

	public String getDispatchCode() {
		return this.dispatchCode;
	}

	public void setDispatchCode(String dispatchCode) {
		this.dispatchCode = dispatchCode;
	}

	public Date getDlvDte() {
		return this.dlvDte;
	}

	public void setDlvDte(Date dlvDte) {
		this.dlvDte = dlvDte;
	}

	public String getDlvseqLoadOrder() {
		return this.dlvseqLoadOrder;
	}

	public void setDlvseqLoadOrder(String dlvseqLoadOrder) {
		this.dlvseqLoadOrder = dlvseqLoadOrder;
	}

	public String getDocNum() {
		return this.docNum;
	}

	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	public String getDocind() {
		return this.docind;
	}

	public void setDocind(String docind) {
		this.docind = docind;
	}

	public BigDecimal getDstMovZoneId() {
		return this.dstMovZoneId;
	}

	public void setDstMovZoneId(BigDecimal dstMovZoneId) {
		this.dstMovZoneId = dstMovZoneId;
	}

	public String getDstloc() {
		return this.dstloc;
	}

	public void setDstloc(String dstloc) {
		this.dstloc = dstloc;
	}

	public Date getEarlyDlvdte() {
		return this.earlyDlvdte;
	}

	public void setEarlyDlvdte(Date earlyDlvdte) {
		this.earlyDlvdte = earlyDlvdte;
	}

	public Date getEarlyShpdte() {
		return this.earlyShpdte;
	}

	public void setEarlyShpdte(Date earlyShpdte) {
		this.earlyShpdte = earlyShpdte;
	}

	public Date getEntdte() {
		return this.entdte;
	}

	public void setEntdte(Date entdte) {
		this.entdte = entdte;
	}

	public String getExportTyp() {
		return this.exportTyp;
	}

	public void setExportTyp(String exportTyp) {
		this.exportTyp = exportTyp;
	}

	public String getExprsntxt() {
		return this.exprsntxt;
	}

	public void setExprsntxt(String exprsntxt) {
		this.exprsntxt = exprsntxt;
	}

	public String getFrtchg() {
		return this.frtchg;
	}

	public void setFrtchg(String frtchg) {
		this.frtchg = frtchg;
	}

	public String getFrtcod() {
		return this.frtcod;
	}

	public void setFrtcod(String frtcod) {
		this.frtcod = frtcod;
	}

	public BigDecimal getFrtrte() {
		return this.frtrte;
	}

	public void setFrtrte(BigDecimal frtrte) {
		this.frtrte = frtrte;
	}

	public String getFtsrnum() {
		return this.ftsrnum;
	}

	public void setFtsrnum(String ftsrnum) {
		this.ftsrnum = ftsrnum;
	}

	public String getHostClientId() {
		return this.hostClientId;
	}

	public void setHostClientId(String hostClientId) {
		this.hostClientId = hostClientId;
	}

	public String getHostExtId() {
		return this.hostExtId;
	}

	public void setHostExtId(String hostExtId) {
		this.hostExtId = hostExtId;
	}

	public String getHubAdrId() {
		return this.hubAdrId;
	}

	public void setHubAdrId(String hubAdrId) {
		this.hubAdrId = hubAdrId;
	}

	public Date getHubArrdte() {
		return this.hubArrdte;
	}

	public void setHubArrdte(Date hubArrdte) {
		this.hubArrdte = hubArrdte;
	}

	public String getHubRateServNam() {
		return this.hubRateServNam;
	}

	public void setHubRateServNam(String hubRateServNam) {
		this.hubRateServNam = hubRateServNam;
	}

	public BigDecimal getInTransitFlg() {
		return this.inTransitFlg;
	}

	public void setInTransitFlg(BigDecimal inTransitFlg) {
		this.inTransitFlg = inTransitFlg;
	}

	public Date getLateDlvdte() {
		return this.lateDlvdte;
	}

	public void setLateDlvdte(Date lateDlvdte) {
		this.lateDlvdte = lateDlvdte;
	}

	public Date getLateShpdte() {
		return this.lateShpdte;
	}

	public void setLateShpdte(Date lateShpdte) {
		this.lateShpdte = lateShpdte;
	}

	public Date getLblPrtdte() {
		return this.lblPrtdte;
	}

	public void setLblPrtdte(Date lblPrtdte) {
		this.lblPrtdte = lblPrtdte;
	}

	public Date getLoddte() {
		return this.loddte;
	}

	public void setLoddte(Date loddte) {
		this.loddte = loddte;
	}

	public Date getLstPrtdte() {
		return this.lstPrtdte;
	}

	public void setLstPrtdte(Date lstPrtdte) {
		this.lstPrtdte = lstPrtdte;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getMstWaybill() {
		return this.mstWaybill;
	}

	public void setMstWaybill(String mstWaybill) {
		this.mstWaybill = mstWaybill;
	}

	public BigDecimal getOptmBaseCost() {
		return this.optmBaseCost;
	}

	public void setOptmBaseCost(BigDecimal optmBaseCost) {
		this.optmBaseCost = optmBaseCost;
	}

	public BigDecimal getPackCode() {
		return this.packCode;
	}

	public void setPackCode(BigDecimal packCode) {
		this.packCode = packCode;
	}

	public String getParShipId() {
		return this.parShipId;
	}

	public void setParShipId(String parShipId) {
		this.parShipId = parShipId;
	}

	public BigDecimal getPlnCmplFlg() {
		return this.plnCmplFlg;
	}

	public void setPlnCmplFlg(BigDecimal plnCmplFlg) {
		this.plnCmplFlg = plnCmplFlg;
	}

	public String getPlnShpsts() {
		return this.plnShpsts;
	}

	public void setPlnShpsts(String plnShpsts) {
		this.plnShpsts = plnShpsts;
	}

	public BigDecimal getPodConfFlg() {
		return this.podConfFlg;
	}

	public void setPodConfFlg(BigDecimal podConfFlg) {
		this.podConfFlg = podConfFlg;
	}

	public String getPriceSts() {
		return this.priceSts;
	}

	public void setPriceSts(String priceSts) {
		this.priceSts = priceSts;
	}

	public String getRateServNam() {
		return this.rateServNam;
	}

	public void setRateServNam(String rateServNam) {
		this.rateServNam = rateServNam;
	}

	public BigDecimal getRrlflg() {
		return this.rrlflg;
	}

	public void setRrlflg(BigDecimal rrlflg) {
		this.rrlflg = rrlflg;
	}

	public String getRtAdrId() {
		return this.rtAdrId;
	}

	public void setRtAdrId(String rtAdrId) {
		this.rtAdrId = rtAdrId;
	}

	public BigDecimal getSddflg() {
		return this.sddflg;
	}

	public void setSddflg(BigDecimal sddflg) {
		this.sddflg = sddflg;
	}

	public String getSesGrpNam() {
		return this.sesGrpNam;
	}

	public void setSesGrpNam(String sesGrpNam) {
		this.sesGrpNam = sesGrpNam;
	}

	public String getSesTag() {
		return this.sesTag;
	}

	public void setSesTag(String sesTag) {
		this.sesTag = sesTag;
	}

	public String getShpsts() {
		return this.shpsts;
	}

	public void setShpsts(String shpsts) {
		this.shpsts = shpsts;
	}

	public String getSrcSys() {
		return this.srcSys;
	}

	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}

	public String getSrvlvl() {
		return this.srvlvl;
	}

	public void setSrvlvl(String srvlvl) {
		this.srvlvl = srvlvl;
	}

	public Date getStgdte() {
		return this.stgdte;
	}

	public void setStgdte(Date stgdte) {
		this.stgdte = stgdte;
	}

	public String getStopId() {
		return this.stopId;
	}

	public void setStopId(String stopId) {
		this.stopId = stopId;
	}

	public BigDecimal getSuperShipFlg() {
		return this.superShipFlg;
	}

	public void setSuperShipFlg(BigDecimal superShipFlg) {
		this.superShipFlg = superShipFlg;
	}

	public String getSuperShipId() {
		return this.superShipId;
	}

	public void setSuperShipId(String superShipId) {
		this.superShipId = superShipId;
	}

	public String getTmsGroupId() {
		return this.tmsGroupId;
	}

	public void setTmsGroupId(String tmsGroupId) {
		this.tmsGroupId = tmsGroupId;
	}

	public String getTmsMoveId() {
		return this.tmsMoveId;
	}

	public void setTmsMoveId(String tmsMoveId) {
		this.tmsMoveId = tmsMoveId;
	}

	public String getTmsMovePlanId() {
		return this.tmsMovePlanId;
	}

	public void setTmsMovePlanId(String tmsMovePlanId) {
		this.tmsMovePlanId = tmsMovePlanId;
	}

	public BigDecimal getTotPkgQty() {
		return this.totPkgQty;
	}

	public void setTotPkgQty(BigDecimal totPkgQty) {
		this.totPkgQty = totPkgQty;
	}

	public String getTrackNum() {
		return this.trackNum;
	}

	public void setTrackNum(String trackNum) {
		this.trackNum = trackNum;
	}

	public String getWaRuleReference() {
		return this.waRuleReference;
	}

	public void setWaRuleReference(String waRuleReference) {
		this.waRuleReference = waRuleReference;
	}

	public String getWaveSet() {
		return this.waveSet;
	}

	public void setWaveSet(String waveSet) {
		this.waveSet = waveSet;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

	public String getZsLineHaulId() {
		return this.zsLineHaulId;
	}

	public void setZsLineHaulId(String zsLineHaulId) {
		this.zsLineHaulId = zsLineHaulId;
	}

}