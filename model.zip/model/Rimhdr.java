package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the RIMHDR database table.
 * 
 */
@Entity
@NamedQuery(name="Rimhdr.findAll", query="SELECT r FROM Rimhdr r")
public class Rimhdr implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RimhdrPK id;

	@Temporal(TemporalType.DATE)
	private Date adddte;

	@Temporal(TemporalType.DATE)
	private Date clsdte;

	@Column(name="CSTMS_TYP")
	private String cstmsTyp;

	@Temporal(TemporalType.DATE)
	private Date invdte;

	private String invtyp;

	private String orgref;

	private String rimsts;

	private String sadnum;

	private String waybil;

	public Rimhdr() {
	}

	public RimhdrPK getId() {
		return this.id;
	}

	public void setId(RimhdrPK id) {
		this.id = id;
	}

	public Date getAdddte() {
		return this.adddte;
	}

	public void setAdddte(Date adddte) {
		this.adddte = adddte;
	}

	public Date getClsdte() {
		return this.clsdte;
	}

	public void setClsdte(Date clsdte) {
		this.clsdte = clsdte;
	}

	public String getCstmsTyp() {
		return this.cstmsTyp;
	}

	public void setCstmsTyp(String cstmsTyp) {
		this.cstmsTyp = cstmsTyp;
	}

	public Date getInvdte() {
		return this.invdte;
	}

	public void setInvdte(Date invdte) {
		this.invdte = invdte;
	}

	public String getInvtyp() {
		return this.invtyp;
	}

	public void setInvtyp(String invtyp) {
		this.invtyp = invtyp;
	}

	public String getOrgref() {
		return this.orgref;
	}

	public void setOrgref(String orgref) {
		this.orgref = orgref;
	}

	public String getRimsts() {
		return this.rimsts;
	}

	public void setRimsts(String rimsts) {
		this.rimsts = rimsts;
	}

	public String getSadnum() {
		return this.sadnum;
	}

	public void setSadnum(String sadnum) {
		this.sadnum = sadnum;
	}

	public String getWaybil() {
		return this.waybil;
	}

	public void setWaybil(String waybil) {
		this.waybil = waybil;
	}

}