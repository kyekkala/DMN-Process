package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the APPTTYP database table.
 * 
 */
@Entity
@NamedQuery(name="Appttyp.findAll", query="SELECT a FROM Appttyp a")
public class Appttyp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="REC_APPT_ID")
	private String recApptId;

	@Column(name="DAY_OF_REC")
	private BigDecimal dayOfRec;

	@Column(name="DAYS_OF_WEEKLY")
	private String daysOfWeekly;

	@Column(name="END_AFTER")
	private BigDecimal endAfter;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="MONTH_OF_YEAR")
	private BigDecimal monthOfYear;

	@Column(name="REC_APPT_TYP")
	private String recApptTyp;

	private String rrule;

	public Appttyp() {
	}

	public String getRecApptId() {
		return this.recApptId;
	}

	public void setRecApptId(String recApptId) {
		this.recApptId = recApptId;
	}

	public BigDecimal getDayOfRec() {
		return this.dayOfRec;
	}

	public void setDayOfRec(BigDecimal dayOfRec) {
		this.dayOfRec = dayOfRec;
	}

	public String getDaysOfWeekly() {
		return this.daysOfWeekly;
	}

	public void setDaysOfWeekly(String daysOfWeekly) {
		this.daysOfWeekly = daysOfWeekly;
	}

	public BigDecimal getEndAfter() {
		return this.endAfter;
	}

	public void setEndAfter(BigDecimal endAfter) {
		this.endAfter = endAfter;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getMonthOfYear() {
		return this.monthOfYear;
	}

	public void setMonthOfYear(BigDecimal monthOfYear) {
		this.monthOfYear = monthOfYear;
	}

	public String getRecApptTyp() {
		return this.recApptTyp;
	}

	public void setRecApptTyp(String recApptTyp) {
		this.recApptTyp = recApptTyp;
	}

	public String getRrule() {
		return this.rrule;
	}

	public void setRrule(String rrule) {
		this.rrule = rrule;
	}

}