package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CSTMST database table.
 * 
 */
@Entity
@NamedQuery(name="Cstmst.findAll", query="SELECT c FROM Cstmst c")
public class Cstmst implements Serializable {
	private static final long serialVersionUID = 1L;

	public Cstmst() {
	}

}