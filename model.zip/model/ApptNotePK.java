package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the APPT_NOTE database table.
 * 
 */
@Embeddable
public class ApptNotePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="APPT_ID")
	private String apptId;

	private long notlin;

	public ApptNotePK() {
	}
	public String getApptId() {
		return this.apptId;
	}
	public void setApptId(String apptId) {
		this.apptId = apptId;
	}
	public long getNotlin() {
		return this.notlin;
	}
	public void setNotlin(long notlin) {
		this.notlin = notlin;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ApptNotePK)) {
			return false;
		}
		ApptNotePK castOther = (ApptNotePK)other;
		return 
			this.apptId.equals(castOther.apptId)
			&& (this.notlin == castOther.notlin);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.apptId.hashCode();
		hash = hash * prime + ((int) (this.notlin ^ (this.notlin >>> 32)));
		
		return hash;
	}
}