package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RF_OUB_AUD_MOV_ZONE database table.
 * 
 */
@Embeddable
public class RfOubAudMovZonePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="MOV_ZONE_ID")
	private long movZoneId;

	@Column(name="WH_ID")
	private String whId;

	public RfOubAudMovZonePK() {
	}
	public long getMovZoneId() {
		return this.movZoneId;
	}
	public void setMovZoneId(long movZoneId) {
		this.movZoneId = movZoneId;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RfOubAudMovZonePK)) {
			return false;
		}
		RfOubAudMovZonePK castOther = (RfOubAudMovZonePK)other;
		return 
			(this.movZoneId == castOther.movZoneId)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.movZoneId ^ (this.movZoneId >>> 32)));
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}