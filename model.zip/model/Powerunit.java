package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the POWERUNIT database table.
 * 
 */
@Entity
@NamedQuery(name="Powerunit.findAll", query="SELECT p FROM Powerunit p")
public class Powerunit implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="POWERUNIT_ID")
	private String powerunitId;

	@Temporal(TemporalType.DATE)
	private Date arrdte;

	private String carcod;

	@Temporal(TemporalType.DATE)
	@Column(name="DISPATCH_DTE")
	private Date dispatchDte;

	@Column(name="DRIVER_LIC_NUM")
	private String driverLicNum;

	@Column(name="DRIVER_NAM")
	private String driverNam;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="POWERUNIT_NUM")
	private String powerunitNum;

	@Column(name="POWERUNIT_REF")
	private String powerunitRef;

	@Column(name="POWERUNIT_STS")
	private String powerunitSts;

	@Column(name="POWERUNIT_TYPE")
	private String powerunitType;

	public Powerunit() {
	}

	public String getPowerunitId() {
		return this.powerunitId;
	}

	public void setPowerunitId(String powerunitId) {
		this.powerunitId = powerunitId;
	}

	public Date getArrdte() {
		return this.arrdte;
	}

	public void setArrdte(Date arrdte) {
		this.arrdte = arrdte;
	}

	public String getCarcod() {
		return this.carcod;
	}

	public void setCarcod(String carcod) {
		this.carcod = carcod;
	}

	public Date getDispatchDte() {
		return this.dispatchDte;
	}

	public void setDispatchDte(Date dispatchDte) {
		this.dispatchDte = dispatchDte;
	}

	public String getDriverLicNum() {
		return this.driverLicNum;
	}

	public void setDriverLicNum(String driverLicNum) {
		this.driverLicNum = driverLicNum;
	}

	public String getDriverNam() {
		return this.driverNam;
	}

	public void setDriverNam(String driverNam) {
		this.driverNam = driverNam;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getPowerunitNum() {
		return this.powerunitNum;
	}

	public void setPowerunitNum(String powerunitNum) {
		this.powerunitNum = powerunitNum;
	}

	public String getPowerunitRef() {
		return this.powerunitRef;
	}

	public void setPowerunitRef(String powerunitRef) {
		this.powerunitRef = powerunitRef;
	}

	public String getPowerunitSts() {
		return this.powerunitSts;
	}

	public void setPowerunitSts(String powerunitSts) {
		this.powerunitSts = powerunitSts;
	}

	public String getPowerunitType() {
		return this.powerunitType;
	}

	public void setPowerunitType(String powerunitType) {
		this.powerunitType = powerunitType;
	}

}