package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the AGEPFL database table.
 * 
 */
@Entity
@NamedQuery(name="Agepfl.findAll", query="SELECT a FROM Agepfl a")
public class Agepfl implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private AgepflPK id;

	private String agecod;

	private BigDecimal agehrs;

	@Column(name="EXP_AGE_FLG")
	private BigDecimal expAgeFlg;

	@Column(name="EXPIRE_FLG")
	private BigDecimal expireFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private BigDecimal scpflg;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	public Agepfl() {
	}

	public AgepflPK getId() {
		return this.id;
	}

	public void setId(AgepflPK id) {
		this.id = id;
	}

	public String getAgecod() {
		return this.agecod;
	}

	public void setAgecod(String agecod) {
		this.agecod = agecod;
	}

	public BigDecimal getAgehrs() {
		return this.agehrs;
	}

	public void setAgehrs(BigDecimal agehrs) {
		this.agehrs = agehrs;
	}

	public BigDecimal getExpAgeFlg() {
		return this.expAgeFlg;
	}

	public void setExpAgeFlg(BigDecimal expAgeFlg) {
		this.expAgeFlg = expAgeFlg;
	}

	public BigDecimal getExpireFlg() {
		return this.expireFlg;
	}

	public void setExpireFlg(BigDecimal expireFlg) {
		this.expireFlg = expireFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getScpflg() {
		return this.scpflg;
	}

	public void setScpflg(BigDecimal scpflg) {
		this.scpflg = scpflg;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

}