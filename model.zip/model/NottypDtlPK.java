package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the NOTTYP_DTL database table.
 * 
 */
@Embeddable
public class NottypDtlPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String nottyp;

	private String exitpnt;

	public NottypDtlPK() {
	}
	public String getNottyp() {
		return this.nottyp;
	}
	public void setNottyp(String nottyp) {
		this.nottyp = nottyp;
	}
	public String getExitpnt() {
		return this.exitpnt;
	}
	public void setExitpnt(String exitpnt) {
		this.exitpnt = exitpnt;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof NottypDtlPK)) {
			return false;
		}
		NottypDtlPK castOther = (NottypDtlPK)other;
		return 
			this.nottyp.equals(castOther.nottyp)
			&& this.exitpnt.equals(castOther.exitpnt);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.nottyp.hashCode();
		hash = hash * prime + this.exitpnt.hashCode();
		
		return hash;
	}
}