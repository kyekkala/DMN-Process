package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the PRGMST database table.
 * 
 */
@Entity
@NamedQuery(name="Prgmst.findAll", query="SELECT p FROM Prgmst p")
public class Prgmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PrgmstPK id;

	private BigDecimal alcflg;

	private BigDecimal shpflg;

	private BigDecimal srtseq;

	public Prgmst() {
	}

	public PrgmstPK getId() {
		return this.id;
	}

	public void setId(PrgmstPK id) {
		this.id = id;
	}

	public BigDecimal getAlcflg() {
		return this.alcflg;
	}

	public void setAlcflg(BigDecimal alcflg) {
		this.alcflg = alcflg;
	}

	public BigDecimal getShpflg() {
		return this.shpflg;
	}

	public void setShpflg(BigDecimal shpflg) {
		this.shpflg = shpflg;
	}

	public BigDecimal getSrtseq() {
		return this.srtseq;
	}

	public void setSrtseq(BigDecimal srtseq) {
		this.srtseq = srtseq;
	}

}