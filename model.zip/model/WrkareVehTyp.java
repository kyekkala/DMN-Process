package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the WRKARE_VEH_TYP database table.
 * 
 */
@Entity
@Table(name="WRKARE_VEH_TYP")
@NamedQuery(name="WrkareVehTyp.findAll", query="SELECT w FROM WrkareVehTyp w")
public class WrkareVehTyp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="WRKARE_VEH_TYP_ID")
	private long wrkareVehTypId;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private BigDecimal maxdev;

	private String vehtyp;

	@Column(name="WH_ID")
	private String whId;

	private String wrkare;

	public WrkareVehTyp() {
	}

	public long getWrkareVehTypId() {
		return this.wrkareVehTypId;
	}

	public void setWrkareVehTypId(long wrkareVehTypId) {
		this.wrkareVehTypId = wrkareVehTypId;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getMaxdev() {
		return this.maxdev;
	}

	public void setMaxdev(BigDecimal maxdev) {
		this.maxdev = maxdev;
	}

	public String getVehtyp() {
		return this.vehtyp;
	}

	public void setVehtyp(String vehtyp) {
		this.vehtyp = vehtyp;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

	public String getWrkare() {
		return this.wrkare;
	}

	public void setWrkare(String wrkare) {
		this.wrkare = wrkare;
	}

}