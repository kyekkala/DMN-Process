package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PRTFAM database table.
 * 
 */
@Entity
@NamedQuery(name="Prtfam.findAll", query="SELECT p FROM Prtfam p")
public class Prtfam implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String prtfam;

	@Column(name="BRK_STOP_SEQ_COD")
	private String brkStopSeqCod;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="PAL_THRESH_PCT")
	private BigDecimal palThreshPct;

	private String prtfamgrp;

	@Column(name="RELPCK_ASSET_FUL_FLG")
	private BigDecimal relpckAssetFulFlg;

	@Column(name="WRK_REL_SEQ")
	private BigDecimal wrkRelSeq;

	public Prtfam() {
	}

	public String getPrtfam() {
		return this.prtfam;
	}

	public void setPrtfam(String prtfam) {
		this.prtfam = prtfam;
	}

	public String getBrkStopSeqCod() {
		return this.brkStopSeqCod;
	}

	public void setBrkStopSeqCod(String brkStopSeqCod) {
		this.brkStopSeqCod = brkStopSeqCod;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getPalThreshPct() {
		return this.palThreshPct;
	}

	public void setPalThreshPct(BigDecimal palThreshPct) {
		this.palThreshPct = palThreshPct;
	}

	public String getPrtfamgrp() {
		return this.prtfamgrp;
	}

	public void setPrtfamgrp(String prtfamgrp) {
		this.prtfamgrp = prtfamgrp;
	}

	public BigDecimal getRelpckAssetFulFlg() {
		return this.relpckAssetFulFlg;
	}

	public void setRelpckAssetFulFlg(BigDecimal relpckAssetFulFlg) {
		this.relpckAssetFulFlg = relpckAssetFulFlg;
	}

	public BigDecimal getWrkRelSeq() {
		return this.wrkRelSeq;
	}

	public void setWrkRelSeq(BigDecimal wrkRelSeq) {
		this.wrkRelSeq = wrkRelSeq;
	}

}