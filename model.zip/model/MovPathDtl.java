package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the MOV_PATH_DTL database table.
 * 
 */
@Entity
@Table(name="MOV_PATH_DTL")
@NamedQuery(name="MovPathDtl.findAll", query="SELECT m FROM MovPathDtl m")
public class MovPathDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private MovPathDtlPK id;

	@Column(name="CRI_ID")
	private String criId;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="MOVE_METHOD")
	private String moveMethod;

	public MovPathDtl() {
	}

	public MovPathDtlPK getId() {
		return this.id;
	}

	public void setId(MovPathDtlPK id) {
		this.id = id;
	}

	public String getCriId() {
		return this.criId;
	}

	public void setCriId(String criId) {
		this.criId = criId;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getMoveMethod() {
		return this.moveMethod;
	}

	public void setMoveMethod(String moveMethod) {
		this.moveMethod = moveMethod;
	}

}