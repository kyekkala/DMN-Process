package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the QVLWRK database table.
 * 
 */
@Entity
@NamedQuery(name="Qvlwrk.findAll", query="SELECT q FROM Qvlwrk q")
public class Qvlwrk implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="ASSET_TYP")
	private String assetTyp;

	private BigDecimal pndqvl;

	@Column(name="PRT_CLIENT_ID")
	private String prtClientId;

	private String prtnum;

	private String stoloc;

	private BigDecimal untqty;

	@Column(name="WH_ID")
	private String whId;

	public Qvlwrk() {
	}

	public String getAssetTyp() {
		return this.assetTyp;
	}

	public void setAssetTyp(String assetTyp) {
		this.assetTyp = assetTyp;
	}

	public BigDecimal getPndqvl() {
		return this.pndqvl;
	}

	public void setPndqvl(BigDecimal pndqvl) {
		this.pndqvl = pndqvl;
	}

	public String getPrtClientId() {
		return this.prtClientId;
	}

	public void setPrtClientId(String prtClientId) {
		this.prtClientId = prtClientId;
	}

	public String getPrtnum() {
		return this.prtnum;
	}

	public void setPrtnum(String prtnum) {
		this.prtnum = prtnum;
	}

	public String getStoloc() {
		return this.stoloc;
	}

	public void setStoloc(String stoloc) {
		this.stoloc = stoloc;
	}

	public BigDecimal getUntqty() {
		return this.untqty;
	}

	public void setUntqty(BigDecimal untqty) {
		this.untqty = untqty;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}