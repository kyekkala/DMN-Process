package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the CARDTL database table.
 * 
 */
@Entity
@NamedQuery(name="Cardtl.findAll", query="SELECT c FROM Cardtl c")
public class Cardtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private CardtlPK id;

	@Column(name="BOOKING_RQD_FLG")
	private BigDecimal bookingRqdFlg;

	@Column(name="BUNDLE_FLG")
	private BigDecimal bundleFlg;

	private String cartyp;

	@Column(name="CRNCY_CODE")
	private String crncyCode;

	@Column(name="FLUID_LOAD_FLG")
	private BigDecimal fluidLoadFlg;

	@Column(name="INTL_FLG")
	private BigDecimal intlFlg;

	@Column(name="MAX_VAL")
	private BigDecimal maxVal;

	@Column(name="MAX_VOL")
	private BigDecimal maxVol;

	@Column(name="MAX_WGT")
	private BigDecimal maxWgt;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="REL_VAL")
	private BigDecimal relVal;

	@Column(name="REL_VAL_UNT_TYP")
	private String relValUntTyp;

	private BigDecimal sddflg;

	@Column(name="SHP_STG_OVRD_FLG")
	private BigDecimal shpStgOvrdFlg;

	@Column(name="SINGLE_PKG_SHP_FLG")
	private BigDecimal singlePkgShpFlg;

	@Column(name="SRVLVL_NAM")
	private String srvlvlNam;

	@Column(name="UNT_INS_VAL")
	private BigDecimal untInsVal;

	public Cardtl() {
	}

	public CardtlPK getId() {
		return this.id;
	}

	public void setId(CardtlPK id) {
		this.id = id;
	}

	public BigDecimal getBookingRqdFlg() {
		return this.bookingRqdFlg;
	}

	public void setBookingRqdFlg(BigDecimal bookingRqdFlg) {
		this.bookingRqdFlg = bookingRqdFlg;
	}

	public BigDecimal getBundleFlg() {
		return this.bundleFlg;
	}

	public void setBundleFlg(BigDecimal bundleFlg) {
		this.bundleFlg = bundleFlg;
	}

	public String getCartyp() {
		return this.cartyp;
	}

	public void setCartyp(String cartyp) {
		this.cartyp = cartyp;
	}

	public String getCrncyCode() {
		return this.crncyCode;
	}

	public void setCrncyCode(String crncyCode) {
		this.crncyCode = crncyCode;
	}

	public BigDecimal getFluidLoadFlg() {
		return this.fluidLoadFlg;
	}

	public void setFluidLoadFlg(BigDecimal fluidLoadFlg) {
		this.fluidLoadFlg = fluidLoadFlg;
	}

	public BigDecimal getIntlFlg() {
		return this.intlFlg;
	}

	public void setIntlFlg(BigDecimal intlFlg) {
		this.intlFlg = intlFlg;
	}

	public BigDecimal getMaxVal() {
		return this.maxVal;
	}

	public void setMaxVal(BigDecimal maxVal) {
		this.maxVal = maxVal;
	}

	public BigDecimal getMaxVol() {
		return this.maxVol;
	}

	public void setMaxVol(BigDecimal maxVol) {
		this.maxVol = maxVol;
	}

	public BigDecimal getMaxWgt() {
		return this.maxWgt;
	}

	public void setMaxWgt(BigDecimal maxWgt) {
		this.maxWgt = maxWgt;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getRelVal() {
		return this.relVal;
	}

	public void setRelVal(BigDecimal relVal) {
		this.relVal = relVal;
	}

	public String getRelValUntTyp() {
		return this.relValUntTyp;
	}

	public void setRelValUntTyp(String relValUntTyp) {
		this.relValUntTyp = relValUntTyp;
	}

	public BigDecimal getSddflg() {
		return this.sddflg;
	}

	public void setSddflg(BigDecimal sddflg) {
		this.sddflg = sddflg;
	}

	public BigDecimal getShpStgOvrdFlg() {
		return this.shpStgOvrdFlg;
	}

	public void setShpStgOvrdFlg(BigDecimal shpStgOvrdFlg) {
		this.shpStgOvrdFlg = shpStgOvrdFlg;
	}

	public BigDecimal getSinglePkgShpFlg() {
		return this.singlePkgShpFlg;
	}

	public void setSinglePkgShpFlg(BigDecimal singlePkgShpFlg) {
		this.singlePkgShpFlg = singlePkgShpFlg;
	}

	public String getSrvlvlNam() {
		return this.srvlvlNam;
	}

	public void setSrvlvlNam(String srvlvlNam) {
		this.srvlvlNam = srvlvlNam;
	}

	public BigDecimal getUntInsVal() {
		return this.untInsVal;
	}

	public void setUntInsVal(BigDecimal untInsVal) {
		this.untInsVal = untInsVal;
	}

}