package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the HOME_FRM_ITM database table.
 * 
 */
@Embeddable
public class HomeFrmItmPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="FRM_ID")
	private String frmId;

	@Column(name="VAR_NAM")
	private String varNam;

	@Column(name="CUST_LVL")
	private long custLvl;

	public HomeFrmItmPK() {
	}
	public String getFrmId() {
		return this.frmId;
	}
	public void setFrmId(String frmId) {
		this.frmId = frmId;
	}
	public String getVarNam() {
		return this.varNam;
	}
	public void setVarNam(String varNam) {
		this.varNam = varNam;
	}
	public long getCustLvl() {
		return this.custLvl;
	}
	public void setCustLvl(long custLvl) {
		this.custLvl = custLvl;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof HomeFrmItmPK)) {
			return false;
		}
		HomeFrmItmPK castOther = (HomeFrmItmPK)other;
		return 
			this.frmId.equals(castOther.frmId)
			&& this.varNam.equals(castOther.varNam)
			&& (this.custLvl == castOther.custLvl);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.frmId.hashCode();
		hash = hash * prime + this.varNam.hashCode();
		hash = hash * prime + ((int) (this.custLvl ^ (this.custLvl >>> 32)));
		
		return hash;
	}
}