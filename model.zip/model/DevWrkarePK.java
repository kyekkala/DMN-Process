package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the DEV_WRKARE database table.
 * 
 */
@Embeddable
public class DevWrkarePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String devcod;

	private String wrkare;

	@Column(name="WH_ID")
	private String whId;

	public DevWrkarePK() {
	}
	public String getDevcod() {
		return this.devcod;
	}
	public void setDevcod(String devcod) {
		this.devcod = devcod;
	}
	public String getWrkare() {
		return this.wrkare;
	}
	public void setWrkare(String wrkare) {
		this.wrkare = wrkare;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof DevWrkarePK)) {
			return false;
		}
		DevWrkarePK castOther = (DevWrkarePK)other;
		return 
			this.devcod.equals(castOther.devcod)
			&& this.wrkare.equals(castOther.wrkare)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.devcod.hashCode();
		hash = hash * prime + this.wrkare.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}