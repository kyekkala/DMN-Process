package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the WKO_TYP database table.
 * 
 */
@Entity
@Table(name="WKO_TYP")
@NamedQuery(name="WkoTyp.findAll", query="SELECT w FROM WkoTyp w")
public class WkoTyp implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private WkoTypPK id;

	@Column(name="BULK_PCK_FLG")
	private BigDecimal bulkPckFlg;

	@Column(name="DISASS_FLG")
	private BigDecimal disassFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private String prcare;

	private String prdlin;

	public WkoTyp() {
	}

	public WkoTypPK getId() {
		return this.id;
	}

	public void setId(WkoTypPK id) {
		this.id = id;
	}

	public BigDecimal getBulkPckFlg() {
		return this.bulkPckFlg;
	}

	public void setBulkPckFlg(BigDecimal bulkPckFlg) {
		this.bulkPckFlg = bulkPckFlg;
	}

	public BigDecimal getDisassFlg() {
		return this.disassFlg;
	}

	public void setDisassFlg(BigDecimal disassFlg) {
		this.disassFlg = disassFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getPrcare() {
		return this.prcare;
	}

	public void setPrcare(String prcare) {
		this.prcare = prcare;
	}

	public String getPrdlin() {
		return this.prdlin;
	}

	public void setPrdlin(String prdlin) {
		this.prdlin = prdlin;
	}

}