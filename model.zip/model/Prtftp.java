package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PRTFTP database table.
 * 
 */
@Entity
@NamedQuery(name="Prtftp.findAll", query="SELECT p FROM Prtftp p")
public class Prtftp implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PrtftpPK id;

	private BigDecimal caslvl;

	@Column(name="DEF_ASSET_TYP")
	private String defAssetTyp;

	@Column(name="DEFFTP_FLG")
	private BigDecimal defftpFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LEVEL_UNITS")
	private BigDecimal levelUnits;

	@Column(name="LOAD_ATTR1_CFG")
	private String loadAttr1Cfg;

	@Column(name="LOAD_ATTR2_CFG")
	private String loadAttr2Cfg;

	@Column(name="LOAD_ATTR3_CFG")
	private String loadAttr3Cfg;

	@Column(name="LOAD_ATTR4_CFG")
	private String loadAttr4Cfg;

	@Column(name="LOAD_ATTR5_CFG")
	private String loadAttr5Cfg;

	private BigDecimal nsthgt;

	private BigDecimal nstlen;

	private BigDecimal nstwid;

	@Column(name="PAL_STCK_HGT")
	private BigDecimal palStckHgt;

	@Column(name="RCVFTP_FLG")
	private BigDecimal rcvftpFlg;

	private String stkmtd;

	public Prtftp() {
	}

	public PrtftpPK getId() {
		return this.id;
	}

	public void setId(PrtftpPK id) {
		this.id = id;
	}

	public BigDecimal getCaslvl() {
		return this.caslvl;
	}

	public void setCaslvl(BigDecimal caslvl) {
		this.caslvl = caslvl;
	}

	public String getDefAssetTyp() {
		return this.defAssetTyp;
	}

	public void setDefAssetTyp(String defAssetTyp) {
		this.defAssetTyp = defAssetTyp;
	}

	public BigDecimal getDefftpFlg() {
		return this.defftpFlg;
	}

	public void setDefftpFlg(BigDecimal defftpFlg) {
		this.defftpFlg = defftpFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getLevelUnits() {
		return this.levelUnits;
	}

	public void setLevelUnits(BigDecimal levelUnits) {
		this.levelUnits = levelUnits;
	}

	public String getLoadAttr1Cfg() {
		return this.loadAttr1Cfg;
	}

	public void setLoadAttr1Cfg(String loadAttr1Cfg) {
		this.loadAttr1Cfg = loadAttr1Cfg;
	}

	public String getLoadAttr2Cfg() {
		return this.loadAttr2Cfg;
	}

	public void setLoadAttr2Cfg(String loadAttr2Cfg) {
		this.loadAttr2Cfg = loadAttr2Cfg;
	}

	public String getLoadAttr3Cfg() {
		return this.loadAttr3Cfg;
	}

	public void setLoadAttr3Cfg(String loadAttr3Cfg) {
		this.loadAttr3Cfg = loadAttr3Cfg;
	}

	public String getLoadAttr4Cfg() {
		return this.loadAttr4Cfg;
	}

	public void setLoadAttr4Cfg(String loadAttr4Cfg) {
		this.loadAttr4Cfg = loadAttr4Cfg;
	}

	public String getLoadAttr5Cfg() {
		return this.loadAttr5Cfg;
	}

	public void setLoadAttr5Cfg(String loadAttr5Cfg) {
		this.loadAttr5Cfg = loadAttr5Cfg;
	}

	public BigDecimal getNsthgt() {
		return this.nsthgt;
	}

	public void setNsthgt(BigDecimal nsthgt) {
		this.nsthgt = nsthgt;
	}

	public BigDecimal getNstlen() {
		return this.nstlen;
	}

	public void setNstlen(BigDecimal nstlen) {
		this.nstlen = nstlen;
	}

	public BigDecimal getNstwid() {
		return this.nstwid;
	}

	public void setNstwid(BigDecimal nstwid) {
		this.nstwid = nstwid;
	}

	public BigDecimal getPalStckHgt() {
		return this.palStckHgt;
	}

	public void setPalStckHgt(BigDecimal palStckHgt) {
		this.palStckHgt = palStckHgt;
	}

	public BigDecimal getRcvftpFlg() {
		return this.rcvftpFlg;
	}

	public void setRcvftpFlg(BigDecimal rcvftpFlg) {
		this.rcvftpFlg = rcvftpFlg;
	}

	public String getStkmtd() {
		return this.stkmtd;
	}

	public void setStkmtd(String stkmtd) {
		this.stkmtd = stkmtd;
	}

}