package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the INB_DOCK_CFG database table.
 * 
 */
@Embeddable
public class InbDockCfgPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="INB_DOCK_ID")
	private long inbDockId;

	@Column(name="WH_ID")
	private String whId;

	@Column(name="BLDG_ID")
	private String bldgId;

	public InbDockCfgPK() {
	}
	public long getInbDockId() {
		return this.inbDockId;
	}
	public void setInbDockId(long inbDockId) {
		this.inbDockId = inbDockId;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getBldgId() {
		return this.bldgId;
	}
	public void setBldgId(String bldgId) {
		this.bldgId = bldgId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof InbDockCfgPK)) {
			return false;
		}
		InbDockCfgPK castOther = (InbDockCfgPK)other;
		return 
			(this.inbDockId == castOther.inbDockId)
			&& this.whId.equals(castOther.whId)
			&& this.bldgId.equals(castOther.bldgId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.inbDockId ^ (this.inbDockId >>> 32)));
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.bldgId.hashCode();
		
		return hash;
	}
}