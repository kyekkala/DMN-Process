package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the SUPMST database table.
 * 
 */
@Embeddable
public class SupmstPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String supnum;

	@Column(name="CLIENT_ID")
	private String clientId;

	public SupmstPK() {
	}
	public String getSupnum() {
		return this.supnum;
	}
	public void setSupnum(String supnum) {
		this.supnum = supnum;
	}
	public String getClientId() {
		return this.clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SupmstPK)) {
			return false;
		}
		SupmstPK castOther = (SupmstPK)other;
		return 
			this.supnum.equals(castOther.supnum)
			&& this.clientId.equals(castOther.clientId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.supnum.hashCode();
		hash = hash * prime + this.clientId.hashCode();
		
		return hash;
	}
}