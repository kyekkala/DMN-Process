package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LVL_TYP database table.
 * 
 */
@Entity
@Table(name="LVL_TYP")
@NamedQuery(name="LvlTyp.findAll", query="SELECT l FROM LvlTyp l")
public class LvlTyp implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private LvlTypPK id;

	@Column(name="DSP_PND_IND_FLG")
	private BigDecimal dspPndIndFlg;

	@Column(name="HRZ_ALIGN_FLG")
	private BigDecimal hrzAlignFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LVL_TYP_DSC")
	private String lvlTypDsc;

	@Column(name="LVL_TYPE_NAME")
	private String lvlTypeName;

	private BigDecimal maxwgt;

	@Column(name="TOT_LVL_UNITS")
	private BigDecimal totLvlUnits;

	@Column(name="VRT_ALIGN_FLG")
	private BigDecimal vrtAlignFlg;

	public LvlTyp() {
	}

	public LvlTypPK getId() {
		return this.id;
	}

	public void setId(LvlTypPK id) {
		this.id = id;
	}

	public BigDecimal getDspPndIndFlg() {
		return this.dspPndIndFlg;
	}

	public void setDspPndIndFlg(BigDecimal dspPndIndFlg) {
		this.dspPndIndFlg = dspPndIndFlg;
	}

	public BigDecimal getHrzAlignFlg() {
		return this.hrzAlignFlg;
	}

	public void setHrzAlignFlg(BigDecimal hrzAlignFlg) {
		this.hrzAlignFlg = hrzAlignFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getLvlTypDsc() {
		return this.lvlTypDsc;
	}

	public void setLvlTypDsc(String lvlTypDsc) {
		this.lvlTypDsc = lvlTypDsc;
	}

	public String getLvlTypeName() {
		return this.lvlTypeName;
	}

	public void setLvlTypeName(String lvlTypeName) {
		this.lvlTypeName = lvlTypeName;
	}

	public BigDecimal getMaxwgt() {
		return this.maxwgt;
	}

	public void setMaxwgt(BigDecimal maxwgt) {
		this.maxwgt = maxwgt;
	}

	public BigDecimal getTotLvlUnits() {
		return this.totLvlUnits;
	}

	public void setTotLvlUnits(BigDecimal totLvlUnits) {
		this.totLvlUnits = totLvlUnits;
	}

	public BigDecimal getVrtAlignFlg() {
		return this.vrtAlignFlg;
	}

	public void setVrtAlignFlg(BigDecimal vrtAlignFlg) {
		this.vrtAlignFlg = vrtAlignFlg;
	}

}