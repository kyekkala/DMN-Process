package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the PCK_BLDG_SEQ database table.
 * 
 */
@Entity
@Table(name="PCK_BLDG_SEQ")
@NamedQuery(name="PckBldgSeq.findAll", query="SELECT p FROM PckBldgSeq p")
public class PckBldgSeq implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PckBldgSeqPK id;

	private BigDecimal srtseq;

	public PckBldgSeq() {
	}

	public PckBldgSeqPK getId() {
		return this.id;
	}

	public void setId(PckBldgSeqPK id) {
		this.id = id;
	}

	public BigDecimal getSrtseq() {
		return this.srtseq;
	}

	public void setSrtseq(BigDecimal srtseq) {
		this.srtseq = srtseq;
	}

}