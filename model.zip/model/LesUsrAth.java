package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LES_USR_ATH database table.
 * 
 */
@Entity
@Table(name="LES_USR_ATH")
@NamedQuery(name="LesUsrAth.findAll", query="SELECT l FROM LesUsrAth l")
public class LesUsrAth implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="USR_ID")
	private String usrId;

	@Temporal(TemporalType.DATE)
	@Column(name="ACCT_EXPIR_DAT")
	private Date acctExpirDat;

	@Column(name="ADJ_THR_CST")
	private BigDecimal adjThrCst;

	@Column(name="ADJ_THR_UNIT")
	private BigDecimal adjThrUnit;

	@Column(name="ADR_ID")
	private String adrId;

	@Column(name="ATH_GRP_NAM")
	private String athGrpNam;

	@Column(name="BA_USER_ID")
	private String baUserId;

	@Column(name="CLIENT_ID")
	private String clientId;

	@Column(name="CNTBCK_ENA_COD")
	private String cntbckEnaCod;

	@Column(name="DIFFERENTIAL_FLG")
	private BigDecimal differentialFlg;

	@Column(name="EXT_ATH_FLG")
	private BigDecimal extAthFlg;

	@Column(name="GRP_NAM")
	private String grpNam;

	@Column(name="INCENTIVE_FLG")
	private BigDecimal incentiveFlg;

	@Column(name="INTRUDER_CNT")
	private BigDecimal intruderCnt;

	@Temporal(TemporalType.DATE)
	private Date lmsdte;

	@Column(name="LOCALE_ID")
	private String localeId;

	@Column(name="LOGIN_ID")
	private String loginId;

	@Temporal(TemporalType.DATE)
	@Column(name="LST_DAT")
	private Date lstDat;

	@Temporal(TemporalType.DATE)
	@Column(name="LST_LOGOUT_DTE")
	private Date lstLogoutDte;

	@Column(name="MC_EMS_FWD_USR_ID")
	private String mcEmsFwdUsrId;

	@Column(name="MC_EMS_GMT_NUM")
	private BigDecimal mcEmsGmtNum;

	@Column(name="MC_EMS_USR_OFF_CFG")
	private BigDecimal mcEmsUsrOffCfg;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="OIDC_SUBJECT")
	private String oidcSubject;

	@Column(name="PAYROLL_FLG")
	private BigDecimal payrollFlg;

	@Column(name="PIN_NUM")
	private String pinNum;

	@Temporal(TemporalType.DATE)
	@Column(name="PSWD_CHG_DAT")
	private Date pswdChgDat;

	@Column(name="PSWD_CHG_FLG")
	private BigDecimal pswdChgFlg;

	@Column(name="PSWD_EXPIR_FLG")
	private BigDecimal pswdExpirFlg;

	@Column(name="SINGLE_SIGNON_FLG")
	private BigDecimal singleSignonFlg;

	@Column(name="SUPER_USR_FLG")
	private BigDecimal superUsrFlg;

	@Column(name="UNMEASURED_FLG")
	private BigDecimal unmeasuredFlg;

	@Column(name="USR_PSWD")
	private String usrPswd;

	@Column(name="USR_STS")
	private String usrSts;

	@Column(name="VOC_PIN")
	private String vocPin;

	public LesUsrAth() {
	}

	public String getUsrId() {
		return this.usrId;
	}

	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}

	public Date getAcctExpirDat() {
		return this.acctExpirDat;
	}

	public void setAcctExpirDat(Date acctExpirDat) {
		this.acctExpirDat = acctExpirDat;
	}

	public BigDecimal getAdjThrCst() {
		return this.adjThrCst;
	}

	public void setAdjThrCst(BigDecimal adjThrCst) {
		this.adjThrCst = adjThrCst;
	}

	public BigDecimal getAdjThrUnit() {
		return this.adjThrUnit;
	}

	public void setAdjThrUnit(BigDecimal adjThrUnit) {
		this.adjThrUnit = adjThrUnit;
	}

	public String getAdrId() {
		return this.adrId;
	}

	public void setAdrId(String adrId) {
		this.adrId = adrId;
	}

	public String getAthGrpNam() {
		return this.athGrpNam;
	}

	public void setAthGrpNam(String athGrpNam) {
		this.athGrpNam = athGrpNam;
	}

	public String getBaUserId() {
		return this.baUserId;
	}

	public void setBaUserId(String baUserId) {
		this.baUserId = baUserId;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getCntbckEnaCod() {
		return this.cntbckEnaCod;
	}

	public void setCntbckEnaCod(String cntbckEnaCod) {
		this.cntbckEnaCod = cntbckEnaCod;
	}

	public BigDecimal getDifferentialFlg() {
		return this.differentialFlg;
	}

	public void setDifferentialFlg(BigDecimal differentialFlg) {
		this.differentialFlg = differentialFlg;
	}

	public BigDecimal getExtAthFlg() {
		return this.extAthFlg;
	}

	public void setExtAthFlg(BigDecimal extAthFlg) {
		this.extAthFlg = extAthFlg;
	}

	public String getGrpNam() {
		return this.grpNam;
	}

	public void setGrpNam(String grpNam) {
		this.grpNam = grpNam;
	}

	public BigDecimal getIncentiveFlg() {
		return this.incentiveFlg;
	}

	public void setIncentiveFlg(BigDecimal incentiveFlg) {
		this.incentiveFlg = incentiveFlg;
	}

	public BigDecimal getIntruderCnt() {
		return this.intruderCnt;
	}

	public void setIntruderCnt(BigDecimal intruderCnt) {
		this.intruderCnt = intruderCnt;
	}

	public Date getLmsdte() {
		return this.lmsdte;
	}

	public void setLmsdte(Date lmsdte) {
		this.lmsdte = lmsdte;
	}

	public String getLocaleId() {
		return this.localeId;
	}

	public void setLocaleId(String localeId) {
		this.localeId = localeId;
	}

	public String getLoginId() {
		return this.loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public Date getLstDat() {
		return this.lstDat;
	}

	public void setLstDat(Date lstDat) {
		this.lstDat = lstDat;
	}

	public Date getLstLogoutDte() {
		return this.lstLogoutDte;
	}

	public void setLstLogoutDte(Date lstLogoutDte) {
		this.lstLogoutDte = lstLogoutDte;
	}

	public String getMcEmsFwdUsrId() {
		return this.mcEmsFwdUsrId;
	}

	public void setMcEmsFwdUsrId(String mcEmsFwdUsrId) {
		this.mcEmsFwdUsrId = mcEmsFwdUsrId;
	}

	public BigDecimal getMcEmsGmtNum() {
		return this.mcEmsGmtNum;
	}

	public void setMcEmsGmtNum(BigDecimal mcEmsGmtNum) {
		this.mcEmsGmtNum = mcEmsGmtNum;
	}

	public BigDecimal getMcEmsUsrOffCfg() {
		return this.mcEmsUsrOffCfg;
	}

	public void setMcEmsUsrOffCfg(BigDecimal mcEmsUsrOffCfg) {
		this.mcEmsUsrOffCfg = mcEmsUsrOffCfg;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getOidcSubject() {
		return this.oidcSubject;
	}

	public void setOidcSubject(String oidcSubject) {
		this.oidcSubject = oidcSubject;
	}

	public BigDecimal getPayrollFlg() {
		return this.payrollFlg;
	}

	public void setPayrollFlg(BigDecimal payrollFlg) {
		this.payrollFlg = payrollFlg;
	}

	public String getPinNum() {
		return this.pinNum;
	}

	public void setPinNum(String pinNum) {
		this.pinNum = pinNum;
	}

	public Date getPswdChgDat() {
		return this.pswdChgDat;
	}

	public void setPswdChgDat(Date pswdChgDat) {
		this.pswdChgDat = pswdChgDat;
	}

	public BigDecimal getPswdChgFlg() {
		return this.pswdChgFlg;
	}

	public void setPswdChgFlg(BigDecimal pswdChgFlg) {
		this.pswdChgFlg = pswdChgFlg;
	}

	public BigDecimal getPswdExpirFlg() {
		return this.pswdExpirFlg;
	}

	public void setPswdExpirFlg(BigDecimal pswdExpirFlg) {
		this.pswdExpirFlg = pswdExpirFlg;
	}

	public BigDecimal getSingleSignonFlg() {
		return this.singleSignonFlg;
	}

	public void setSingleSignonFlg(BigDecimal singleSignonFlg) {
		this.singleSignonFlg = singleSignonFlg;
	}

	public BigDecimal getSuperUsrFlg() {
		return this.superUsrFlg;
	}

	public void setSuperUsrFlg(BigDecimal superUsrFlg) {
		this.superUsrFlg = superUsrFlg;
	}

	public BigDecimal getUnmeasuredFlg() {
		return this.unmeasuredFlg;
	}

	public void setUnmeasuredFlg(BigDecimal unmeasuredFlg) {
		this.unmeasuredFlg = unmeasuredFlg;
	}

	public String getUsrPswd() {
		return this.usrPswd;
	}

	public void setUsrPswd(String usrPswd) {
		this.usrPswd = usrPswd;
	}

	public String getUsrSts() {
		return this.usrSts;
	}

	public void setUsrSts(String usrSts) {
		this.usrSts = usrSts;
	}

	public String getVocPin() {
		return this.vocPin;
	}

	public void setVocPin(String vocPin) {
		this.vocPin = vocPin;
	}

}