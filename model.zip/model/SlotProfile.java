package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SLOT_PROFILE database table.
 * 
 */
@Entity
@Table(name="SLOT_PROFILE")
@NamedQuery(name="SlotProfile.findAll", query="SELECT s FROM SlotProfile s")
public class SlotProfile implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SlotProfilePK id;

	@Column(name="BRK_ON_FAIL_FLG")
	private BigDecimal brkOnFailFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="CTRL_DT")
	private Date ctrlDt;

	@Column(name="CTRL_USER_ID")
	private String ctrlUserId;

	@Column(name="CURRENT_FLG")
	private BigDecimal currentFlg;

	@Column(name="DEMAND_DRIVEN_FLG")
	private BigDecimal demandDrivenFlg;

	@Column(name="EJECTED_FLG")
	private BigDecimal ejectedFlg;

	@Column(name="GROWTH_FACTOR")
	private BigDecimal growthFactor;

	@Column(name="LOC_RULE")
	private String locRule;

	@Column(name="MAX_LOCS_PER_ITEM")
	private BigDecimal maxLocsPerItem;

	@Column(name="MAX_TURNS_PER_LOC")
	private BigDecimal maxTurnsPerLoc;

	@Column(name="SLOT_MODE")
	private String slotMode;

	private BigDecimal srtseq;

	@Column(name="UNSLOTTED_FLG")
	private BigDecimal unslottedFlg;

	@Column(name="WGT_CHK_FLG")
	private BigDecimal wgtChkFlg;

	public SlotProfile() {
	}

	public SlotProfilePK getId() {
		return this.id;
	}

	public void setId(SlotProfilePK id) {
		this.id = id;
	}

	public BigDecimal getBrkOnFailFlg() {
		return this.brkOnFailFlg;
	}

	public void setBrkOnFailFlg(BigDecimal brkOnFailFlg) {
		this.brkOnFailFlg = brkOnFailFlg;
	}

	public Date getCtrlDt() {
		return this.ctrlDt;
	}

	public void setCtrlDt(Date ctrlDt) {
		this.ctrlDt = ctrlDt;
	}

	public String getCtrlUserId() {
		return this.ctrlUserId;
	}

	public void setCtrlUserId(String ctrlUserId) {
		this.ctrlUserId = ctrlUserId;
	}

	public BigDecimal getCurrentFlg() {
		return this.currentFlg;
	}

	public void setCurrentFlg(BigDecimal currentFlg) {
		this.currentFlg = currentFlg;
	}

	public BigDecimal getDemandDrivenFlg() {
		return this.demandDrivenFlg;
	}

	public void setDemandDrivenFlg(BigDecimal demandDrivenFlg) {
		this.demandDrivenFlg = demandDrivenFlg;
	}

	public BigDecimal getEjectedFlg() {
		return this.ejectedFlg;
	}

	public void setEjectedFlg(BigDecimal ejectedFlg) {
		this.ejectedFlg = ejectedFlg;
	}

	public BigDecimal getGrowthFactor() {
		return this.growthFactor;
	}

	public void setGrowthFactor(BigDecimal growthFactor) {
		this.growthFactor = growthFactor;
	}

	public String getLocRule() {
		return this.locRule;
	}

	public void setLocRule(String locRule) {
		this.locRule = locRule;
	}

	public BigDecimal getMaxLocsPerItem() {
		return this.maxLocsPerItem;
	}

	public void setMaxLocsPerItem(BigDecimal maxLocsPerItem) {
		this.maxLocsPerItem = maxLocsPerItem;
	}

	public BigDecimal getMaxTurnsPerLoc() {
		return this.maxTurnsPerLoc;
	}

	public void setMaxTurnsPerLoc(BigDecimal maxTurnsPerLoc) {
		this.maxTurnsPerLoc = maxTurnsPerLoc;
	}

	public String getSlotMode() {
		return this.slotMode;
	}

	public void setSlotMode(String slotMode) {
		this.slotMode = slotMode;
	}

	public BigDecimal getSrtseq() {
		return this.srtseq;
	}

	public void setSrtseq(BigDecimal srtseq) {
		this.srtseq = srtseq;
	}

	public BigDecimal getUnslottedFlg() {
		return this.unslottedFlg;
	}

	public void setUnslottedFlg(BigDecimal unslottedFlg) {
		this.unslottedFlg = unslottedFlg;
	}

	public BigDecimal getWgtChkFlg() {
		return this.wgtChkFlg;
	}

	public void setWgtChkFlg(BigDecimal wgtChkFlg) {
		this.wgtChkFlg = wgtChkFlg;
	}

}