package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the BLDG_INVMIX_RULE database table.
 * 
 */
@Entity
@Table(name="BLDG_INVMIX_RULE")
@NamedQuery(name="BldgInvmixRule.findAll", query="SELECT b FROM BldgInvmixRule b")
public class BldgInvmixRule implements Serializable {
	private static final long serialVersionUID = 1L;

	public BldgInvmixRule() {
	}

}