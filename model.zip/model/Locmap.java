package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LOCMAP database table.
 * 
 */
@Entity
@NamedQuery(name="Locmap.findAll", query="SELECT l FROM Locmap l")
public class Locmap implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private LocmapPK id;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private BigDecimal locflg;

	private BigDecimal loclvl;

	private BigDecimal poshgt;

	private BigDecimal poslft;

	private BigDecimal postop;

	private BigDecimal poswid;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	public Locmap() {
	}

	public LocmapPK getId() {
		return this.id;
	}

	public void setId(LocmapPK id) {
		this.id = id;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getLocflg() {
		return this.locflg;
	}

	public void setLocflg(BigDecimal locflg) {
		this.locflg = locflg;
	}

	public BigDecimal getLoclvl() {
		return this.loclvl;
	}

	public void setLoclvl(BigDecimal loclvl) {
		this.loclvl = loclvl;
	}

	public BigDecimal getPoshgt() {
		return this.poshgt;
	}

	public void setPoshgt(BigDecimal poshgt) {
		this.poshgt = poshgt;
	}

	public BigDecimal getPoslft() {
		return this.poslft;
	}

	public void setPoslft(BigDecimal poslft) {
		this.poslft = poslft;
	}

	public BigDecimal getPostop() {
		return this.postop;
	}

	public void setPostop(BigDecimal postop) {
		this.postop = postop;
	}

	public BigDecimal getPoswid() {
		return this.poswid;
	}

	public void setPoswid(BigDecimal poswid) {
		this.poswid = poswid;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

}