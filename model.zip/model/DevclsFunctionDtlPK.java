package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the DEVCLS_FUNCTION_DTL database table.
 * 
 */
@Embeddable
public class DevclsFunctionDtlPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String devcls;

	@Column(name="DEV_FUNCTION")
	private long devFunction;

	private String oprcod;

	@Column(name="WH_ID")
	private String whId;

	public DevclsFunctionDtlPK() {
	}
	public String getDevcls() {
		return this.devcls;
	}
	public void setDevcls(String devcls) {
		this.devcls = devcls;
	}
	public long getDevFunction() {
		return this.devFunction;
	}
	public void setDevFunction(long devFunction) {
		this.devFunction = devFunction;
	}
	public String getOprcod() {
		return this.oprcod;
	}
	public void setOprcod(String oprcod) {
		this.oprcod = oprcod;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof DevclsFunctionDtlPK)) {
			return false;
		}
		DevclsFunctionDtlPK castOther = (DevclsFunctionDtlPK)other;
		return 
			this.devcls.equals(castOther.devcls)
			&& (this.devFunction == castOther.devFunction)
			&& this.oprcod.equals(castOther.oprcod)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.devcls.hashCode();
		hash = hash * prime + ((int) (this.devFunction ^ (this.devFunction >>> 32)));
		hash = hash * prime + this.oprcod.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}