package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the RES_FLTR_RULE database table.
 * 
 */
@Entity
@Table(name="RES_FLTR_RULE")
@NamedQuery(name="ResFltrRule.findAll", query="SELECT r FROM ResFltrRule r")
public class ResFltrRule implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ResFltrRulePK id;

	@Column(name="INCL_FLG")
	private BigDecimal inclFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	public ResFltrRule() {
	}

	public ResFltrRulePK getId() {
		return this.id;
	}

	public void setId(ResFltrRulePK id) {
		this.id = id;
	}

	public BigDecimal getInclFlg() {
		return this.inclFlg;
	}

	public void setInclFlg(BigDecimal inclFlg) {
		this.inclFlg = inclFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

}