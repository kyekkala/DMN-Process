package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SHIPMENT_LINE database table.
 * 
 */
@Entity
@Table(name="SHIPMENT_LINE")
@NamedQuery(name="ShipmentLine.findAll", query="SELECT s FROM ShipmentLine s")
public class ShipmentLine implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SHIP_LINE_ID")
	private String shipLineId;

	@Column(name="CLIENT_ID")
	private String clientId;

	@Column(name="CONS_BATCH")
	private String consBatch;

	@Column(name="DSTR_QTY")
	private BigDecimal dstrQty;

	private BigDecimal edtflg;

	@Column(name="EST_TIME")
	private BigDecimal estTime;

	private String ftpcod;

	private BigDecimal inloadqty;

	private BigDecimal inpqty;

	private BigDecimal instgqty;

	private String linsts;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private String ordlin;

	private String ordnum;

	private String ordsln;

	private BigDecimal oviqty;

	private BigDecimal ovramt;

	private String ovrcod;

	private String pckgr1;

	private String pckgr2;

	private String pckgr3;

	private String pckgr4;

	private BigDecimal pckqty;

	@Column(name="PICKED_QTY")
	private BigDecimal pickedQty;

	private String prcpri;

	@Column(name="PRT_CLIENT_ID")
	private String prtClientId;

	private String prtnum;

	@Column(name="REL_VAL")
	private BigDecimal relVal;

	@Column(name="REL_VAL_UNT_TYP")
	private String relValUntTyp;

	private String schbat;

	@Column(name="SHIP_ID")
	private String shipId;

	private BigDecimal shpqty;

	private String shpwth;

	private BigDecimal stgqty;

	@Column(name="TMS_LOAD_ID")
	private String tmsLoadId;

	@Column(name="TMS_SHIP_ID")
	private String tmsShipId;

	@Column(name="TMS_SHIP_LINE_ID")
	private String tmsShipLineId;

	@Column(name="TOT_PLN_CAS_QTY")
	private BigDecimal totPlnCasQty;

	@Column(name="TOT_PLN_CUBE")
	private BigDecimal totPlnCube;

	@Column(name="TOT_PLN_MISC_QTY")
	private BigDecimal totPlnMiscQty;

	@Column(name="TOT_PLN_MISC2_QTY")
	private BigDecimal totPlnMisc2Qty;

	@Column(name="TOT_PLN_PAL_QTY")
	private BigDecimal totPlnPalQty;

	@Column(name="TOT_PLN_QTY")
	private BigDecimal totPlnQty;

	@Column(name="TOT_PLN_WGT")
	private BigDecimal totPlnWgt;

	@Column(name="UNT_INS_VAL")
	private BigDecimal untInsVal;

	private BigDecimal untpal;

	@Column(name="WH_ID")
	private String whId;

	private String wkonum;

	private String wkorev;

	public ShipmentLine() {
	}

	public String getShipLineId() {
		return this.shipLineId;
	}

	public void setShipLineId(String shipLineId) {
		this.shipLineId = shipLineId;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getConsBatch() {
		return this.consBatch;
	}

	public void setConsBatch(String consBatch) {
		this.consBatch = consBatch;
	}

	public BigDecimal getDstrQty() {
		return this.dstrQty;
	}

	public void setDstrQty(BigDecimal dstrQty) {
		this.dstrQty = dstrQty;
	}

	public BigDecimal getEdtflg() {
		return this.edtflg;
	}

	public void setEdtflg(BigDecimal edtflg) {
		this.edtflg = edtflg;
	}

	public BigDecimal getEstTime() {
		return this.estTime;
	}

	public void setEstTime(BigDecimal estTime) {
		this.estTime = estTime;
	}

	public String getFtpcod() {
		return this.ftpcod;
	}

	public void setFtpcod(String ftpcod) {
		this.ftpcod = ftpcod;
	}

	public BigDecimal getInloadqty() {
		return this.inloadqty;
	}

	public void setInloadqty(BigDecimal inloadqty) {
		this.inloadqty = inloadqty;
	}

	public BigDecimal getInpqty() {
		return this.inpqty;
	}

	public void setInpqty(BigDecimal inpqty) {
		this.inpqty = inpqty;
	}

	public BigDecimal getInstgqty() {
		return this.instgqty;
	}

	public void setInstgqty(BigDecimal instgqty) {
		this.instgqty = instgqty;
	}

	public String getLinsts() {
		return this.linsts;
	}

	public void setLinsts(String linsts) {
		this.linsts = linsts;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getOrdlin() {
		return this.ordlin;
	}

	public void setOrdlin(String ordlin) {
		this.ordlin = ordlin;
	}

	public String getOrdnum() {
		return this.ordnum;
	}

	public void setOrdnum(String ordnum) {
		this.ordnum = ordnum;
	}

	public String getOrdsln() {
		return this.ordsln;
	}

	public void setOrdsln(String ordsln) {
		this.ordsln = ordsln;
	}

	public BigDecimal getOviqty() {
		return this.oviqty;
	}

	public void setOviqty(BigDecimal oviqty) {
		this.oviqty = oviqty;
	}

	public BigDecimal getOvramt() {
		return this.ovramt;
	}

	public void setOvramt(BigDecimal ovramt) {
		this.ovramt = ovramt;
	}

	public String getOvrcod() {
		return this.ovrcod;
	}

	public void setOvrcod(String ovrcod) {
		this.ovrcod = ovrcod;
	}

	public String getPckgr1() {
		return this.pckgr1;
	}

	public void setPckgr1(String pckgr1) {
		this.pckgr1 = pckgr1;
	}

	public String getPckgr2() {
		return this.pckgr2;
	}

	public void setPckgr2(String pckgr2) {
		this.pckgr2 = pckgr2;
	}

	public String getPckgr3() {
		return this.pckgr3;
	}

	public void setPckgr3(String pckgr3) {
		this.pckgr3 = pckgr3;
	}

	public String getPckgr4() {
		return this.pckgr4;
	}

	public void setPckgr4(String pckgr4) {
		this.pckgr4 = pckgr4;
	}

	public BigDecimal getPckqty() {
		return this.pckqty;
	}

	public void setPckqty(BigDecimal pckqty) {
		this.pckqty = pckqty;
	}

	public BigDecimal getPickedQty() {
		return this.pickedQty;
	}

	public void setPickedQty(BigDecimal pickedQty) {
		this.pickedQty = pickedQty;
	}

	public String getPrcpri() {
		return this.prcpri;
	}

	public void setPrcpri(String prcpri) {
		this.prcpri = prcpri;
	}

	public String getPrtClientId() {
		return this.prtClientId;
	}

	public void setPrtClientId(String prtClientId) {
		this.prtClientId = prtClientId;
	}

	public String getPrtnum() {
		return this.prtnum;
	}

	public void setPrtnum(String prtnum) {
		this.prtnum = prtnum;
	}

	public BigDecimal getRelVal() {
		return this.relVal;
	}

	public void setRelVal(BigDecimal relVal) {
		this.relVal = relVal;
	}

	public String getRelValUntTyp() {
		return this.relValUntTyp;
	}

	public void setRelValUntTyp(String relValUntTyp) {
		this.relValUntTyp = relValUntTyp;
	}

	public String getSchbat() {
		return this.schbat;
	}

	public void setSchbat(String schbat) {
		this.schbat = schbat;
	}

	public String getShipId() {
		return this.shipId;
	}

	public void setShipId(String shipId) {
		this.shipId = shipId;
	}

	public BigDecimal getShpqty() {
		return this.shpqty;
	}

	public void setShpqty(BigDecimal shpqty) {
		this.shpqty = shpqty;
	}

	public String getShpwth() {
		return this.shpwth;
	}

	public void setShpwth(String shpwth) {
		this.shpwth = shpwth;
	}

	public BigDecimal getStgqty() {
		return this.stgqty;
	}

	public void setStgqty(BigDecimal stgqty) {
		this.stgqty = stgqty;
	}

	public String getTmsLoadId() {
		return this.tmsLoadId;
	}

	public void setTmsLoadId(String tmsLoadId) {
		this.tmsLoadId = tmsLoadId;
	}

	public String getTmsShipId() {
		return this.tmsShipId;
	}

	public void setTmsShipId(String tmsShipId) {
		this.tmsShipId = tmsShipId;
	}

	public String getTmsShipLineId() {
		return this.tmsShipLineId;
	}

	public void setTmsShipLineId(String tmsShipLineId) {
		this.tmsShipLineId = tmsShipLineId;
	}

	public BigDecimal getTotPlnCasQty() {
		return this.totPlnCasQty;
	}

	public void setTotPlnCasQty(BigDecimal totPlnCasQty) {
		this.totPlnCasQty = totPlnCasQty;
	}

	public BigDecimal getTotPlnCube() {
		return this.totPlnCube;
	}

	public void setTotPlnCube(BigDecimal totPlnCube) {
		this.totPlnCube = totPlnCube;
	}

	public BigDecimal getTotPlnMiscQty() {
		return this.totPlnMiscQty;
	}

	public void setTotPlnMiscQty(BigDecimal totPlnMiscQty) {
		this.totPlnMiscQty = totPlnMiscQty;
	}

	public BigDecimal getTotPlnMisc2Qty() {
		return this.totPlnMisc2Qty;
	}

	public void setTotPlnMisc2Qty(BigDecimal totPlnMisc2Qty) {
		this.totPlnMisc2Qty = totPlnMisc2Qty;
	}

	public BigDecimal getTotPlnPalQty() {
		return this.totPlnPalQty;
	}

	public void setTotPlnPalQty(BigDecimal totPlnPalQty) {
		this.totPlnPalQty = totPlnPalQty;
	}

	public BigDecimal getTotPlnQty() {
		return this.totPlnQty;
	}

	public void setTotPlnQty(BigDecimal totPlnQty) {
		this.totPlnQty = totPlnQty;
	}

	public BigDecimal getTotPlnWgt() {
		return this.totPlnWgt;
	}

	public void setTotPlnWgt(BigDecimal totPlnWgt) {
		this.totPlnWgt = totPlnWgt;
	}

	public BigDecimal getUntInsVal() {
		return this.untInsVal;
	}

	public void setUntInsVal(BigDecimal untInsVal) {
		this.untInsVal = untInsVal;
	}

	public BigDecimal getUntpal() {
		return this.untpal;
	}

	public void setUntpal(BigDecimal untpal) {
		this.untpal = untpal;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

	public String getWkonum() {
		return this.wkonum;
	}

	public void setWkonum(String wkonum) {
		this.wkonum = wkonum;
	}

	public String getWkorev() {
		return this.wkorev;
	}

	public void setWkorev(String wkorev) {
		this.wkorev = wkorev;
	}

}