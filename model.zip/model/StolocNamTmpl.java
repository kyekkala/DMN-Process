package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the STOLOC_NAM_TMPL database table.
 * 
 */
@Entity
@Table(name="STOLOC_NAM_TMPL")
@NamedQuery(name="StolocNamTmpl.findAll", query="SELECT s FROM StolocNamTmpl s")
public class StolocNamTmpl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="STOLOC_NAM_TMPL_ID")
	private long stolocNamTmplId;

	private String backfillnamstr;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private String namstr;

	@Column(name="WH_ID")
	private String whId;

	public StolocNamTmpl() {
	}

	public long getStolocNamTmplId() {
		return this.stolocNamTmplId;
	}

	public void setStolocNamTmplId(long stolocNamTmplId) {
		this.stolocNamTmplId = stolocNamTmplId;
	}

	public String getBackfillnamstr() {
		return this.backfillnamstr;
	}

	public void setBackfillnamstr(String backfillnamstr) {
		this.backfillnamstr = backfillnamstr;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getNamstr() {
		return this.namstr;
	}

	public void setNamstr(String namstr) {
		this.namstr = namstr;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}