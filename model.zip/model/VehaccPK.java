package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the VEHACC database table.
 * 
 */
@Embeddable
public class VehaccPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String vehtyp;

	private String locacc;

	public VehaccPK() {
	}
	public String getVehtyp() {
		return this.vehtyp;
	}
	public void setVehtyp(String vehtyp) {
		this.vehtyp = vehtyp;
	}
	public String getLocacc() {
		return this.locacc;
	}
	public void setLocacc(String locacc) {
		this.locacc = locacc;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof VehaccPK)) {
			return false;
		}
		VehaccPK castOther = (VehaccPK)other;
		return 
			this.vehtyp.equals(castOther.vehtyp)
			&& this.locacc.equals(castOther.locacc);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.vehtyp.hashCode();
		hash = hash * prime + this.locacc.hashCode();
		
		return hash;
	}
}