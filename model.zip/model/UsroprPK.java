package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the USROPR database table.
 * 
 */
@Embeddable
public class UsroprPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="USR_ID")
	private String usrId;

	private String oprcod;

	@Column(name="WH_ID")
	private String whId;

	public UsroprPK() {
	}
	public String getUsrId() {
		return this.usrId;
	}
	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}
	public String getOprcod() {
		return this.oprcod;
	}
	public void setOprcod(String oprcod) {
		this.oprcod = oprcod;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof UsroprPK)) {
			return false;
		}
		UsroprPK castOther = (UsroprPK)other;
		return 
			this.usrId.equals(castOther.usrId)
			&& this.oprcod.equals(castOther.oprcod)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.usrId.hashCode();
		hash = hash * prime + this.oprcod.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}