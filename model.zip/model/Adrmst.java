package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the ADRMST database table.
 * 
 */
@Entity
@NamedQuery(name="Adrmst.findAll", query="SELECT a FROM Adrmst a")
public class Adrmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ADR_ID")
	private String adrId;

	@Column(name="ADR_DISTRICT")
	private String adrDistrict;

	private String adrcty;

	private String adrln1;

	private String adrln2;

	private String adrln3;

	private String adrnam;

	private String adrpsz;

	private String adrstc;

	private String adrtyp;

	@Column(name="ATTN_NAME")
	private String attnName;

	@Column(name="ATTN_TEL")
	private String attnTel;

	@Column(name="CLIENT_ID")
	private String clientId;

	@Column(name="CONT_NAME")
	private String contName;

	@Column(name="CONT_TEL")
	private String contTel;

	@Column(name="CONT_TITLE")
	private String contTitle;

	@Column(name="CSTMS_SITE_TYP")
	private String cstmsSiteTyp;

	@Column(name="CSTMS_TX_SITE")
	private String cstmsTxSite;

	@Column(name="CTRY_NAME")
	private String ctryName;

	@Column(name="EMAIL_ADR")
	private String emailAdr;

	private String faxnum;

	@Column(name="FIRST_NAME")
	private String firstName;

	private String gln;

	@Column(name="GRP_NAM")
	private String grpNam;

	private String honorific;

	@Column(name="HOST_EXT_ID")
	private String hostExtId;

	@Column(name="LAST_NAME")
	private String lastName;

	private String latitude;

	@Column(name="LOCALE_ID")
	private String localeId;

	private String longitude;

	private String pagnum;

	private String phnnum;

	@Column(name="PO_BOX_FLG")
	private BigDecimal poBoxFlg;

	@Column(name="POOL_FLG")
	private BigDecimal poolFlg;

	@Column(name="POOL_RATE_SERV_NAM")
	private String poolRateServNam;

	private String rgncod;

	@Column(name="RQST_STATE_COD")
	private String rqstStateCod;

	private BigDecimal rsaflg;

	@Column(name="SHIP_ATTN_NAME")
	private String shipAttnName;

	@Column(name="SHIP_ATTN_PHNNUM")
	private String shipAttnPhnnum;

	@Column(name="SHIP_CONT_NAME")
	private String shipContName;

	@Column(name="SHIP_CONT_TEL")
	private String shipContTel;

	@Column(name="SHIP_CONT_TITLE")
	private String shipContTitle;

	@Column(name="SHIP_EMAIL_ADR")
	private String shipEmailAdr;

	@Column(name="SHIP_FAXNUM")
	private String shipFaxnum;

	@Column(name="SHIP_PHNNUM")
	private String shipPhnnum;

	@Column(name="SHIP_WEB_ADR")
	private String shipWebAdr;

	@Column(name="TEMP_FLG")
	private BigDecimal tempFlg;

	@Column(name="TIM_ZON_CD")
	private String timZonCd;

	@Column(name="USR_DSP")
	private String usrDsp;

	@Column(name="WEB_ADR")
	private String webAdr;

	public Adrmst() {
	}

	public String getAdrId() {
		return this.adrId;
	}

	public void setAdrId(String adrId) {
		this.adrId = adrId;
	}

	public String getAdrDistrict() {
		return this.adrDistrict;
	}

	public void setAdrDistrict(String adrDistrict) {
		this.adrDistrict = adrDistrict;
	}

	public String getAdrcty() {
		return this.adrcty;
	}

	public void setAdrcty(String adrcty) {
		this.adrcty = adrcty;
	}

	public String getAdrln1() {
		return this.adrln1;
	}

	public void setAdrln1(String adrln1) {
		this.adrln1 = adrln1;
	}

	public String getAdrln2() {
		return this.adrln2;
	}

	public void setAdrln2(String adrln2) {
		this.adrln2 = adrln2;
	}

	public String getAdrln3() {
		return this.adrln3;
	}

	public void setAdrln3(String adrln3) {
		this.adrln3 = adrln3;
	}

	public String getAdrnam() {
		return this.adrnam;
	}

	public void setAdrnam(String adrnam) {
		this.adrnam = adrnam;
	}

	public String getAdrpsz() {
		return this.adrpsz;
	}

	public void setAdrpsz(String adrpsz) {
		this.adrpsz = adrpsz;
	}

	public String getAdrstc() {
		return this.adrstc;
	}

	public void setAdrstc(String adrstc) {
		this.adrstc = adrstc;
	}

	public String getAdrtyp() {
		return this.adrtyp;
	}

	public void setAdrtyp(String adrtyp) {
		this.adrtyp = adrtyp;
	}

	public String getAttnName() {
		return this.attnName;
	}

	public void setAttnName(String attnName) {
		this.attnName = attnName;
	}

	public String getAttnTel() {
		return this.attnTel;
	}

	public void setAttnTel(String attnTel) {
		this.attnTel = attnTel;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getContName() {
		return this.contName;
	}

	public void setContName(String contName) {
		this.contName = contName;
	}

	public String getContTel() {
		return this.contTel;
	}

	public void setContTel(String contTel) {
		this.contTel = contTel;
	}

	public String getContTitle() {
		return this.contTitle;
	}

	public void setContTitle(String contTitle) {
		this.contTitle = contTitle;
	}

	public String getCstmsSiteTyp() {
		return this.cstmsSiteTyp;
	}

	public void setCstmsSiteTyp(String cstmsSiteTyp) {
		this.cstmsSiteTyp = cstmsSiteTyp;
	}

	public String getCstmsTxSite() {
		return this.cstmsTxSite;
	}

	public void setCstmsTxSite(String cstmsTxSite) {
		this.cstmsTxSite = cstmsTxSite;
	}

	public String getCtryName() {
		return this.ctryName;
	}

	public void setCtryName(String ctryName) {
		this.ctryName = ctryName;
	}

	public String getEmailAdr() {
		return this.emailAdr;
	}

	public void setEmailAdr(String emailAdr) {
		this.emailAdr = emailAdr;
	}

	public String getFaxnum() {
		return this.faxnum;
	}

	public void setFaxnum(String faxnum) {
		this.faxnum = faxnum;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGln() {
		return this.gln;
	}

	public void setGln(String gln) {
		this.gln = gln;
	}

	public String getGrpNam() {
		return this.grpNam;
	}

	public void setGrpNam(String grpNam) {
		this.grpNam = grpNam;
	}

	public String getHonorific() {
		return this.honorific;
	}

	public void setHonorific(String honorific) {
		this.honorific = honorific;
	}

	public String getHostExtId() {
		return this.hostExtId;
	}

	public void setHostExtId(String hostExtId) {
		this.hostExtId = hostExtId;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLatitude() {
		return this.latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLocaleId() {
		return this.localeId;
	}

	public void setLocaleId(String localeId) {
		this.localeId = localeId;
	}

	public String getLongitude() {
		return this.longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getPagnum() {
		return this.pagnum;
	}

	public void setPagnum(String pagnum) {
		this.pagnum = pagnum;
	}

	public String getPhnnum() {
		return this.phnnum;
	}

	public void setPhnnum(String phnnum) {
		this.phnnum = phnnum;
	}

	public BigDecimal getPoBoxFlg() {
		return this.poBoxFlg;
	}

	public void setPoBoxFlg(BigDecimal poBoxFlg) {
		this.poBoxFlg = poBoxFlg;
	}

	public BigDecimal getPoolFlg() {
		return this.poolFlg;
	}

	public void setPoolFlg(BigDecimal poolFlg) {
		this.poolFlg = poolFlg;
	}

	public String getPoolRateServNam() {
		return this.poolRateServNam;
	}

	public void setPoolRateServNam(String poolRateServNam) {
		this.poolRateServNam = poolRateServNam;
	}

	public String getRgncod() {
		return this.rgncod;
	}

	public void setRgncod(String rgncod) {
		this.rgncod = rgncod;
	}

	public String getRqstStateCod() {
		return this.rqstStateCod;
	}

	public void setRqstStateCod(String rqstStateCod) {
		this.rqstStateCod = rqstStateCod;
	}

	public BigDecimal getRsaflg() {
		return this.rsaflg;
	}

	public void setRsaflg(BigDecimal rsaflg) {
		this.rsaflg = rsaflg;
	}

	public String getShipAttnName() {
		return this.shipAttnName;
	}

	public void setShipAttnName(String shipAttnName) {
		this.shipAttnName = shipAttnName;
	}

	public String getShipAttnPhnnum() {
		return this.shipAttnPhnnum;
	}

	public void setShipAttnPhnnum(String shipAttnPhnnum) {
		this.shipAttnPhnnum = shipAttnPhnnum;
	}

	public String getShipContName() {
		return this.shipContName;
	}

	public void setShipContName(String shipContName) {
		this.shipContName = shipContName;
	}

	public String getShipContTel() {
		return this.shipContTel;
	}

	public void setShipContTel(String shipContTel) {
		this.shipContTel = shipContTel;
	}

	public String getShipContTitle() {
		return this.shipContTitle;
	}

	public void setShipContTitle(String shipContTitle) {
		this.shipContTitle = shipContTitle;
	}

	public String getShipEmailAdr() {
		return this.shipEmailAdr;
	}

	public void setShipEmailAdr(String shipEmailAdr) {
		this.shipEmailAdr = shipEmailAdr;
	}

	public String getShipFaxnum() {
		return this.shipFaxnum;
	}

	public void setShipFaxnum(String shipFaxnum) {
		this.shipFaxnum = shipFaxnum;
	}

	public String getShipPhnnum() {
		return this.shipPhnnum;
	}

	public void setShipPhnnum(String shipPhnnum) {
		this.shipPhnnum = shipPhnnum;
	}

	public String getShipWebAdr() {
		return this.shipWebAdr;
	}

	public void setShipWebAdr(String shipWebAdr) {
		this.shipWebAdr = shipWebAdr;
	}

	public BigDecimal getTempFlg() {
		return this.tempFlg;
	}

	public void setTempFlg(BigDecimal tempFlg) {
		this.tempFlg = tempFlg;
	}

	public String getTimZonCd() {
		return this.timZonCd;
	}

	public void setTimZonCd(String timZonCd) {
		this.timZonCd = timZonCd;
	}

	public String getUsrDsp() {
		return this.usrDsp;
	}

	public void setUsrDsp(String usrDsp) {
		this.usrDsp = usrDsp;
	}

	public String getWebAdr() {
		return this.webAdr;
	}

	public void setWebAdr(String webAdr) {
		this.webAdr = webAdr;
	}

}