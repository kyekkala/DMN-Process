package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the INVLOD database table.
 * 
 */
@Entity
@NamedQuery(name="Invlod.findAll", query="SELECT i FROM Invlod i")
public class Invlod implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String lodnum;

	@Temporal(TemporalType.DATE)
	private Date adddte;

	@Column(name="ASSET_TYP")
	private String assetTyp;

	@Column(name="AVG_UNT_CATCH_QTY")
	private BigDecimal avgUntCatchQty;

	@Column(name="BUNDLED_FLG")
	private BigDecimal bundledFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="COMPLETED_RECEIVING_DATE")
	private Date completedReceivingDate;

	@Column(name="DISTRO_PALOPN_FLG")
	private BigDecimal distroPalopnFlg;

	@Column(name="EST_LODWGT")
	private BigDecimal estLodwgt;

	@Column(name="EST_TIME")
	private BigDecimal estTime;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LOAD_ATTR1_FLG")
	private BigDecimal loadAttr1Flg;

	@Column(name="LOAD_ATTR2_FLG")
	private BigDecimal loadAttr2Flg;

	@Column(name="LOAD_ATTR3_FLG")
	private BigDecimal loadAttr3Flg;

	@Column(name="LOAD_ATTR4_FLG")
	private BigDecimal loadAttr4Flg;

	@Column(name="LOAD_ATTR5_FLG")
	private BigDecimal loadAttr5Flg;

	@Column(name="LOD_TAGSTS")
	private String lodTagsts;

	private BigDecimal lodhgt;

	private BigDecimal lodlen;

	private String lodtag;

	private String loducc;

	private BigDecimal lodwdt;

	private BigDecimal lodwgt;

	@Column(name="LST_USR_ID")
	private String lstUsrId;

	private String lstcod;

	@Temporal(TemporalType.DATE)
	private Date lstdte;

	@Temporal(TemporalType.DATE)
	private Date lstmov;

	private BigDecimal mvlflg;

	@Column(name="NO_LOC_PUTAWAY")
	private BigDecimal noLocPutaway;

	@Column(name="NO_OF_BOXES")
	private BigDecimal noOfBoxes;

	private String palpos;

	private BigDecimal prmflg;

	private String stoloc;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	@Temporal(TemporalType.DATE)
	private Date uccdte;

	private BigDecimal unkflg;

	@Column(name="VOC_CHKDGT")
	private String vocChkdgt;

	@Column(name="WH_ID")
	private String whId;

	public Invlod() {
	}

	public String getLodnum() {
		return this.lodnum;
	}

	public void setLodnum(String lodnum) {
		this.lodnum = lodnum;
	}

	public Date getAdddte() {
		return this.adddte;
	}

	public void setAdddte(Date adddte) {
		this.adddte = adddte;
	}

	public String getAssetTyp() {
		return this.assetTyp;
	}

	public void setAssetTyp(String assetTyp) {
		this.assetTyp = assetTyp;
	}

	public BigDecimal getAvgUntCatchQty() {
		return this.avgUntCatchQty;
	}

	public void setAvgUntCatchQty(BigDecimal avgUntCatchQty) {
		this.avgUntCatchQty = avgUntCatchQty;
	}

	public BigDecimal getBundledFlg() {
		return this.bundledFlg;
	}

	public void setBundledFlg(BigDecimal bundledFlg) {
		this.bundledFlg = bundledFlg;
	}

	public Date getCompletedReceivingDate() {
		return this.completedReceivingDate;
	}

	public void setCompletedReceivingDate(Date completedReceivingDate) {
		this.completedReceivingDate = completedReceivingDate;
	}

	public BigDecimal getDistroPalopnFlg() {
		return this.distroPalopnFlg;
	}

	public void setDistroPalopnFlg(BigDecimal distroPalopnFlg) {
		this.distroPalopnFlg = distroPalopnFlg;
	}

	public BigDecimal getEstLodwgt() {
		return this.estLodwgt;
	}

	public void setEstLodwgt(BigDecimal estLodwgt) {
		this.estLodwgt = estLodwgt;
	}

	public BigDecimal getEstTime() {
		return this.estTime;
	}

	public void setEstTime(BigDecimal estTime) {
		this.estTime = estTime;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getLoadAttr1Flg() {
		return this.loadAttr1Flg;
	}

	public void setLoadAttr1Flg(BigDecimal loadAttr1Flg) {
		this.loadAttr1Flg = loadAttr1Flg;
	}

	public BigDecimal getLoadAttr2Flg() {
		return this.loadAttr2Flg;
	}

	public void setLoadAttr2Flg(BigDecimal loadAttr2Flg) {
		this.loadAttr2Flg = loadAttr2Flg;
	}

	public BigDecimal getLoadAttr3Flg() {
		return this.loadAttr3Flg;
	}

	public void setLoadAttr3Flg(BigDecimal loadAttr3Flg) {
		this.loadAttr3Flg = loadAttr3Flg;
	}

	public BigDecimal getLoadAttr4Flg() {
		return this.loadAttr4Flg;
	}

	public void setLoadAttr4Flg(BigDecimal loadAttr4Flg) {
		this.loadAttr4Flg = loadAttr4Flg;
	}

	public BigDecimal getLoadAttr5Flg() {
		return this.loadAttr5Flg;
	}

	public void setLoadAttr5Flg(BigDecimal loadAttr5Flg) {
		this.loadAttr5Flg = loadAttr5Flg;
	}

	public String getLodTagsts() {
		return this.lodTagsts;
	}

	public void setLodTagsts(String lodTagsts) {
		this.lodTagsts = lodTagsts;
	}

	public BigDecimal getLodhgt() {
		return this.lodhgt;
	}

	public void setLodhgt(BigDecimal lodhgt) {
		this.lodhgt = lodhgt;
	}

	public BigDecimal getLodlen() {
		return this.lodlen;
	}

	public void setLodlen(BigDecimal lodlen) {
		this.lodlen = lodlen;
	}

	public String getLodtag() {
		return this.lodtag;
	}

	public void setLodtag(String lodtag) {
		this.lodtag = lodtag;
	}

	public String getLoducc() {
		return this.loducc;
	}

	public void setLoducc(String loducc) {
		this.loducc = loducc;
	}

	public BigDecimal getLodwdt() {
		return this.lodwdt;
	}

	public void setLodwdt(BigDecimal lodwdt) {
		this.lodwdt = lodwdt;
	}

	public BigDecimal getLodwgt() {
		return this.lodwgt;
	}

	public void setLodwgt(BigDecimal lodwgt) {
		this.lodwgt = lodwgt;
	}

	public String getLstUsrId() {
		return this.lstUsrId;
	}

	public void setLstUsrId(String lstUsrId) {
		this.lstUsrId = lstUsrId;
	}

	public String getLstcod() {
		return this.lstcod;
	}

	public void setLstcod(String lstcod) {
		this.lstcod = lstcod;
	}

	public Date getLstdte() {
		return this.lstdte;
	}

	public void setLstdte(Date lstdte) {
		this.lstdte = lstdte;
	}

	public Date getLstmov() {
		return this.lstmov;
	}

	public void setLstmov(Date lstmov) {
		this.lstmov = lstmov;
	}

	public BigDecimal getMvlflg() {
		return this.mvlflg;
	}

	public void setMvlflg(BigDecimal mvlflg) {
		this.mvlflg = mvlflg;
	}

	public BigDecimal getNoLocPutaway() {
		return this.noLocPutaway;
	}

	public void setNoLocPutaway(BigDecimal noLocPutaway) {
		this.noLocPutaway = noLocPutaway;
	}

	public BigDecimal getNoOfBoxes() {
		return this.noOfBoxes;
	}

	public void setNoOfBoxes(BigDecimal noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}

	public String getPalpos() {
		return this.palpos;
	}

	public void setPalpos(String palpos) {
		this.palpos = palpos;
	}

	public BigDecimal getPrmflg() {
		return this.prmflg;
	}

	public void setPrmflg(BigDecimal prmflg) {
		this.prmflg = prmflg;
	}

	public String getStoloc() {
		return this.stoloc;
	}

	public void setStoloc(String stoloc) {
		this.stoloc = stoloc;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

	public Date getUccdte() {
		return this.uccdte;
	}

	public void setUccdte(Date uccdte) {
		this.uccdte = uccdte;
	}

	public BigDecimal getUnkflg() {
		return this.unkflg;
	}

	public void setUnkflg(BigDecimal unkflg) {
		this.unkflg = unkflg;
	}

	public String getVocChkdgt() {
		return this.vocChkdgt;
	}

	public void setVocChkdgt(String vocChkdgt) {
		this.vocChkdgt = vocChkdgt;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}