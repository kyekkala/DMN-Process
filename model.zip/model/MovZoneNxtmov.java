package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the MOV_ZONE_NXTMOV database table.
 * 
 */
@Entity
@Table(name="MOV_ZONE_NXTMOV")
@NamedQuery(name="MovZoneNxtmov.findAll", query="SELECT m FROM MovZoneNxtmov m")
public class MovZoneNxtmov implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private MovZoneNxtmovPK id;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private String oprcod;

	private BigDecimal pricod;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	public MovZoneNxtmov() {
	}

	public MovZoneNxtmovPK getId() {
		return this.id;
	}

	public void setId(MovZoneNxtmovPK id) {
		this.id = id;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getOprcod() {
		return this.oprcod;
	}

	public void setOprcod(String oprcod) {
		this.oprcod = oprcod;
	}

	public BigDecimal getPricod() {
		return this.pricod;
	}

	public void setPricod(BigDecimal pricod) {
		this.pricod = pricod;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

}