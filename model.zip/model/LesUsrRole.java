package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the LES_USR_ROLE database table.
 * 
 */
@Entity
@Table(name="LES_USR_ROLE")
@NamedQuery(name="LesUsrRole.findAll", query="SELECT l FROM LesUsrRole l")
public class LesUsrRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private LesUsrRolePK id;

	@Column(name="GRP_NAM")
	private String grpNam;

	@Column(name="LDAP_FLG")
	private BigDecimal ldapFlg;

	public LesUsrRole() {
	}

	public LesUsrRolePK getId() {
		return this.id;
	}

	public void setId(LesUsrRolePK id) {
		this.id = id;
	}

	public String getGrpNam() {
		return this.grpNam;
	}

	public void setGrpNam(String grpNam) {
		this.grpNam = grpNam;
	}

	public BigDecimal getLdapFlg() {
		return this.ldapFlg;
	}

	public void setLdapFlg(BigDecimal ldapFlg) {
		this.ldapFlg = ldapFlg;
	}

}