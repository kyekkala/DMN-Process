package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PCK_ZONE_INVSTS database table.
 * 
 */
@Embeddable
public class PckZoneInvstPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PCK_ZONE_ID")
	private long pckZoneId;

	private String invsts;

	public PckZoneInvstPK() {
	}
	public long getPckZoneId() {
		return this.pckZoneId;
	}
	public void setPckZoneId(long pckZoneId) {
		this.pckZoneId = pckZoneId;
	}
	public String getInvsts() {
		return this.invsts;
	}
	public void setInvsts(String invsts) {
		this.invsts = invsts;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PckZoneInvstPK)) {
			return false;
		}
		PckZoneInvstPK castOther = (PckZoneInvstPK)other;
		return 
			(this.pckZoneId == castOther.pckZoneId)
			&& this.invsts.equals(castOther.invsts);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.pckZoneId ^ (this.pckZoneId >>> 32)));
		hash = hash * prime + this.invsts.hashCode();
		
		return hash;
	}
}