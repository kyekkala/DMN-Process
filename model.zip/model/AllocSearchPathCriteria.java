package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the ALLOC_SEARCH_PATH_CRITERIA database table.
 * 
 */
@Entity
@Table(name="ALLOC_SEARCH_PATH_CRITERIA")
@NamedQuery(name="AllocSearchPathCriteria.findAll", query="SELECT a FROM AllocSearchPathCriteria a")
public class AllocSearchPathCriteria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ALLOC_SEARCH_PATH_CRITERIA_ID")
	private String allocSearchPathCriteriaId;

	@Column(name="ALLOC_SEARCH_PATH_ID")
	private String allocSearchPathId;

	private String colnam;

	private String colval;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	public AllocSearchPathCriteria() {
	}

	public String getAllocSearchPathCriteriaId() {
		return this.allocSearchPathCriteriaId;
	}

	public void setAllocSearchPathCriteriaId(String allocSearchPathCriteriaId) {
		this.allocSearchPathCriteriaId = allocSearchPathCriteriaId;
	}

	public String getAllocSearchPathId() {
		return this.allocSearchPathId;
	}

	public void setAllocSearchPathId(String allocSearchPathId) {
		this.allocSearchPathId = allocSearchPathId;
	}

	public String getColnam() {
		return this.colnam;
	}

	public void setColnam(String colnam) {
		this.colnam = colnam;
	}

	public String getColval() {
		return this.colval;
	}

	public void setColval(String colval) {
		this.colval = colval;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

}