package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LOCMST database table.
 * 
 */
@Entity
@NamedQuery(name="Locmst.findAll", query="SELECT l FROM Locmst l")
public class Locmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private LocmstPK id;

	private String abccod;

	@Column(name="AISLE_ID")
	private String aisleId;

	private String arecod;

	private BigDecimal asgflg;

	@Temporal(TemporalType.DATE)
	private Date atedte;

	private BigDecimal ateseq;

	private String attr1;

	private String attr2;

	private String attr3;

	private String attr4;

	private String attr5;

	@Column(name="AUTO_MOV_FLG")
	private BigDecimal autoMovFlg;

	@Column(name="BASEPOINT_ID")
	private String basepointId;

	private String bay;

	@Column(name="BCKFILL_AISLE")
	private String bckfillAisle;

	@Column(name="BCKFILL_LOC")
	private String bckfillLoc;

	@Column(name="BCKFILL_LOCVRC")
	private String bckfillLocvrc;

	@Column(name="BCKFILL_VOC_CHKDGT")
	private String bckfillVocChkdgt;

	@Column(name="BCKFILL_VOC_CHKDGT_2")
	private String bckfillVocChkdgt2;

	@Column(name="BCKFILL_VOC_CHKDGT_3")
	private String bckfillVocChkdgt3;

	@Column(name="BILLING_FLG")
	private BigDecimal billingFlg;

	@Column(name="BORDER_PAD")
	private BigDecimal borderPad;

	@Column(name="BOTTOM_LEFT_X")
	private BigDecimal bottomLeftX;

	@Column(name="BOTTOM_LEFT_Y")
	private BigDecimal bottomLeftY;

	@Column(name="BOTTOM_RIGHT_X")
	private BigDecimal bottomRightX;

	@Column(name="BOTTOM_RIGHT_Y")
	private BigDecimal bottomRightY;

	private BigDecimal cipflg;

	@Column(name="CNT_ZONE_ID")
	private BigDecimal cntZoneId;

	@Column(name="CNTBCK_ENA_FLG")
	private BigDecimal cntbckEnaFlg;

	@Temporal(TemporalType.DATE)
	private Date cntdte;

	private String cntseq;

	private BigDecimal curqvl;

	@Column(name="DCK_ACC_COD")
	private String dckAccCod;

	@Column(name="DEF_MAXQVL")
	private BigDecimal defMaxqvl;

	private String devcod;

	private BigDecimal erfpct;

	@Column(name="ESC_THR")
	private BigDecimal escThr;

	@Column(name="ESC_TYPE")
	private String escType;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LBL_PRTADR")
	private String lblPrtadr;

	@Column(name="LOC_TYP_ID")
	private BigDecimal locTypId;

	private String locacc;

	private String loccod;

	private BigDecimal lochgt;

	private BigDecimal loclen;

	private String locpos;

	private String locsts;

	private String locvrc;

	private BigDecimal locwid;

	private String lokcod;

	@Column(name="LST_USR_ID")
	private String lstUsrId;

	private String lstcod;

	@Temporal(TemporalType.DATE)
	private Date lstdte;

	private String lvl;

	@Column(name="LVL_TYP_ID")
	private String lvlTypId;

	@Column(name="MAX_LVL_UNIT")
	private BigDecimal maxLvlUnit;

	private BigDecimal maxqvl;

	private BigDecimal maxwgt;

	@Column(name="MIN_LVL_UNIT")
	private BigDecimal minLvlUnit;

	@Column(name="MOV_ZONE_ID")
	private BigDecimal movZoneId;

	private BigDecimal numcnt;

	@Column(name="OF_LVL_UNIT")
	private BigDecimal ofLvlUnit;

	@Column(name="PAL_STCK_RST")
	private String palStckRst;

	@Column(name="PCK_ZONE_ID")
	private BigDecimal pckZoneId;

	private BigDecimal pckflg;

	@Column(name="PERM_ASGFLG")
	private BigDecimal permAsgflg;

	private BigDecimal pndqvl;

	private String prdlin;

	private String prtadr;

	@Column(name="RCV_RESCOD")
	private String rcvRescod;

	private BigDecimal repflg;

	private String rescod;

	@Column(name="\"SECTION\"")
	private String section;

	@Column(name="SLOT_ID")
	private String slotId;

	private String slotseq;

	private String stgloc;

	@Column(name="STO_SEQ")
	private String stoSeq;

	@Column(name="STO_ZONE_ID")
	private BigDecimal stoZoneId;

	private BigDecimal stoflg;

	@Column(name="TOP_LEFT_X")
	private BigDecimal topLeftX;

	@Column(name="TOP_LEFT_Y")
	private BigDecimal topLeftY;

	@Column(name="TOP_RIGHT_X")
	private BigDecimal topRightX;

	@Column(name="TOP_RIGHT_Y")
	private BigDecimal topRightY;

	private BigDecimal trfpct;

	private String trvseq;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	private BigDecimal useflg;

	private String velzon;

	@Column(name="VOC_CHKDGT")
	private String vocChkdgt;

	@Column(name="VOC_CHKDGT_2")
	private String vocChkdgt2;

	@Column(name="VOC_CHKDGT_3")
	private String vocChkdgt3;

	@Column(name="WRK_ZONE_ID")
	private BigDecimal wrkZoneId;

	private String x;

	private String y;

	private String z;

	public Locmst() {
	}

	public LocmstPK getId() {
		return this.id;
	}

	public void setId(LocmstPK id) {
		this.id = id;
	}

	public String getAbccod() {
		return this.abccod;
	}

	public void setAbccod(String abccod) {
		this.abccod = abccod;
	}

	public String getAisleId() {
		return this.aisleId;
	}

	public void setAisleId(String aisleId) {
		this.aisleId = aisleId;
	}

	public String getArecod() {
		return this.arecod;
	}

	public void setArecod(String arecod) {
		this.arecod = arecod;
	}

	public BigDecimal getAsgflg() {
		return this.asgflg;
	}

	public void setAsgflg(BigDecimal asgflg) {
		this.asgflg = asgflg;
	}

	public Date getAtedte() {
		return this.atedte;
	}

	public void setAtedte(Date atedte) {
		this.atedte = atedte;
	}

	public BigDecimal getAteseq() {
		return this.ateseq;
	}

	public void setAteseq(BigDecimal ateseq) {
		this.ateseq = ateseq;
	}

	public String getAttr1() {
		return this.attr1;
	}

	public void setAttr1(String attr1) {
		this.attr1 = attr1;
	}

	public String getAttr2() {
		return this.attr2;
	}

	public void setAttr2(String attr2) {
		this.attr2 = attr2;
	}

	public String getAttr3() {
		return this.attr3;
	}

	public void setAttr3(String attr3) {
		this.attr3 = attr3;
	}

	public String getAttr4() {
		return this.attr4;
	}

	public void setAttr4(String attr4) {
		this.attr4 = attr4;
	}

	public String getAttr5() {
		return this.attr5;
	}

	public void setAttr5(String attr5) {
		this.attr5 = attr5;
	}

	public BigDecimal getAutoMovFlg() {
		return this.autoMovFlg;
	}

	public void setAutoMovFlg(BigDecimal autoMovFlg) {
		this.autoMovFlg = autoMovFlg;
	}

	public String getBasepointId() {
		return this.basepointId;
	}

	public void setBasepointId(String basepointId) {
		this.basepointId = basepointId;
	}

	public String getBay() {
		return this.bay;
	}

	public void setBay(String bay) {
		this.bay = bay;
	}

	public String getBckfillAisle() {
		return this.bckfillAisle;
	}

	public void setBckfillAisle(String bckfillAisle) {
		this.bckfillAisle = bckfillAisle;
	}

	public String getBckfillLoc() {
		return this.bckfillLoc;
	}

	public void setBckfillLoc(String bckfillLoc) {
		this.bckfillLoc = bckfillLoc;
	}

	public String getBckfillLocvrc() {
		return this.bckfillLocvrc;
	}

	public void setBckfillLocvrc(String bckfillLocvrc) {
		this.bckfillLocvrc = bckfillLocvrc;
	}

	public String getBckfillVocChkdgt() {
		return this.bckfillVocChkdgt;
	}

	public void setBckfillVocChkdgt(String bckfillVocChkdgt) {
		this.bckfillVocChkdgt = bckfillVocChkdgt;
	}

	public String getBckfillVocChkdgt2() {
		return this.bckfillVocChkdgt2;
	}

	public void setBckfillVocChkdgt2(String bckfillVocChkdgt2) {
		this.bckfillVocChkdgt2 = bckfillVocChkdgt2;
	}

	public String getBckfillVocChkdgt3() {
		return this.bckfillVocChkdgt3;
	}

	public void setBckfillVocChkdgt3(String bckfillVocChkdgt3) {
		this.bckfillVocChkdgt3 = bckfillVocChkdgt3;
	}

	public BigDecimal getBillingFlg() {
		return this.billingFlg;
	}

	public void setBillingFlg(BigDecimal billingFlg) {
		this.billingFlg = billingFlg;
	}

	public BigDecimal getBorderPad() {
		return this.borderPad;
	}

	public void setBorderPad(BigDecimal borderPad) {
		this.borderPad = borderPad;
	}

	public BigDecimal getBottomLeftX() {
		return this.bottomLeftX;
	}

	public void setBottomLeftX(BigDecimal bottomLeftX) {
		this.bottomLeftX = bottomLeftX;
	}

	public BigDecimal getBottomLeftY() {
		return this.bottomLeftY;
	}

	public void setBottomLeftY(BigDecimal bottomLeftY) {
		this.bottomLeftY = bottomLeftY;
	}

	public BigDecimal getBottomRightX() {
		return this.bottomRightX;
	}

	public void setBottomRightX(BigDecimal bottomRightX) {
		this.bottomRightX = bottomRightX;
	}

	public BigDecimal getBottomRightY() {
		return this.bottomRightY;
	}

	public void setBottomRightY(BigDecimal bottomRightY) {
		this.bottomRightY = bottomRightY;
	}

	public BigDecimal getCipflg() {
		return this.cipflg;
	}

	public void setCipflg(BigDecimal cipflg) {
		this.cipflg = cipflg;
	}

	public BigDecimal getCntZoneId() {
		return this.cntZoneId;
	}

	public void setCntZoneId(BigDecimal cntZoneId) {
		this.cntZoneId = cntZoneId;
	}

	public BigDecimal getCntbckEnaFlg() {
		return this.cntbckEnaFlg;
	}

	public void setCntbckEnaFlg(BigDecimal cntbckEnaFlg) {
		this.cntbckEnaFlg = cntbckEnaFlg;
	}

	public Date getCntdte() {
		return this.cntdte;
	}

	public void setCntdte(Date cntdte) {
		this.cntdte = cntdte;
	}

	public String getCntseq() {
		return this.cntseq;
	}

	public void setCntseq(String cntseq) {
		this.cntseq = cntseq;
	}

	public BigDecimal getCurqvl() {
		return this.curqvl;
	}

	public void setCurqvl(BigDecimal curqvl) {
		this.curqvl = curqvl;
	}

	public String getDckAccCod() {
		return this.dckAccCod;
	}

	public void setDckAccCod(String dckAccCod) {
		this.dckAccCod = dckAccCod;
	}

	public BigDecimal getDefMaxqvl() {
		return this.defMaxqvl;
	}

	public void setDefMaxqvl(BigDecimal defMaxqvl) {
		this.defMaxqvl = defMaxqvl;
	}

	public String getDevcod() {
		return this.devcod;
	}

	public void setDevcod(String devcod) {
		this.devcod = devcod;
	}

	public BigDecimal getErfpct() {
		return this.erfpct;
	}

	public void setErfpct(BigDecimal erfpct) {
		this.erfpct = erfpct;
	}

	public BigDecimal getEscThr() {
		return this.escThr;
	}

	public void setEscThr(BigDecimal escThr) {
		this.escThr = escThr;
	}

	public String getEscType() {
		return this.escType;
	}

	public void setEscType(String escType) {
		this.escType = escType;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getLblPrtadr() {
		return this.lblPrtadr;
	}

	public void setLblPrtadr(String lblPrtadr) {
		this.lblPrtadr = lblPrtadr;
	}

	public BigDecimal getLocTypId() {
		return this.locTypId;
	}

	public void setLocTypId(BigDecimal locTypId) {
		this.locTypId = locTypId;
	}

	public String getLocacc() {
		return this.locacc;
	}

	public void setLocacc(String locacc) {
		this.locacc = locacc;
	}

	public String getLoccod() {
		return this.loccod;
	}

	public void setLoccod(String loccod) {
		this.loccod = loccod;
	}

	public BigDecimal getLochgt() {
		return this.lochgt;
	}

	public void setLochgt(BigDecimal lochgt) {
		this.lochgt = lochgt;
	}

	public BigDecimal getLoclen() {
		return this.loclen;
	}

	public void setLoclen(BigDecimal loclen) {
		this.loclen = loclen;
	}

	public String getLocpos() {
		return this.locpos;
	}

	public void setLocpos(String locpos) {
		this.locpos = locpos;
	}

	public String getLocsts() {
		return this.locsts;
	}

	public void setLocsts(String locsts) {
		this.locsts = locsts;
	}

	public String getLocvrc() {
		return this.locvrc;
	}

	public void setLocvrc(String locvrc) {
		this.locvrc = locvrc;
	}

	public BigDecimal getLocwid() {
		return this.locwid;
	}

	public void setLocwid(BigDecimal locwid) {
		this.locwid = locwid;
	}

	public String getLokcod() {
		return this.lokcod;
	}

	public void setLokcod(String lokcod) {
		this.lokcod = lokcod;
	}

	public String getLstUsrId() {
		return this.lstUsrId;
	}

	public void setLstUsrId(String lstUsrId) {
		this.lstUsrId = lstUsrId;
	}

	public String getLstcod() {
		return this.lstcod;
	}

	public void setLstcod(String lstcod) {
		this.lstcod = lstcod;
	}

	public Date getLstdte() {
		return this.lstdte;
	}

	public void setLstdte(Date lstdte) {
		this.lstdte = lstdte;
	}

	public String getLvl() {
		return this.lvl;
	}

	public void setLvl(String lvl) {
		this.lvl = lvl;
	}

	public String getLvlTypId() {
		return this.lvlTypId;
	}

	public void setLvlTypId(String lvlTypId) {
		this.lvlTypId = lvlTypId;
	}

	public BigDecimal getMaxLvlUnit() {
		return this.maxLvlUnit;
	}

	public void setMaxLvlUnit(BigDecimal maxLvlUnit) {
		this.maxLvlUnit = maxLvlUnit;
	}

	public BigDecimal getMaxqvl() {
		return this.maxqvl;
	}

	public void setMaxqvl(BigDecimal maxqvl) {
		this.maxqvl = maxqvl;
	}

	public BigDecimal getMaxwgt() {
		return this.maxwgt;
	}

	public void setMaxwgt(BigDecimal maxwgt) {
		this.maxwgt = maxwgt;
	}

	public BigDecimal getMinLvlUnit() {
		return this.minLvlUnit;
	}

	public void setMinLvlUnit(BigDecimal minLvlUnit) {
		this.minLvlUnit = minLvlUnit;
	}

	public BigDecimal getMovZoneId() {
		return this.movZoneId;
	}

	public void setMovZoneId(BigDecimal movZoneId) {
		this.movZoneId = movZoneId;
	}

	public BigDecimal getNumcnt() {
		return this.numcnt;
	}

	public void setNumcnt(BigDecimal numcnt) {
		this.numcnt = numcnt;
	}

	public BigDecimal getOfLvlUnit() {
		return this.ofLvlUnit;
	}

	public void setOfLvlUnit(BigDecimal ofLvlUnit) {
		this.ofLvlUnit = ofLvlUnit;
	}

	public String getPalStckRst() {
		return this.palStckRst;
	}

	public void setPalStckRst(String palStckRst) {
		this.palStckRst = palStckRst;
	}

	public BigDecimal getPckZoneId() {
		return this.pckZoneId;
	}

	public void setPckZoneId(BigDecimal pckZoneId) {
		this.pckZoneId = pckZoneId;
	}

	public BigDecimal getPckflg() {
		return this.pckflg;
	}

	public void setPckflg(BigDecimal pckflg) {
		this.pckflg = pckflg;
	}

	public BigDecimal getPermAsgflg() {
		return this.permAsgflg;
	}

	public void setPermAsgflg(BigDecimal permAsgflg) {
		this.permAsgflg = permAsgflg;
	}

	public BigDecimal getPndqvl() {
		return this.pndqvl;
	}

	public void setPndqvl(BigDecimal pndqvl) {
		this.pndqvl = pndqvl;
	}

	public String getPrdlin() {
		return this.prdlin;
	}

	public void setPrdlin(String prdlin) {
		this.prdlin = prdlin;
	}

	public String getPrtadr() {
		return this.prtadr;
	}

	public void setPrtadr(String prtadr) {
		this.prtadr = prtadr;
	}

	public String getRcvRescod() {
		return this.rcvRescod;
	}

	public void setRcvRescod(String rcvRescod) {
		this.rcvRescod = rcvRescod;
	}

	public BigDecimal getRepflg() {
		return this.repflg;
	}

	public void setRepflg(BigDecimal repflg) {
		this.repflg = repflg;
	}

	public String getRescod() {
		return this.rescod;
	}

	public void setRescod(String rescod) {
		this.rescod = rescod;
	}

	public String getSection() {
		return this.section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getSlotId() {
		return this.slotId;
	}

	public void setSlotId(String slotId) {
		this.slotId = slotId;
	}

	public String getSlotseq() {
		return this.slotseq;
	}

	public void setSlotseq(String slotseq) {
		this.slotseq = slotseq;
	}

	public String getStgloc() {
		return this.stgloc;
	}

	public void setStgloc(String stgloc) {
		this.stgloc = stgloc;
	}

	public String getStoSeq() {
		return this.stoSeq;
	}

	public void setStoSeq(String stoSeq) {
		this.stoSeq = stoSeq;
	}

	public BigDecimal getStoZoneId() {
		return this.stoZoneId;
	}

	public void setStoZoneId(BigDecimal stoZoneId) {
		this.stoZoneId = stoZoneId;
	}

	public BigDecimal getStoflg() {
		return this.stoflg;
	}

	public void setStoflg(BigDecimal stoflg) {
		this.stoflg = stoflg;
	}

	public BigDecimal getTopLeftX() {
		return this.topLeftX;
	}

	public void setTopLeftX(BigDecimal topLeftX) {
		this.topLeftX = topLeftX;
	}

	public BigDecimal getTopLeftY() {
		return this.topLeftY;
	}

	public void setTopLeftY(BigDecimal topLeftY) {
		this.topLeftY = topLeftY;
	}

	public BigDecimal getTopRightX() {
		return this.topRightX;
	}

	public void setTopRightX(BigDecimal topRightX) {
		this.topRightX = topRightX;
	}

	public BigDecimal getTopRightY() {
		return this.topRightY;
	}

	public void setTopRightY(BigDecimal topRightY) {
		this.topRightY = topRightY;
	}

	public BigDecimal getTrfpct() {
		return this.trfpct;
	}

	public void setTrfpct(BigDecimal trfpct) {
		this.trfpct = trfpct;
	}

	public String getTrvseq() {
		return this.trvseq;
	}

	public void setTrvseq(String trvseq) {
		this.trvseq = trvseq;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

	public BigDecimal getUseflg() {
		return this.useflg;
	}

	public void setUseflg(BigDecimal useflg) {
		this.useflg = useflg;
	}

	public String getVelzon() {
		return this.velzon;
	}

	public void setVelzon(String velzon) {
		this.velzon = velzon;
	}

	public String getVocChkdgt() {
		return this.vocChkdgt;
	}

	public void setVocChkdgt(String vocChkdgt) {
		this.vocChkdgt = vocChkdgt;
	}

	public String getVocChkdgt2() {
		return this.vocChkdgt2;
	}

	public void setVocChkdgt2(String vocChkdgt2) {
		this.vocChkdgt2 = vocChkdgt2;
	}

	public String getVocChkdgt3() {
		return this.vocChkdgt3;
	}

	public void setVocChkdgt3(String vocChkdgt3) {
		this.vocChkdgt3 = vocChkdgt3;
	}

	public BigDecimal getWrkZoneId() {
		return this.wrkZoneId;
	}

	public void setWrkZoneId(BigDecimal wrkZoneId) {
		this.wrkZoneId = wrkZoneId;
	}

	public String getX() {
		return this.x;
	}

	public void setX(String x) {
		this.x = x;
	}

	public String getY() {
		return this.y;
	}

	public void setY(String y) {
		this.y = y;
	}

	public String getZ() {
		return this.z;
	}

	public void setZ(String z) {
		this.z = z;
	}

}