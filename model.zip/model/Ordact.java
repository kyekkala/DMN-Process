package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the ORDACT database table.
 * 
 */
@Entity
@NamedQuery(name="Ordact.findAll", query="SELECT o FROM Ordact o")
public class Ordact implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrdactPK id;

	private String actcod;

	@Column(name="ARC_SRC")
	private String arcSrc;

	@Temporal(TemporalType.DATE)
	private Date arcdte;

	@Column(name="CAR_MOVE_ID")
	private String carMoveId;

	private String carcod;

	@Column(name="CLIENT_ID")
	private String clientId;

	@Column(name="MOD_COLLST")
	private String modCollst;

	@Column(name="MOD_VALLST")
	private String modVallst;

	private String ordlin;

	@Column(name="ORDLIN_CHG_REACOD")
	private String ordlinChgReacod;

	private String ordnum;

	private BigDecimal ordqty;

	private String ordsln;

	private String ordtyp;

	@Column(name="ORIG_SHIP_ID")
	private String origShipId;

	@Column(name="ORIG_SHIP_LINE_ID")
	private String origShipLineId;

	private BigDecimal pckqty;

	@Column(name="PRT_CLIENT_ID")
	private String prtClientId;

	private String prtnum;

	@Column(name="REACOD_CMNT")
	private String reacodCmnt;

	private String schbat;

	@Column(name="SHIP_ID")
	private String shipId;

	@Column(name="SHIP_LINE_ID")
	private String shipLineId;

	private String srvlvl;

	private String stcust;

	@Column(name="STOP_ID")
	private String stopId;

	@Column(name="STOP_SEQ")
	private BigDecimal stopSeq;

	@Column(name="SUPER_SHIP_FLG")
	private BigDecimal superShipFlg;

	@Column(name="SUPER_SHIP_ID")
	private String superShipId;

	@Temporal(TemporalType.DATE)
	private Date trndte;

	@Column(name="USR_ID")
	private String usrId;

	public Ordact() {
	}

	public OrdactPK getId() {
		return this.id;
	}

	public void setId(OrdactPK id) {
		this.id = id;
	}

	public String getActcod() {
		return this.actcod;
	}

	public void setActcod(String actcod) {
		this.actcod = actcod;
	}

	public String getArcSrc() {
		return this.arcSrc;
	}

	public void setArcSrc(String arcSrc) {
		this.arcSrc = arcSrc;
	}

	public Date getArcdte() {
		return this.arcdte;
	}

	public void setArcdte(Date arcdte) {
		this.arcdte = arcdte;
	}

	public String getCarMoveId() {
		return this.carMoveId;
	}

	public void setCarMoveId(String carMoveId) {
		this.carMoveId = carMoveId;
	}

	public String getCarcod() {
		return this.carcod;
	}

	public void setCarcod(String carcod) {
		this.carcod = carcod;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getModCollst() {
		return this.modCollst;
	}

	public void setModCollst(String modCollst) {
		this.modCollst = modCollst;
	}

	public String getModVallst() {
		return this.modVallst;
	}

	public void setModVallst(String modVallst) {
		this.modVallst = modVallst;
	}

	public String getOrdlin() {
		return this.ordlin;
	}

	public void setOrdlin(String ordlin) {
		this.ordlin = ordlin;
	}

	public String getOrdlinChgReacod() {
		return this.ordlinChgReacod;
	}

	public void setOrdlinChgReacod(String ordlinChgReacod) {
		this.ordlinChgReacod = ordlinChgReacod;
	}

	public String getOrdnum() {
		return this.ordnum;
	}

	public void setOrdnum(String ordnum) {
		this.ordnum = ordnum;
	}

	public BigDecimal getOrdqty() {
		return this.ordqty;
	}

	public void setOrdqty(BigDecimal ordqty) {
		this.ordqty = ordqty;
	}

	public String getOrdsln() {
		return this.ordsln;
	}

	public void setOrdsln(String ordsln) {
		this.ordsln = ordsln;
	}

	public String getOrdtyp() {
		return this.ordtyp;
	}

	public void setOrdtyp(String ordtyp) {
		this.ordtyp = ordtyp;
	}

	public String getOrigShipId() {
		return this.origShipId;
	}

	public void setOrigShipId(String origShipId) {
		this.origShipId = origShipId;
	}

	public String getOrigShipLineId() {
		return this.origShipLineId;
	}

	public void setOrigShipLineId(String origShipLineId) {
		this.origShipLineId = origShipLineId;
	}

	public BigDecimal getPckqty() {
		return this.pckqty;
	}

	public void setPckqty(BigDecimal pckqty) {
		this.pckqty = pckqty;
	}

	public String getPrtClientId() {
		return this.prtClientId;
	}

	public void setPrtClientId(String prtClientId) {
		this.prtClientId = prtClientId;
	}

	public String getPrtnum() {
		return this.prtnum;
	}

	public void setPrtnum(String prtnum) {
		this.prtnum = prtnum;
	}

	public String getReacodCmnt() {
		return this.reacodCmnt;
	}

	public void setReacodCmnt(String reacodCmnt) {
		this.reacodCmnt = reacodCmnt;
	}

	public String getSchbat() {
		return this.schbat;
	}

	public void setSchbat(String schbat) {
		this.schbat = schbat;
	}

	public String getShipId() {
		return this.shipId;
	}

	public void setShipId(String shipId) {
		this.shipId = shipId;
	}

	public String getShipLineId() {
		return this.shipLineId;
	}

	public void setShipLineId(String shipLineId) {
		this.shipLineId = shipLineId;
	}

	public String getSrvlvl() {
		return this.srvlvl;
	}

	public void setSrvlvl(String srvlvl) {
		this.srvlvl = srvlvl;
	}

	public String getStcust() {
		return this.stcust;
	}

	public void setStcust(String stcust) {
		this.stcust = stcust;
	}

	public String getStopId() {
		return this.stopId;
	}

	public void setStopId(String stopId) {
		this.stopId = stopId;
	}

	public BigDecimal getStopSeq() {
		return this.stopSeq;
	}

	public void setStopSeq(BigDecimal stopSeq) {
		this.stopSeq = stopSeq;
	}

	public BigDecimal getSuperShipFlg() {
		return this.superShipFlg;
	}

	public void setSuperShipFlg(BigDecimal superShipFlg) {
		this.superShipFlg = superShipFlg;
	}

	public String getSuperShipId() {
		return this.superShipId;
	}

	public void setSuperShipId(String superShipId) {
		this.superShipId = superShipId;
	}

	public Date getTrndte() {
		return this.trndte;
	}

	public void setTrndte(Date trndte) {
		this.trndte = trndte;
	}

	public String getUsrId() {
		return this.usrId;
	}

	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}

}