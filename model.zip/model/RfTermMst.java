package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the RF_TERM_MST database table.
 * 
 */
@Entity
@Table(name="RF_TERM_MST")
@NamedQuery(name="RfTermMst.findAll", query="SELECT r FROM RfTermMst r")
public class RfTermMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RfTermMstPK id;

	private String devcod;

	@Column(name="DSPLY_HGT")
	private BigDecimal dsplyHgt;

	@Column(name="DSPLY_WID")
	private BigDecimal dsplyWid;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LOCALE_ID")
	private String localeId;

	private String recplycod;

	private String recplyfil;

	@Column(name="TERM_TYP")
	private String termTyp;

	public RfTermMst() {
	}

	public RfTermMstPK getId() {
		return this.id;
	}

	public void setId(RfTermMstPK id) {
		this.id = id;
	}

	public String getDevcod() {
		return this.devcod;
	}

	public void setDevcod(String devcod) {
		this.devcod = devcod;
	}

	public BigDecimal getDsplyHgt() {
		return this.dsplyHgt;
	}

	public void setDsplyHgt(BigDecimal dsplyHgt) {
		this.dsplyHgt = dsplyHgt;
	}

	public BigDecimal getDsplyWid() {
		return this.dsplyWid;
	}

	public void setDsplyWid(BigDecimal dsplyWid) {
		this.dsplyWid = dsplyWid;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getLocaleId() {
		return this.localeId;
	}

	public void setLocaleId(String localeId) {
		this.localeId = localeId;
	}

	public String getRecplycod() {
		return this.recplycod;
	}

	public void setRecplycod(String recplycod) {
		this.recplycod = recplycod;
	}

	public String getRecplyfil() {
		return this.recplyfil;
	}

	public void setRecplyfil(String recplyfil) {
		this.recplyfil = recplyfil;
	}

	public String getTermTyp() {
		return this.termTyp;
	}

	public void setTermTyp(String termTyp) {
		this.termTyp = termTyp;
	}

}