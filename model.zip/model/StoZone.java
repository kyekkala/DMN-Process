package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the STO_ZONE database table.
 * 
 */
@Entity
@Table(name="STO_ZONE")
@NamedQuery(name="StoZone.findAll", query="SELECT s FROM StoZone s")
public class StoZone implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="STO_ZONE_ID")
	private long stoZoneId;

	@Column(name="BLDG_ID")
	private String bldgId;

	@Column(name="CON_PAL_FLG")
	private BigDecimal conPalFlg;

	private BigDecimal conflg;

	private BigDecimal fifflg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private String pckcod;

	@Column(name="PROX_PUT_COD")
	private String proxPutCod;

	@Column(name="RNWL_STO_FLG")
	private BigDecimal rnwlStoFlg;

	@Column(name="SET_LOCSTS_FLG")
	private BigDecimal setLocstsFlg;

	@Column(name="SET_MAXQVL_FLG")
	private BigDecimal setMaxqvlFlg;

	@Column(name="STO_ZONE_COD")
	private String stoZoneCod;

	@Column(name="VRT_STCK_FLG")
	private BigDecimal vrtStckFlg;

	@Column(name="WH_ID")
	private String whId;

	public StoZone() {
	}

	public long getStoZoneId() {
		return this.stoZoneId;
	}

	public void setStoZoneId(long stoZoneId) {
		this.stoZoneId = stoZoneId;
	}

	public String getBldgId() {
		return this.bldgId;
	}

	public void setBldgId(String bldgId) {
		this.bldgId = bldgId;
	}

	public BigDecimal getConPalFlg() {
		return this.conPalFlg;
	}

	public void setConPalFlg(BigDecimal conPalFlg) {
		this.conPalFlg = conPalFlg;
	}

	public BigDecimal getConflg() {
		return this.conflg;
	}

	public void setConflg(BigDecimal conflg) {
		this.conflg = conflg;
	}

	public BigDecimal getFifflg() {
		return this.fifflg;
	}

	public void setFifflg(BigDecimal fifflg) {
		this.fifflg = fifflg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getPckcod() {
		return this.pckcod;
	}

	public void setPckcod(String pckcod) {
		this.pckcod = pckcod;
	}

	public String getProxPutCod() {
		return this.proxPutCod;
	}

	public void setProxPutCod(String proxPutCod) {
		this.proxPutCod = proxPutCod;
	}

	public BigDecimal getRnwlStoFlg() {
		return this.rnwlStoFlg;
	}

	public void setRnwlStoFlg(BigDecimal rnwlStoFlg) {
		this.rnwlStoFlg = rnwlStoFlg;
	}

	public BigDecimal getSetLocstsFlg() {
		return this.setLocstsFlg;
	}

	public void setSetLocstsFlg(BigDecimal setLocstsFlg) {
		this.setLocstsFlg = setLocstsFlg;
	}

	public BigDecimal getSetMaxqvlFlg() {
		return this.setMaxqvlFlg;
	}

	public void setSetMaxqvlFlg(BigDecimal setMaxqvlFlg) {
		this.setMaxqvlFlg = setMaxqvlFlg;
	}

	public String getStoZoneCod() {
		return this.stoZoneCod;
	}

	public void setStoZoneCod(String stoZoneCod) {
		this.stoZoneCod = stoZoneCod;
	}

	public BigDecimal getVrtStckFlg() {
		return this.vrtStckFlg;
	}

	public void setVrtStckFlg(BigDecimal vrtStckFlg) {
		this.vrtStckFlg = vrtStckFlg;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}