package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the WH_UOM database table.
 * 
 */
@Embeddable
public class WhUomPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="WH_ID")
	private String whId;

	private String uomcod;

	public WhUomPK() {
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getUomcod() {
		return this.uomcod;
	}
	public void setUomcod(String uomcod) {
		this.uomcod = uomcod;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof WhUomPK)) {
			return false;
		}
		WhUomPK castOther = (WhUomPK)other;
		return 
			this.whId.equals(castOther.whId)
			&& this.uomcod.equals(castOther.uomcod);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.uomcod.hashCode();
		
		return hash;
	}
}