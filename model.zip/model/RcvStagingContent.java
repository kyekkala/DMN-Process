package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the RCV_STAGING_CONTENTS database table.
 * 
 */
@Entity
@Table(name="RCV_STAGING_CONTENTS")
@NamedQuery(name="RcvStagingContent.findAll", query="SELECT r FROM RcvStagingContent r")
public class RcvStagingContent implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RcvStagingContentPK id;

	public RcvStagingContent() {
	}

	public RcvStagingContentPK getId() {
		return this.id;
	}

	public void setId(RcvStagingContentPK id) {
		this.id = id;
	}

}