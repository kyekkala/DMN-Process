package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPN_INVMIX_RULE database table.
 * 
 */
@Entity
@Table(name="LPN_INVMIX_RULE")
@NamedQuery(name="LpnInvmixRule.findAll", query="SELECT l FROM LpnInvmixRule l")
public class LpnInvmixRule implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LPN_RULE_ID")
	private String lpnRuleId;

	@Column(name="CLIENT_ID")
	private String clientId;

	@Column(name="COLUMN_NAME")
	private String columnName;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="MIX_RULE_TYPE")
	private String mixRuleType;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private BigDecimal srtseq;

	private String tblnme;

	@Column(name="WH_ID")
	private String whId;

	public LpnInvmixRule() {
	}

	public String getLpnRuleId() {
		return this.lpnRuleId;
	}

	public void setLpnRuleId(String lpnRuleId) {
		this.lpnRuleId = lpnRuleId;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getColumnName() {
		return this.columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getMixRuleType() {
		return this.mixRuleType;
	}

	public void setMixRuleType(String mixRuleType) {
		this.mixRuleType = mixRuleType;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getSrtseq() {
		return this.srtseq;
	}

	public void setSrtseq(BigDecimal srtseq) {
		this.srtseq = srtseq;
	}

	public String getTblnme() {
		return this.tblnme;
	}

	public void setTblnme(String tblnme) {
		this.tblnme = tblnme;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}