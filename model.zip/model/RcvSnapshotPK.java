package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RCV_SNAPSHOT database table.
 * 
 */
@Embeddable
public class RcvSnapshotPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Temporal(TemporalType.DATE)
	@Column(name="SNAP_DTE")
	private java.util.Date snapDte;

	@Column(name="WH_ID")
	private String whId;

	private String lodlvl;

	public RcvSnapshotPK() {
	}
	public java.util.Date getSnapDte() {
		return this.snapDte;
	}
	public void setSnapDte(java.util.Date snapDte) {
		this.snapDte = snapDte;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getLodlvl() {
		return this.lodlvl;
	}
	public void setLodlvl(String lodlvl) {
		this.lodlvl = lodlvl;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RcvSnapshotPK)) {
			return false;
		}
		RcvSnapshotPK castOther = (RcvSnapshotPK)other;
		return 
			this.snapDte.equals(castOther.snapDte)
			&& this.whId.equals(castOther.whId)
			&& this.lodlvl.equals(castOther.lodlvl);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.snapDte.hashCode();
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.lodlvl.hashCode();
		
		return hash;
	}
}