package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the VOC_ASSIGN_SUM_CFG database table.
 * 
 */
@Embeddable
public class VocAssignSumCfgPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="WH_ID")
	private String whId;

	private String colnam;

	public VocAssignSumCfgPK() {
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getColnam() {
		return this.colnam;
	}
	public void setColnam(String colnam) {
		this.colnam = colnam;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof VocAssignSumCfgPK)) {
			return false;
		}
		VocAssignSumCfgPK castOther = (VocAssignSumCfgPK)other;
		return 
			this.whId.equals(castOther.whId)
			&& this.colnam.equals(castOther.colnam);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.colnam.hashCode();
		
		return hash;
	}
}