package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PKO_FLDS database table.
 * 
 */
@Embeddable
public class PkoFldPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String colnam;

	@Column(name="WH_ID")
	private String whId;

	@Column(name="AUD_TYP")
	private String audTyp;

	@Column(name="CLIENT_ID")
	private String clientId;

	public PkoFldPK() {
	}
	public String getColnam() {
		return this.colnam;
	}
	public void setColnam(String colnam) {
		this.colnam = colnam;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getAudTyp() {
		return this.audTyp;
	}
	public void setAudTyp(String audTyp) {
		this.audTyp = audTyp;
	}
	public String getClientId() {
		return this.clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PkoFldPK)) {
			return false;
		}
		PkoFldPK castOther = (PkoFldPK)other;
		return 
			this.colnam.equals(castOther.colnam)
			&& this.whId.equals(castOther.whId)
			&& this.audTyp.equals(castOther.audTyp)
			&& this.clientId.equals(castOther.clientId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.colnam.hashCode();
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.audTyp.hashCode();
		hash = hash * prime + this.clientId.hashCode();
		
		return hash;
	}
}