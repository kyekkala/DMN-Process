package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PRGMST database table.
 * 
 */
@Embeddable
public class PrgmstPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="INVSTS_PRG")
	private String invstsPrg;

	private String invsts;

	public PrgmstPK() {
	}
	public String getInvstsPrg() {
		return this.invstsPrg;
	}
	public void setInvstsPrg(String invstsPrg) {
		this.invstsPrg = invstsPrg;
	}
	public String getInvsts() {
		return this.invsts;
	}
	public void setInvsts(String invsts) {
		this.invsts = invsts;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PrgmstPK)) {
			return false;
		}
		PrgmstPK castOther = (PrgmstPK)other;
		return 
			this.invstsPrg.equals(castOther.invstsPrg)
			&& this.invsts.equals(castOther.invsts);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.invstsPrg.hashCode();
		hash = hash * prime + this.invsts.hashCode();
		
		return hash;
	}
}