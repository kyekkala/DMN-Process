package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SUPMST database table.
 * 
 */
@Entity
@NamedQuery(name="Supmst.findAll", query="SELECT s FROM Supmst s")
public class Supmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SupmstPK id;

	@Column(name="ADR_ID")
	private String adrId;

	@Column(name="ASSET_TYP")
	private String assetTyp;

	@Column(name="AUTORCV_FLG")
	private BigDecimal autorcvFlg;

	@Column(name="BAR_CODE_TMPL_ID")
	private String barCodeTmplId;

	@Column(name="CNSG_COD")
	private String cnsgCod;

	@Column(name="CNSG_PERIOD")
	private BigDecimal cnsgPeriod;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LOAD_ATTR1_CFG")
	private String loadAttr1Cfg;

	@Column(name="LOAD_ATTR2_CFG")
	private String loadAttr2Cfg;

	@Column(name="LOAD_ATTR3_CFG")
	private String loadAttr3Cfg;

	@Column(name="LOAD_ATTR4_CFG")
	private String loadAttr4Cfg;

	@Column(name="LOAD_ATTR5_CFG")
	private String loadAttr5Cfg;

	@Column(name="LOT_FMT_ID")
	private String lotFmtId;

	private String rcvsts;

	@Column(name="SER_NUM_TYP_ID")
	private String serNumTypId;

	@Column(name="TRK_CNSG_COD")
	private String trkCnsgCod;

	@Column(name="TRUST_FLG")
	private BigDecimal trustFlg;

	public Supmst() {
	}

	public SupmstPK getId() {
		return this.id;
	}

	public void setId(SupmstPK id) {
		this.id = id;
	}

	public String getAdrId() {
		return this.adrId;
	}

	public void setAdrId(String adrId) {
		this.adrId = adrId;
	}

	public String getAssetTyp() {
		return this.assetTyp;
	}

	public void setAssetTyp(String assetTyp) {
		this.assetTyp = assetTyp;
	}

	public BigDecimal getAutorcvFlg() {
		return this.autorcvFlg;
	}

	public void setAutorcvFlg(BigDecimal autorcvFlg) {
		this.autorcvFlg = autorcvFlg;
	}

	public String getBarCodeTmplId() {
		return this.barCodeTmplId;
	}

	public void setBarCodeTmplId(String barCodeTmplId) {
		this.barCodeTmplId = barCodeTmplId;
	}

	public String getCnsgCod() {
		return this.cnsgCod;
	}

	public void setCnsgCod(String cnsgCod) {
		this.cnsgCod = cnsgCod;
	}

	public BigDecimal getCnsgPeriod() {
		return this.cnsgPeriod;
	}

	public void setCnsgPeriod(BigDecimal cnsgPeriod) {
		this.cnsgPeriod = cnsgPeriod;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getLoadAttr1Cfg() {
		return this.loadAttr1Cfg;
	}

	public void setLoadAttr1Cfg(String loadAttr1Cfg) {
		this.loadAttr1Cfg = loadAttr1Cfg;
	}

	public String getLoadAttr2Cfg() {
		return this.loadAttr2Cfg;
	}

	public void setLoadAttr2Cfg(String loadAttr2Cfg) {
		this.loadAttr2Cfg = loadAttr2Cfg;
	}

	public String getLoadAttr3Cfg() {
		return this.loadAttr3Cfg;
	}

	public void setLoadAttr3Cfg(String loadAttr3Cfg) {
		this.loadAttr3Cfg = loadAttr3Cfg;
	}

	public String getLoadAttr4Cfg() {
		return this.loadAttr4Cfg;
	}

	public void setLoadAttr4Cfg(String loadAttr4Cfg) {
		this.loadAttr4Cfg = loadAttr4Cfg;
	}

	public String getLoadAttr5Cfg() {
		return this.loadAttr5Cfg;
	}

	public void setLoadAttr5Cfg(String loadAttr5Cfg) {
		this.loadAttr5Cfg = loadAttr5Cfg;
	}

	public String getLotFmtId() {
		return this.lotFmtId;
	}

	public void setLotFmtId(String lotFmtId) {
		this.lotFmtId = lotFmtId;
	}

	public String getRcvsts() {
		return this.rcvsts;
	}

	public void setRcvsts(String rcvsts) {
		this.rcvsts = rcvsts;
	}

	public String getSerNumTypId() {
		return this.serNumTypId;
	}

	public void setSerNumTypId(String serNumTypId) {
		this.serNumTypId = serNumTypId;
	}

	public String getTrkCnsgCod() {
		return this.trkCnsgCod;
	}

	public void setTrkCnsgCod(String trkCnsgCod) {
		this.trkCnsgCod = trkCnsgCod;
	}

	public BigDecimal getTrustFlg() {
		return this.trustFlg;
	}

	public void setTrustFlg(BigDecimal trustFlg) {
		this.trustFlg = trustFlg;
	}

}