package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the STO_TMPL_HDR database table.
 * 
 */
@Entity
@Table(name="STO_TMPL_HDR")
@NamedQuery(name="StoTmplHdr.findAll", query="SELECT s FROM StoTmplHdr s")
public class StoTmplHdr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="STO_TMPL_HDR_ID")
	private long stoTmplHdrId;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private BigDecimal levels;

	private BigDecimal positions;

	public StoTmplHdr() {
	}

	public long getStoTmplHdrId() {
		return this.stoTmplHdrId;
	}

	public void setStoTmplHdrId(long stoTmplHdrId) {
		this.stoTmplHdrId = stoTmplHdrId;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getLevels() {
		return this.levels;
	}

	public void setLevels(BigDecimal levels) {
		this.levels = levels;
	}

	public BigDecimal getPositions() {
		return this.positions;
	}

	public void setPositions(BigDecimal positions) {
		this.positions = positions;
	}

}