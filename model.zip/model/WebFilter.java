package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the WEB_FILTER database table.
 * 
 */
@Entity
@Table(name="WEB_FILTER")
@NamedQuery(name="WebFilter.findAll", query="SELECT w FROM WebFilter w")
public class WebFilter implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long id;

	private String dtype;

	@Column(name="FILTER_NAME")
	private String filterName;

	@Column(name="FILTER_TYPE")
	private String filterType;

	@Column(name="GROUP_ID")
	private BigDecimal groupId;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DATE")
	private Date insDate;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="MOD_DATE")
	private Date modDate;

	@Column(name="MOD_USER_ID")
	private String modUserId;

	public WebFilter() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDtype() {
		return this.dtype;
	}

	public void setDtype(String dtype) {
		this.dtype = dtype;
	}

	public String getFilterName() {
		return this.filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public String getFilterType() {
		return this.filterType;
	}

	public void setFilterType(String filterType) {
		this.filterType = filterType;
	}

	public BigDecimal getGroupId() {
		return this.groupId;
	}

	public void setGroupId(BigDecimal groupId) {
		this.groupId = groupId;
	}

	public Date getInsDate() {
		return this.insDate;
	}

	public void setInsDate(Date insDate) {
		this.insDate = insDate;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getModDate() {
		return this.modDate;
	}

	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}

	public String getModUserId() {
		return this.modUserId;
	}

	public void setModUserId(String modUserId) {
		this.modUserId = modUserId;
	}

}