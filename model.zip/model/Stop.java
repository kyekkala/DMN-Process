package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the "STOP" database table.
 * 
 */
@Entity
@Table(name="\"STOP\"")
@NamedQuery(name="Stop.findAll", query="SELECT s FROM Stop s")
public class Stop implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="STOP_ID")
	private String stopId;

	@Temporal(TemporalType.DATE)
	@Column(name="ACT_ARR_DTE")
	private Date actArrDte;

	@Temporal(TemporalType.DATE)
	@Column(name="ACT_DEP_DTE")
	private Date actDepDte;

	@Column(name="ACT_TIME")
	private BigDecimal actTime;

	@Column(name="ADR_ID")
	private String adrId;

	@Temporal(TemporalType.DATE)
	@Column(name="APPT_DTE")
	private Date apptDte;

	@Column(name="ARR_DIST")
	private BigDecimal arrDist;

	@Column(name="CAR_MOVE_ID")
	private String carMoveId;

	@Column(name="DOC_NUM")
	private String docNum;

	@Column(name="DRIVE_TIME")
	private BigDecimal driveTime;

	@Temporal(TemporalType.DATE)
	@Column(name="EXP_ARR_DTE")
	private Date expArrDte;

	@Temporal(TemporalType.DATE)
	@Column(name="EXP_DEP_DTE")
	private Date expDepDte;

	@Temporal(TemporalType.DATE)
	@Column(name="FIRST_ATMPT_DTE")
	private Date firstAtmptDte;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_ATMPT_DTE")
	private Date lastAtmptDte;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Temporal(TemporalType.DATE)
	@Column(name="ORIG_APPT_DTE")
	private Date origApptDte;

	@Temporal(TemporalType.DATE)
	@Column(name="PLN_ARR_DTE")
	private Date plnArrDte;

	@Temporal(TemporalType.DATE)
	@Column(name="PLN_DEP_DTE")
	private Date plnDepDte;

	@Column(name="STOP_CMPL_FLG")
	private BigDecimal stopCmplFlg;

	@Column(name="STOP_NAM")
	private String stopNam;

	@Column(name="STOP_SEAL")
	private String stopSeal;

	@Column(name="STOP_SEQ")
	private BigDecimal stopSeq;

	@Column(name="TMS_STOP_SEQ")
	private BigDecimal tmsStopSeq;

	@Column(name="TRACK_NUM")
	private String trackNum;

	@Column(name="WAIT_TIME")
	private BigDecimal waitTime;

	public Stop() {
	}

	public String getStopId() {
		return this.stopId;
	}

	public void setStopId(String stopId) {
		this.stopId = stopId;
	}

	public Date getActArrDte() {
		return this.actArrDte;
	}

	public void setActArrDte(Date actArrDte) {
		this.actArrDte = actArrDte;
	}

	public Date getActDepDte() {
		return this.actDepDte;
	}

	public void setActDepDte(Date actDepDte) {
		this.actDepDte = actDepDte;
	}

	public BigDecimal getActTime() {
		return this.actTime;
	}

	public void setActTime(BigDecimal actTime) {
		this.actTime = actTime;
	}

	public String getAdrId() {
		return this.adrId;
	}

	public void setAdrId(String adrId) {
		this.adrId = adrId;
	}

	public Date getApptDte() {
		return this.apptDte;
	}

	public void setApptDte(Date apptDte) {
		this.apptDte = apptDte;
	}

	public BigDecimal getArrDist() {
		return this.arrDist;
	}

	public void setArrDist(BigDecimal arrDist) {
		this.arrDist = arrDist;
	}

	public String getCarMoveId() {
		return this.carMoveId;
	}

	public void setCarMoveId(String carMoveId) {
		this.carMoveId = carMoveId;
	}

	public String getDocNum() {
		return this.docNum;
	}

	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	public BigDecimal getDriveTime() {
		return this.driveTime;
	}

	public void setDriveTime(BigDecimal driveTime) {
		this.driveTime = driveTime;
	}

	public Date getExpArrDte() {
		return this.expArrDte;
	}

	public void setExpArrDte(Date expArrDte) {
		this.expArrDte = expArrDte;
	}

	public Date getExpDepDte() {
		return this.expDepDte;
	}

	public void setExpDepDte(Date expDepDte) {
		this.expDepDte = expDepDte;
	}

	public Date getFirstAtmptDte() {
		return this.firstAtmptDte;
	}

	public void setFirstAtmptDte(Date firstAtmptDte) {
		this.firstAtmptDte = firstAtmptDte;
	}

	public Date getLastAtmptDte() {
		return this.lastAtmptDte;
	}

	public void setLastAtmptDte(Date lastAtmptDte) {
		this.lastAtmptDte = lastAtmptDte;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public Date getOrigApptDte() {
		return this.origApptDte;
	}

	public void setOrigApptDte(Date origApptDte) {
		this.origApptDte = origApptDte;
	}

	public Date getPlnArrDte() {
		return this.plnArrDte;
	}

	public void setPlnArrDte(Date plnArrDte) {
		this.plnArrDte = plnArrDte;
	}

	public Date getPlnDepDte() {
		return this.plnDepDte;
	}

	public void setPlnDepDte(Date plnDepDte) {
		this.plnDepDte = plnDepDte;
	}

	public BigDecimal getStopCmplFlg() {
		return this.stopCmplFlg;
	}

	public void setStopCmplFlg(BigDecimal stopCmplFlg) {
		this.stopCmplFlg = stopCmplFlg;
	}

	public String getStopNam() {
		return this.stopNam;
	}

	public void setStopNam(String stopNam) {
		this.stopNam = stopNam;
	}

	public String getStopSeal() {
		return this.stopSeal;
	}

	public void setStopSeal(String stopSeal) {
		this.stopSeal = stopSeal;
	}

	public BigDecimal getStopSeq() {
		return this.stopSeq;
	}

	public void setStopSeq(BigDecimal stopSeq) {
		this.stopSeq = stopSeq;
	}

	public BigDecimal getTmsStopSeq() {
		return this.tmsStopSeq;
	}

	public void setTmsStopSeq(BigDecimal tmsStopSeq) {
		this.tmsStopSeq = tmsStopSeq;
	}

	public String getTrackNum() {
		return this.trackNum;
	}

	public void setTrackNum(String trackNum) {
		this.trackNum = trackNum;
	}

	public BigDecimal getWaitTime() {
		return this.waitTime;
	}

	public void setWaitTime(BigDecimal waitTime) {
		this.waitTime = waitTime;
	}

}