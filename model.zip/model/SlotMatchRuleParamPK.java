package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the SLOT_MATCH_RULE_PARAMS database table.
 * 
 */
@Embeddable
public class SlotMatchRuleParamPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="MATCH_RULE_NAM")
	private String matchRuleNam;

	@Column(name="MATCH_RULE_PARAM")
	private String matchRuleParam;

	public SlotMatchRuleParamPK() {
	}
	public String getMatchRuleNam() {
		return this.matchRuleNam;
	}
	public void setMatchRuleNam(String matchRuleNam) {
		this.matchRuleNam = matchRuleNam;
	}
	public String getMatchRuleParam() {
		return this.matchRuleParam;
	}
	public void setMatchRuleParam(String matchRuleParam) {
		this.matchRuleParam = matchRuleParam;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SlotMatchRuleParamPK)) {
			return false;
		}
		SlotMatchRuleParamPK castOther = (SlotMatchRuleParamPK)other;
		return 
			this.matchRuleNam.equals(castOther.matchRuleNam)
			&& this.matchRuleParam.equals(castOther.matchRuleParam);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.matchRuleNam.hashCode();
		hash = hash * prime + this.matchRuleParam.hashCode();
		
		return hash;
	}
}