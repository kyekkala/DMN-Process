package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the WKAMST database table.
 * 
 */
@Embeddable
public class WkamstPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String wrkare;

	@Column(name="WH_ID")
	private String whId;

	public WkamstPK() {
	}
	public String getWrkare() {
		return this.wrkare;
	}
	public void setWrkare(String wrkare) {
		this.wrkare = wrkare;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof WkamstPK)) {
			return false;
		}
		WkamstPK castOther = (WkamstPK)other;
		return 
			this.wrkare.equals(castOther.wrkare)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.wrkare.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}