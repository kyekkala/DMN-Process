package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CNFRM_SERV_INS database table.
 * 
 */
@Entity
@Table(name="CNFRM_SERV_INS")
@NamedQuery(name="CnfrmServIn.findAll", query="SELECT c FROM CnfrmServIn c")
public class CnfrmServIn implements Serializable {
	private static final long serialVersionUID = 1L;

	public CnfrmServIn() {
	}

}