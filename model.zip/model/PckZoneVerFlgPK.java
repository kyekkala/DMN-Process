package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PCK_ZONE_VER_FLG database table.
 * 
 */
@Embeddable
public class PckZoneVerFlgPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SRC_PCK_ZONE_ID")
	private long srcPckZoneId;

	private String lodlvl;

	private String wrktyp;

	public PckZoneVerFlgPK() {
	}
	public long getSrcPckZoneId() {
		return this.srcPckZoneId;
	}
	public void setSrcPckZoneId(long srcPckZoneId) {
		this.srcPckZoneId = srcPckZoneId;
	}
	public String getLodlvl() {
		return this.lodlvl;
	}
	public void setLodlvl(String lodlvl) {
		this.lodlvl = lodlvl;
	}
	public String getWrktyp() {
		return this.wrktyp;
	}
	public void setWrktyp(String wrktyp) {
		this.wrktyp = wrktyp;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PckZoneVerFlgPK)) {
			return false;
		}
		PckZoneVerFlgPK castOther = (PckZoneVerFlgPK)other;
		return 
			(this.srcPckZoneId == castOther.srcPckZoneId)
			&& this.lodlvl.equals(castOther.lodlvl)
			&& this.wrktyp.equals(castOther.wrktyp);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.srcPckZoneId ^ (this.srcPckZoneId >>> 32)));
		hash = hash * prime + this.lodlvl.hashCode();
		hash = hash * prime + this.wrktyp.hashCode();
		
		return hash;
	}
}