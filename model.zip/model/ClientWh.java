package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CLIENT_WH database table.
 * 
 */
@Entity
@Table(name="CLIENT_WH")
@NamedQuery(name="ClientWh.findAll", query="SELECT c FROM ClientWh c")
public class ClientWh implements Serializable {
	private static final long serialVersionUID = 1L;

	public ClientWh() {
	}

}