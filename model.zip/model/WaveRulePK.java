package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the WAVE_RULE database table.
 * 
 */
@Embeddable
public class WaveRulePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="RULE_NAM")
	private String ruleNam;

	private long dumkey;

	public WaveRulePK() {
	}
	public String getRuleNam() {
		return this.ruleNam;
	}
	public void setRuleNam(String ruleNam) {
		this.ruleNam = ruleNam;
	}
	public long getDumkey() {
		return this.dumkey;
	}
	public void setDumkey(long dumkey) {
		this.dumkey = dumkey;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof WaveRulePK)) {
			return false;
		}
		WaveRulePK castOther = (WaveRulePK)other;
		return 
			this.ruleNam.equals(castOther.ruleNam)
			&& (this.dumkey == castOther.dumkey);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.ruleNam.hashCode();
		hash = hash * prime + ((int) (this.dumkey ^ (this.dumkey >>> 32)));
		
		return hash;
	}
}