package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the WH_SERV database table.
 * 
 */
@Entity
@Table(name="WH_SERV")
@NamedQuery(name="WhServ.findAll", query="SELECT w FROM WhServ w")
public class WhServ implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private WhServPK id;

	@Column(name="ACCUM_FLG")
	private BigDecimal accumFlg;

	@Column(name="AUDIT_THRESH_COST")
	private BigDecimal auditThreshCost;

	@Column(name="CRNCY_CODE")
	private String crncyCode;

	private String lodlvl;

	@Column(name="MIXED_PRT_FLG")
	private BigDecimal mixedPrtFlg;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private BigDecimal seqnum;

	@Column(name="SERV_ENAFLG")
	private BigDecimal servEnaflg;

	@Column(name="SPEC_SERV_COD")
	private String specServCod;

	public WhServ() {
	}

	public WhServPK getId() {
		return this.id;
	}

	public void setId(WhServPK id) {
		this.id = id;
	}

	public BigDecimal getAccumFlg() {
		return this.accumFlg;
	}

	public void setAccumFlg(BigDecimal accumFlg) {
		this.accumFlg = accumFlg;
	}

	public BigDecimal getAuditThreshCost() {
		return this.auditThreshCost;
	}

	public void setAuditThreshCost(BigDecimal auditThreshCost) {
		this.auditThreshCost = auditThreshCost;
	}

	public String getCrncyCode() {
		return this.crncyCode;
	}

	public void setCrncyCode(String crncyCode) {
		this.crncyCode = crncyCode;
	}

	public String getLodlvl() {
		return this.lodlvl;
	}

	public void setLodlvl(String lodlvl) {
		this.lodlvl = lodlvl;
	}

	public BigDecimal getMixedPrtFlg() {
		return this.mixedPrtFlg;
	}

	public void setMixedPrtFlg(BigDecimal mixedPrtFlg) {
		this.mixedPrtFlg = mixedPrtFlg;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getSeqnum() {
		return this.seqnum;
	}

	public void setSeqnum(BigDecimal seqnum) {
		this.seqnum = seqnum;
	}

	public BigDecimal getServEnaflg() {
		return this.servEnaflg;
	}

	public void setServEnaflg(BigDecimal servEnaflg) {
		this.servEnaflg = servEnaflg;
	}

	public String getSpecServCod() {
		return this.specServCod;
	}

	public void setSpecServCod(String specServCod) {
		this.specServCod = specServCod;
	}

}