package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the ASYNC_GROUP database table.
 * 
 */
@Entity
@Table(name="ASYNC_GROUP")
@NamedQuery(name="AsyncGroup.findAll", query="SELECT a FROM AsyncGroup a")
public class AsyncGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ASYNC_GROUP_ID")
	private long asyncGroupId;

	@Column(name="ASYNC_TYP")
	private String asyncTyp;

	@Column(name="CLIENT_ID")
	private String clientId;

	@Temporal(TemporalType.DATE)
	private Date credte;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="WH_ID")
	private String whId;

	public AsyncGroup() {
	}

	public long getAsyncGroupId() {
		return this.asyncGroupId;
	}

	public void setAsyncGroupId(long asyncGroupId) {
		this.asyncGroupId = asyncGroupId;
	}

	public String getAsyncTyp() {
		return this.asyncTyp;
	}

	public void setAsyncTyp(String asyncTyp) {
		this.asyncTyp = asyncTyp;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public Date getCredte() {
		return this.credte;
	}

	public void setCredte(Date credte) {
		this.credte = credte;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}