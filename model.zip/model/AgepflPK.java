package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the AGEPFL database table.
 * 
 */
@Embeddable
public class AgepflPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="AGE_PFLNAM")
	private String agePflnam;

	private String invsts;

	public AgepflPK() {
	}
	public String getAgePflnam() {
		return this.agePflnam;
	}
	public void setAgePflnam(String agePflnam) {
		this.agePflnam = agePflnam;
	}
	public String getInvsts() {
		return this.invsts;
	}
	public void setInvsts(String invsts) {
		this.invsts = invsts;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AgepflPK)) {
			return false;
		}
		AgepflPK castOther = (AgepflPK)other;
		return 
			this.agePflnam.equals(castOther.agePflnam)
			&& this.invsts.equals(castOther.invsts);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.agePflnam.hashCode();
		hash = hash * prime + this.invsts.hashCode();
		
		return hash;
	}
}