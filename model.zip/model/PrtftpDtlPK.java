package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PRTFTP_DTL database table.
 * 
 */
@Embeddable
public class PrtftpDtlPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String prtnum;

	@Column(name="PRT_CLIENT_ID")
	private String prtClientId;

	@Column(name="WH_ID")
	private String whId;

	private String ftpcod;

	private String uomcod;

	public PrtftpDtlPK() {
	}
	public String getPrtnum() {
		return this.prtnum;
	}
	public void setPrtnum(String prtnum) {
		this.prtnum = prtnum;
	}
	public String getPrtClientId() {
		return this.prtClientId;
	}
	public void setPrtClientId(String prtClientId) {
		this.prtClientId = prtClientId;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getFtpcod() {
		return this.ftpcod;
	}
	public void setFtpcod(String ftpcod) {
		this.ftpcod = ftpcod;
	}
	public String getUomcod() {
		return this.uomcod;
	}
	public void setUomcod(String uomcod) {
		this.uomcod = uomcod;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PrtftpDtlPK)) {
			return false;
		}
		PrtftpDtlPK castOther = (PrtftpDtlPK)other;
		return 
			this.prtnum.equals(castOther.prtnum)
			&& this.prtClientId.equals(castOther.prtClientId)
			&& this.whId.equals(castOther.whId)
			&& this.ftpcod.equals(castOther.ftpcod)
			&& this.uomcod.equals(castOther.uomcod);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.prtnum.hashCode();
		hash = hash * prime + this.prtClientId.hashCode();
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.ftpcod.hashCode();
		hash = hash * prime + this.uomcod.hashCode();
		
		return hash;
	}
}