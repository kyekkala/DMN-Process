package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the ORD_TYP database table.
 * 
 */
@Entity
@Table(name="ORD_TYP")
@NamedQuery(name="OrdTyp.findAll", query="SELECT o FROM OrdTyp o")
public class OrdTyp implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrdTypPK id;

	@Column(name="ALLOW_SHP_RES_FLG")
	private BigDecimal allowShpResFlg;

	@Column(name="BULK_PCK_FLG")
	private BigDecimal bulkPckFlg;

	@Column(name="GS1_ORDTYP")
	private String gs1Ordtyp;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="PCL_VAL_FLG")
	private BigDecimal pclValFlg;

	@Column(name="SHP_CTNRTE_FLG")
	private BigDecimal shpCtnrteFlg;

	@Column(name="WM_DEFAULT_FLG")
	private BigDecimal wmDefaultFlg;

	public OrdTyp() {
	}

	public OrdTypPK getId() {
		return this.id;
	}

	public void setId(OrdTypPK id) {
		this.id = id;
	}

	public BigDecimal getAllowShpResFlg() {
		return this.allowShpResFlg;
	}

	public void setAllowShpResFlg(BigDecimal allowShpResFlg) {
		this.allowShpResFlg = allowShpResFlg;
	}

	public BigDecimal getBulkPckFlg() {
		return this.bulkPckFlg;
	}

	public void setBulkPckFlg(BigDecimal bulkPckFlg) {
		this.bulkPckFlg = bulkPckFlg;
	}

	public String getGs1Ordtyp() {
		return this.gs1Ordtyp;
	}

	public void setGs1Ordtyp(String gs1Ordtyp) {
		this.gs1Ordtyp = gs1Ordtyp;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getPclValFlg() {
		return this.pclValFlg;
	}

	public void setPclValFlg(BigDecimal pclValFlg) {
		this.pclValFlg = pclValFlg;
	}

	public BigDecimal getShpCtnrteFlg() {
		return this.shpCtnrteFlg;
	}

	public void setShpCtnrteFlg(BigDecimal shpCtnrteFlg) {
		this.shpCtnrteFlg = shpCtnrteFlg;
	}

	public BigDecimal getWmDefaultFlg() {
		return this.wmDefaultFlg;
	}

	public void setWmDefaultFlg(BigDecimal wmDefaultFlg) {
		this.wmDefaultFlg = wmDefaultFlg;
	}

}