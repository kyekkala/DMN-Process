package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the INVSUB database table.
 * 
 */
@Entity
@NamedQuery(name="Invsub.findAll", query="SELECT i FROM Invsub i")
public class Invsub implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String subnum;

	@Temporal(TemporalType.DATE)
	private Date adddte;

	@Column(name="ASSET_TYP")
	private String assetTyp;

	private BigDecimal ctnflg;

	@Column(name="DISTRO_CTNOPN_FLG")
	private BigDecimal distroCtnopnFlg;

	@Column(name="EST_SUBWGT")
	private BigDecimal estSubwgt;

	private BigDecimal idmflg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private String lodnum;

	@Column(name="LST_USR_ID")
	private String lstUsrId;

	private String lstcod;

	@Temporal(TemporalType.DATE)
	private Date lstdte;

	@Temporal(TemporalType.DATE)
	private Date lstmov;

	private BigDecimal mvsflg;

	@Column(name="PCK_SUB_FLG")
	private BigDecimal pckSubFlg;

	private BigDecimal phyflg;

	private BigDecimal prmflg;

	@Column(name="SUB_TAGSTS")
	private String subTagsts;

	private String subtag;

	private String subucc;

	private BigDecimal subwgt;

	private String tagdev;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	@Temporal(TemporalType.DATE)
	private Date uccdte;

	private String wrkref;

	public Invsub() {
	}

	public String getSubnum() {
		return this.subnum;
	}

	public void setSubnum(String subnum) {
		this.subnum = subnum;
	}

	public Date getAdddte() {
		return this.adddte;
	}

	public void setAdddte(Date adddte) {
		this.adddte = adddte;
	}

	public String getAssetTyp() {
		return this.assetTyp;
	}

	public void setAssetTyp(String assetTyp) {
		this.assetTyp = assetTyp;
	}

	public BigDecimal getCtnflg() {
		return this.ctnflg;
	}

	public void setCtnflg(BigDecimal ctnflg) {
		this.ctnflg = ctnflg;
	}

	public BigDecimal getDistroCtnopnFlg() {
		return this.distroCtnopnFlg;
	}

	public void setDistroCtnopnFlg(BigDecimal distroCtnopnFlg) {
		this.distroCtnopnFlg = distroCtnopnFlg;
	}

	public BigDecimal getEstSubwgt() {
		return this.estSubwgt;
	}

	public void setEstSubwgt(BigDecimal estSubwgt) {
		this.estSubwgt = estSubwgt;
	}

	public BigDecimal getIdmflg() {
		return this.idmflg;
	}

	public void setIdmflg(BigDecimal idmflg) {
		this.idmflg = idmflg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getLodnum() {
		return this.lodnum;
	}

	public void setLodnum(String lodnum) {
		this.lodnum = lodnum;
	}

	public String getLstUsrId() {
		return this.lstUsrId;
	}

	public void setLstUsrId(String lstUsrId) {
		this.lstUsrId = lstUsrId;
	}

	public String getLstcod() {
		return this.lstcod;
	}

	public void setLstcod(String lstcod) {
		this.lstcod = lstcod;
	}

	public Date getLstdte() {
		return this.lstdte;
	}

	public void setLstdte(Date lstdte) {
		this.lstdte = lstdte;
	}

	public Date getLstmov() {
		return this.lstmov;
	}

	public void setLstmov(Date lstmov) {
		this.lstmov = lstmov;
	}

	public BigDecimal getMvsflg() {
		return this.mvsflg;
	}

	public void setMvsflg(BigDecimal mvsflg) {
		this.mvsflg = mvsflg;
	}

	public BigDecimal getPckSubFlg() {
		return this.pckSubFlg;
	}

	public void setPckSubFlg(BigDecimal pckSubFlg) {
		this.pckSubFlg = pckSubFlg;
	}

	public BigDecimal getPhyflg() {
		return this.phyflg;
	}

	public void setPhyflg(BigDecimal phyflg) {
		this.phyflg = phyflg;
	}

	public BigDecimal getPrmflg() {
		return this.prmflg;
	}

	public void setPrmflg(BigDecimal prmflg) {
		this.prmflg = prmflg;
	}

	public String getSubTagsts() {
		return this.subTagsts;
	}

	public void setSubTagsts(String subTagsts) {
		this.subTagsts = subTagsts;
	}

	public String getSubtag() {
		return this.subtag;
	}

	public void setSubtag(String subtag) {
		this.subtag = subtag;
	}

	public String getSubucc() {
		return this.subucc;
	}

	public void setSubucc(String subucc) {
		this.subucc = subucc;
	}

	public BigDecimal getSubwgt() {
		return this.subwgt;
	}

	public void setSubwgt(BigDecimal subwgt) {
		this.subwgt = subwgt;
	}

	public String getTagdev() {
		return this.tagdev;
	}

	public void setTagdev(String tagdev) {
		this.tagdev = tagdev;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

	public Date getUccdte() {
		return this.uccdte;
	}

	public void setUccdte(Date uccdte) {
		this.uccdte = uccdte;
	}

	public String getWrkref() {
		return this.wrkref;
	}

	public void setWrkref(String wrkref) {
		this.wrkref = wrkref;
	}

}