package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the INB_SERV_RCVINV database table.
 * 
 */
@Entity
@Table(name="INB_SERV_RCVINV")
@NamedQuery(name="InbServRcvinv.findAll", query="SELECT i FROM InbServRcvinv i")
public class InbServRcvinv implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private InbServRcvinvPK id;

	@Temporal(TemporalType.DATE)
	private Date adddte;

	@Column(name="DEF_SERV_COD")
	private String defServCod;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="SERV_REQ_FLG")
	private BigDecimal servReqFlg;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	public InbServRcvinv() {
	}

	public InbServRcvinvPK getId() {
		return this.id;
	}

	public void setId(InbServRcvinvPK id) {
		this.id = id;
	}

	public Date getAdddte() {
		return this.adddte;
	}

	public void setAdddte(Date adddte) {
		this.adddte = adddte;
	}

	public String getDefServCod() {
		return this.defServCod;
	}

	public void setDefServCod(String defServCod) {
		this.defServCod = defServCod;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getServReqFlg() {
		return this.servReqFlg;
	}

	public void setServReqFlg(BigDecimal servReqFlg) {
		this.servReqFlg = servReqFlg;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

}