package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the AISLE_DCKLOC database table.
 * 
 */
@Entity
@Table(name="AISLE_DCKLOC")
@NamedQuery(name="AisleDckloc.findAll", query="SELECT a FROM AisleDckloc a")
public class AisleDckloc implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private AisleDcklocPK id;

	@Column(name="AISLE_ID")
	private String aisleId;

	@Column(name="BLDG_ID")
	private String bldgId;

	private String dckloc;

	private String dckmode;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="SEQNUM_PRIMARY")
	private BigDecimal seqnumPrimary;

	@Column(name="SEQNUM_SECONDARY")
	private BigDecimal seqnumSecondary;

	private String stgloc;

	public AisleDckloc() {
	}

	public AisleDcklocPK getId() {
		return this.id;
	}

	public void setId(AisleDcklocPK id) {
		this.id = id;
	}

	public String getAisleId() {
		return this.aisleId;
	}

	public void setAisleId(String aisleId) {
		this.aisleId = aisleId;
	}

	public String getBldgId() {
		return this.bldgId;
	}

	public void setBldgId(String bldgId) {
		this.bldgId = bldgId;
	}

	public String getDckloc() {
		return this.dckloc;
	}

	public void setDckloc(String dckloc) {
		this.dckloc = dckloc;
	}

	public String getDckmode() {
		return this.dckmode;
	}

	public void setDckmode(String dckmode) {
		this.dckmode = dckmode;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getSeqnumPrimary() {
		return this.seqnumPrimary;
	}

	public void setSeqnumPrimary(BigDecimal seqnumPrimary) {
		this.seqnumPrimary = seqnumPrimary;
	}

	public BigDecimal getSeqnumSecondary() {
		return this.seqnumSecondary;
	}

	public void setSeqnumSecondary(BigDecimal seqnumSecondary) {
		this.seqnumSecondary = seqnumSecondary;
	}

	public String getStgloc() {
		return this.stgloc;
	}

	public void setStgloc(String stgloc) {
		this.stgloc = stgloc;
	}

}