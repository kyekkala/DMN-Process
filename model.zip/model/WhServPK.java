package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the WH_SERV database table.
 * 
 */
@Embeddable
public class WhServPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SERV_ID")
	private String servId;

	@Column(name="WH_ID")
	private String whId;

	public WhServPK() {
	}
	public String getServId() {
		return this.servId;
	}
	public void setServId(String servId) {
		this.servId = servId;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof WhServPK)) {
			return false;
		}
		WhServPK castOther = (WhServPK)other;
		return 
			this.servId.equals(castOther.servId)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.servId.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}