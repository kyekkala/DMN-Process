package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the WAVE_RULE database table.
 * 
 */
@Entity
@Table(name="WAVE_RULE")
@NamedQuery(name="WaveRule.findAll", query="SELECT w FROM WaveRule w")
public class WaveRule implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private WaveRulePK id;

	private String cmd;

	private BigDecimal srtseq;

	public WaveRule() {
	}

	public WaveRulePK getId() {
		return this.id;
	}

	public void setId(WaveRulePK id) {
		this.id = id;
	}

	public String getCmd() {
		return this.cmd;
	}

	public void setCmd(String cmd) {
		this.cmd = cmd;
	}

	public BigDecimal getSrtseq() {
		return this.srtseq;
	}

	public void setSrtseq(BigDecimal srtseq) {
		this.srtseq = srtseq;
	}

}