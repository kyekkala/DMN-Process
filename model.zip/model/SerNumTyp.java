package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SER_NUM_TYP database table.
 * 
 */
@Entity
@Table(name="SER_NUM_TYP")
@NamedQuery(name="SerNumTyp.findAll", query="SELECT s FROM SerNumTyp s")
public class SerNumTyp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SER_NUM_TYP_ID")
	private String serNumTypId;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="RPT_TO_HOST_FLG")
	private BigDecimal rptToHostFlg;

	@Column(name="SER_MSK")
	private String serMsk;

	private BigDecimal srtseq;

	public SerNumTyp() {
	}

	public String getSerNumTypId() {
		return this.serNumTypId;
	}

	public void setSerNumTypId(String serNumTypId) {
		this.serNumTypId = serNumTypId;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getRptToHostFlg() {
		return this.rptToHostFlg;
	}

	public void setRptToHostFlg(BigDecimal rptToHostFlg) {
		this.rptToHostFlg = rptToHostFlg;
	}

	public String getSerMsk() {
		return this.serMsk;
	}

	public void setSerMsk(String serMsk) {
		this.serMsk = serMsk;
	}

	public BigDecimal getSrtseq() {
		return this.srtseq;
	}

	public void setSrtseq(BigDecimal srtseq) {
		this.srtseq = srtseq;
	}

}