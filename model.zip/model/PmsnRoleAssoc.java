package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the PMSN_ROLE_ASSOC database table.
 * 
 */
@Entity
@Table(name="PMSN_ROLE_ASSOC")
@NamedQuery(name="PmsnRoleAssoc.findAll", query="SELECT p FROM PmsnRoleAssoc p")
public class PmsnRoleAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PmsnRoleAssocPK id;

	@Column(name="PMSN_MASK")
	private BigDecimal pmsnMask;

	public PmsnRoleAssoc() {
	}

	public PmsnRoleAssocPK getId() {
		return this.id;
	}

	public void setId(PmsnRoleAssocPK id) {
		this.id = id;
	}

	public BigDecimal getPmsnMask() {
		return this.pmsnMask;
	}

	public void setPmsnMask(BigDecimal pmsnMask) {
		this.pmsnMask = pmsnMask;
	}

}