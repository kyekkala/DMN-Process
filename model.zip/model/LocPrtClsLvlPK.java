package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the LOC_PRT_CLS_LVL database table.
 * 
 */
@Embeddable
public class LocPrtClsLvlPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String stoloc;

	@Column(name="WH_ID")
	private String whId;

	public LocPrtClsLvlPK() {
	}
	public String getStoloc() {
		return this.stoloc;
	}
	public void setStoloc(String stoloc) {
		this.stoloc = stoloc;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof LocPrtClsLvlPK)) {
			return false;
		}
		LocPrtClsLvlPK castOther = (LocPrtClsLvlPK)other;
		return 
			this.stoloc.equals(castOther.stoloc)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.stoloc.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}