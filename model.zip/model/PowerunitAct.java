package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the POWERUNIT_ACT database table.
 * 
 */
@Entity
@Table(name="POWERUNIT_ACT")
@NamedQuery(name="PowerunitAct.findAll", query="SELECT p FROM PowerunitAct p")
public class PowerunitAct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="POWERUNIT_ACT_ID")
	private String powerunitActId;

	private String actcod;

	private String carcod;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Column(name="POWERUNIT_ID")
	private String powerunitId;

	@Column(name="POWERUNIT_NUM")
	private String powerunitNum;

	@Column(name="POWERUNIT_STS")
	private String powerunitSts;

	@Column(name="TRLR_CARCOD")
	private String trlrCarcod;

	@Column(name="TRLR_ID")
	private String trlrId;

	@Column(name="TRLR_NUM")
	private String trlrNum;

	@Temporal(TemporalType.DATE)
	private Date trndte;

	@Column(name="YARD_LOC")
	private String yardLoc;

	public PowerunitAct() {
	}

	public String getPowerunitActId() {
		return this.powerunitActId;
	}

	public void setPowerunitActId(String powerunitActId) {
		this.powerunitActId = powerunitActId;
	}

	public String getActcod() {
		return this.actcod;
	}

	public void setActcod(String actcod) {
		this.actcod = actcod;
	}

	public String getCarcod() {
		return this.carcod;
	}

	public void setCarcod(String carcod) {
		this.carcod = carcod;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public String getPowerunitId() {
		return this.powerunitId;
	}

	public void setPowerunitId(String powerunitId) {
		this.powerunitId = powerunitId;
	}

	public String getPowerunitNum() {
		return this.powerunitNum;
	}

	public void setPowerunitNum(String powerunitNum) {
		this.powerunitNum = powerunitNum;
	}

	public String getPowerunitSts() {
		return this.powerunitSts;
	}

	public void setPowerunitSts(String powerunitSts) {
		this.powerunitSts = powerunitSts;
	}

	public String getTrlrCarcod() {
		return this.trlrCarcod;
	}

	public void setTrlrCarcod(String trlrCarcod) {
		this.trlrCarcod = trlrCarcod;
	}

	public String getTrlrId() {
		return this.trlrId;
	}

	public void setTrlrId(String trlrId) {
		this.trlrId = trlrId;
	}

	public String getTrlrNum() {
		return this.trlrNum;
	}

	public void setTrlrNum(String trlrNum) {
		this.trlrNum = trlrNum;
	}

	public Date getTrndte() {
		return this.trndte;
	}

	public void setTrndte(Date trndte) {
		this.trndte = trndte;
	}

	public String getYardLoc() {
		return this.yardLoc;
	}

	public void setYardLoc(String yardLoc) {
		this.yardLoc = yardLoc;
	}

}