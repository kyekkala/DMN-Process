package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the PRTDSC database table.
 * 
 */
@Entity
@NamedQuery(name="Prtdsc.findAll", query="SELECT p FROM Prtdsc p")
public class Prtdsc implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PrtdscPK id;

	private String lngdsc;

	@Column(name="SHORT_DSC")
	private String shortDsc;

	public Prtdsc() {
	}

	public PrtdscPK getId() {
		return this.id;
	}

	public void setId(PrtdscPK id) {
		this.id = id;
	}

	public String getLngdsc() {
		return this.lngdsc;
	}

	public void setLngdsc(String lngdsc) {
		this.lngdsc = lngdsc;
	}

	public String getShortDsc() {
		return this.shortDsc;
	}

	public void setShortDsc(String shortDsc) {
		this.shortDsc = shortDsc;
	}

}