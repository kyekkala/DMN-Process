package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LOC_TYP database table.
 * 
 */
@Entity
@Table(name="LOC_TYP")
@NamedQuery(name="LocTyp.findAll", query="SELECT l FROM LocTyp l")
public class LocTyp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LOC_TYP_ID")
	private long locTypId;

	private BigDecimal adjflg;

	@Column(name="AUTCLR_PRCARE")
	private BigDecimal autclrPrcare;

	@Column(name="BCKFILL_FLG")
	private BigDecimal bckfillFlg;

	@Column(name="CAP_CW_DEP_FLG")
	private BigDecimal capCwDepFlg;

	@Column(name="DEF_RCV_INVSTS")
	private String defRcvInvsts;

	@Column(name="DISPATCH_FLG")
	private BigDecimal dispatchFlg;

	@Column(name="DSTR_FLG")
	private BigDecimal dstrFlg;

	@Column(name="DSTR_PCK_CTN_FLG")
	private BigDecimal dstrPckCtnFlg;

	@Column(name="DSTR_PCK_PAL_FLG")
	private BigDecimal dstrPckPalFlg;

	@Column(name="DSTR_SUG_CTN_FLG")
	private BigDecimal dstrSugCtnFlg;

	@Column(name="DSTR_SUG_PAL_FLG")
	private BigDecimal dstrSugPalFlg;

	private BigDecimal expflg;

	@Column(name="FTL_FLG")
	private BigDecimal ftlFlg;

	private BigDecimal fwiflg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LOC_OVRD_FLG")
	private BigDecimal locOvrdFlg;

	@Column(name="LOC_TYP")
	private String locTyp;

	@Column(name="LOC_TYP_CAT")
	private String locTypCat;

	@Column(name="LPN_MIX_FLG")
	private BigDecimal lpnMixFlg;

	@Column(name="MIX_SHPRCV_FLG")
	private BigDecimal mixShprcvFlg;

	@Column(name="PCK_TO_STO_FLG")
	private BigDecimal pckToStoFlg;

	private BigDecimal pdflg;

	private BigDecimal praflg;

	@Column(name="PRD_STGFLG")
	private BigDecimal prdStgflg;

	@Column(name="PROD_FLG")
	private BigDecimal prodFlg;

	@Column(name="PUT_TO_STO_FLG")
	private BigDecimal putToStoFlg;

	@Column(name="RCV_DCK_FLG")
	private BigDecimal rcvDckFlg;

	@Column(name="RCV_STGFLG")
	private BigDecimal rcvStgflg;

	@Column(name="RCVWO_NON_FWIFLG")
	private BigDecimal rcvwoNonFwiflg;

	private BigDecimal rdtflg;

	@Column(name="REM_LPN_FLG")
	private BigDecimal remLpnFlg;

	@Column(name="SHARE_LOC_FLG")
	private BigDecimal shareLocFlg;

	@Column(name="SHP_DCK_FLG")
	private BigDecimal shpDckFlg;

	private BigDecimal shpflg;

	private BigDecimal sigflg;

	private BigDecimal stgflg;

	@Column(name="STO_TRLR_FLG")
	private BigDecimal stoTrlrFlg;

	@Column(name="STOARE_FLG")
	private BigDecimal stoareFlg;

	@Column(name="WH_ID")
	private String whId;

	@Column(name="WIP_EXPFLG")
	private BigDecimal wipExpflg;

	@Column(name="WIP_SUPFLG")
	private BigDecimal wipSupflg;

	private BigDecimal wipflg;

	private BigDecimal xdaflg;

	private BigDecimal yrdflg;

	public LocTyp() {
	}

	public long getLocTypId() {
		return this.locTypId;
	}

	public void setLocTypId(long locTypId) {
		this.locTypId = locTypId;
	}

	public BigDecimal getAdjflg() {
		return this.adjflg;
	}

	public void setAdjflg(BigDecimal adjflg) {
		this.adjflg = adjflg;
	}

	public BigDecimal getAutclrPrcare() {
		return this.autclrPrcare;
	}

	public void setAutclrPrcare(BigDecimal autclrPrcare) {
		this.autclrPrcare = autclrPrcare;
	}

	public BigDecimal getBckfillFlg() {
		return this.bckfillFlg;
	}

	public void setBckfillFlg(BigDecimal bckfillFlg) {
		this.bckfillFlg = bckfillFlg;
	}

	public BigDecimal getCapCwDepFlg() {
		return this.capCwDepFlg;
	}

	public void setCapCwDepFlg(BigDecimal capCwDepFlg) {
		this.capCwDepFlg = capCwDepFlg;
	}

	public String getDefRcvInvsts() {
		return this.defRcvInvsts;
	}

	public void setDefRcvInvsts(String defRcvInvsts) {
		this.defRcvInvsts = defRcvInvsts;
	}

	public BigDecimal getDispatchFlg() {
		return this.dispatchFlg;
	}

	public void setDispatchFlg(BigDecimal dispatchFlg) {
		this.dispatchFlg = dispatchFlg;
	}

	public BigDecimal getDstrFlg() {
		return this.dstrFlg;
	}

	public void setDstrFlg(BigDecimal dstrFlg) {
		this.dstrFlg = dstrFlg;
	}

	public BigDecimal getDstrPckCtnFlg() {
		return this.dstrPckCtnFlg;
	}

	public void setDstrPckCtnFlg(BigDecimal dstrPckCtnFlg) {
		this.dstrPckCtnFlg = dstrPckCtnFlg;
	}

	public BigDecimal getDstrPckPalFlg() {
		return this.dstrPckPalFlg;
	}

	public void setDstrPckPalFlg(BigDecimal dstrPckPalFlg) {
		this.dstrPckPalFlg = dstrPckPalFlg;
	}

	public BigDecimal getDstrSugCtnFlg() {
		return this.dstrSugCtnFlg;
	}

	public void setDstrSugCtnFlg(BigDecimal dstrSugCtnFlg) {
		this.dstrSugCtnFlg = dstrSugCtnFlg;
	}

	public BigDecimal getDstrSugPalFlg() {
		return this.dstrSugPalFlg;
	}

	public void setDstrSugPalFlg(BigDecimal dstrSugPalFlg) {
		this.dstrSugPalFlg = dstrSugPalFlg;
	}

	public BigDecimal getExpflg() {
		return this.expflg;
	}

	public void setExpflg(BigDecimal expflg) {
		this.expflg = expflg;
	}

	public BigDecimal getFtlFlg() {
		return this.ftlFlg;
	}

	public void setFtlFlg(BigDecimal ftlFlg) {
		this.ftlFlg = ftlFlg;
	}

	public BigDecimal getFwiflg() {
		return this.fwiflg;
	}

	public void setFwiflg(BigDecimal fwiflg) {
		this.fwiflg = fwiflg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getLocOvrdFlg() {
		return this.locOvrdFlg;
	}

	public void setLocOvrdFlg(BigDecimal locOvrdFlg) {
		this.locOvrdFlg = locOvrdFlg;
	}

	public String getLocTyp() {
		return this.locTyp;
	}

	public void setLocTyp(String locTyp) {
		this.locTyp = locTyp;
	}

	public String getLocTypCat() {
		return this.locTypCat;
	}

	public void setLocTypCat(String locTypCat) {
		this.locTypCat = locTypCat;
	}

	public BigDecimal getLpnMixFlg() {
		return this.lpnMixFlg;
	}

	public void setLpnMixFlg(BigDecimal lpnMixFlg) {
		this.lpnMixFlg = lpnMixFlg;
	}

	public BigDecimal getMixShprcvFlg() {
		return this.mixShprcvFlg;
	}

	public void setMixShprcvFlg(BigDecimal mixShprcvFlg) {
		this.mixShprcvFlg = mixShprcvFlg;
	}

	public BigDecimal getPckToStoFlg() {
		return this.pckToStoFlg;
	}

	public void setPckToStoFlg(BigDecimal pckToStoFlg) {
		this.pckToStoFlg = pckToStoFlg;
	}

	public BigDecimal getPdflg() {
		return this.pdflg;
	}

	public void setPdflg(BigDecimal pdflg) {
		this.pdflg = pdflg;
	}

	public BigDecimal getPraflg() {
		return this.praflg;
	}

	public void setPraflg(BigDecimal praflg) {
		this.praflg = praflg;
	}

	public BigDecimal getPrdStgflg() {
		return this.prdStgflg;
	}

	public void setPrdStgflg(BigDecimal prdStgflg) {
		this.prdStgflg = prdStgflg;
	}

	public BigDecimal getProdFlg() {
		return this.prodFlg;
	}

	public void setProdFlg(BigDecimal prodFlg) {
		this.prodFlg = prodFlg;
	}

	public BigDecimal getPutToStoFlg() {
		return this.putToStoFlg;
	}

	public void setPutToStoFlg(BigDecimal putToStoFlg) {
		this.putToStoFlg = putToStoFlg;
	}

	public BigDecimal getRcvDckFlg() {
		return this.rcvDckFlg;
	}

	public void setRcvDckFlg(BigDecimal rcvDckFlg) {
		this.rcvDckFlg = rcvDckFlg;
	}

	public BigDecimal getRcvStgflg() {
		return this.rcvStgflg;
	}

	public void setRcvStgflg(BigDecimal rcvStgflg) {
		this.rcvStgflg = rcvStgflg;
	}

	public BigDecimal getRcvwoNonFwiflg() {
		return this.rcvwoNonFwiflg;
	}

	public void setRcvwoNonFwiflg(BigDecimal rcvwoNonFwiflg) {
		this.rcvwoNonFwiflg = rcvwoNonFwiflg;
	}

	public BigDecimal getRdtflg() {
		return this.rdtflg;
	}

	public void setRdtflg(BigDecimal rdtflg) {
		this.rdtflg = rdtflg;
	}

	public BigDecimal getRemLpnFlg() {
		return this.remLpnFlg;
	}

	public void setRemLpnFlg(BigDecimal remLpnFlg) {
		this.remLpnFlg = remLpnFlg;
	}

	public BigDecimal getShareLocFlg() {
		return this.shareLocFlg;
	}

	public void setShareLocFlg(BigDecimal shareLocFlg) {
		this.shareLocFlg = shareLocFlg;
	}

	public BigDecimal getShpDckFlg() {
		return this.shpDckFlg;
	}

	public void setShpDckFlg(BigDecimal shpDckFlg) {
		this.shpDckFlg = shpDckFlg;
	}

	public BigDecimal getShpflg() {
		return this.shpflg;
	}

	public void setShpflg(BigDecimal shpflg) {
		this.shpflg = shpflg;
	}

	public BigDecimal getSigflg() {
		return this.sigflg;
	}

	public void setSigflg(BigDecimal sigflg) {
		this.sigflg = sigflg;
	}

	public BigDecimal getStgflg() {
		return this.stgflg;
	}

	public void setStgflg(BigDecimal stgflg) {
		this.stgflg = stgflg;
	}

	public BigDecimal getStoTrlrFlg() {
		return this.stoTrlrFlg;
	}

	public void setStoTrlrFlg(BigDecimal stoTrlrFlg) {
		this.stoTrlrFlg = stoTrlrFlg;
	}

	public BigDecimal getStoareFlg() {
		return this.stoareFlg;
	}

	public void setStoareFlg(BigDecimal stoareFlg) {
		this.stoareFlg = stoareFlg;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

	public BigDecimal getWipExpflg() {
		return this.wipExpflg;
	}

	public void setWipExpflg(BigDecimal wipExpflg) {
		this.wipExpflg = wipExpflg;
	}

	public BigDecimal getWipSupflg() {
		return this.wipSupflg;
	}

	public void setWipSupflg(BigDecimal wipSupflg) {
		this.wipSupflg = wipSupflg;
	}

	public BigDecimal getWipflg() {
		return this.wipflg;
	}

	public void setWipflg(BigDecimal wipflg) {
		this.wipflg = wipflg;
	}

	public BigDecimal getXdaflg() {
		return this.xdaflg;
	}

	public void setXdaflg(BigDecimal xdaflg) {
		this.xdaflg = xdaflg;
	}

	public BigDecimal getYrdflg() {
		return this.yrdflg;
	}

	public void setYrdflg(BigDecimal yrdflg) {
		this.yrdflg = yrdflg;
	}

}