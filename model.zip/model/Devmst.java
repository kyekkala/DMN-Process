package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the DEVMST database table.
 * 
 */
@Entity
@NamedQuery(name="Devmst.findAll", query="SELECT d FROM Devmst d")
public class Devmst implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private DevmstPK id;

	@Column(name="CONS_AT_PACK_STATION_FLG")
	private BigDecimal consAtPackStationFlg;

	private String devcls;

	private String devnam;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LBL_PRTADR")
	private String lblPrtadr;

	@Column(name="LOCALE_ID")
	private String localeId;

	@Column(name="LST_USR_ID")
	private String lstUsrId;

	@Column(name="MANIFEST_CARTON_FLG")
	private BigDecimal manifestCartonFlg;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="PKO_MOV_ZONE_ID")
	private BigDecimal pkoMovZoneId;

	private String prtadr;

	@Column(name="RFID_PRTADR")
	private String rfidPrtadr;

	@Column(name="SCALE_COMM_ADDR")
	private String scaleCommAddr;

	@Column(name="SCALE_COMM_CMD")
	private String scaleCommCmd;

	@Column(name="SCALE_COMM_PORT")
	private String scaleCommPort;

	@Column(name="SCANNER_SER_DEV_ID")
	private String scannerSerDevId;

	@Column(name="SPL_HAND_LOC")
	private String splHandLoc;

	@Column(name="TOUCHSCREEN_FLG")
	private BigDecimal touchscreenFlg;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	@Column(name="VOC_TERM_ID")
	private String vocTermId;

	@Column(name="WKO_PRCLOC")
	private String wkoPrcloc;

	public Devmst() {
	}

	public DevmstPK getId() {
		return this.id;
	}

	public void setId(DevmstPK id) {
		this.id = id;
	}

	public BigDecimal getConsAtPackStationFlg() {
		return this.consAtPackStationFlg;
	}

	public void setConsAtPackStationFlg(BigDecimal consAtPackStationFlg) {
		this.consAtPackStationFlg = consAtPackStationFlg;
	}

	public String getDevcls() {
		return this.devcls;
	}

	public void setDevcls(String devcls) {
		this.devcls = devcls;
	}

	public String getDevnam() {
		return this.devnam;
	}

	public void setDevnam(String devnam) {
		this.devnam = devnam;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getLblPrtadr() {
		return this.lblPrtadr;
	}

	public void setLblPrtadr(String lblPrtadr) {
		this.lblPrtadr = lblPrtadr;
	}

	public String getLocaleId() {
		return this.localeId;
	}

	public void setLocaleId(String localeId) {
		this.localeId = localeId;
	}

	public String getLstUsrId() {
		return this.lstUsrId;
	}

	public void setLstUsrId(String lstUsrId) {
		this.lstUsrId = lstUsrId;
	}

	public BigDecimal getManifestCartonFlg() {
		return this.manifestCartonFlg;
	}

	public void setManifestCartonFlg(BigDecimal manifestCartonFlg) {
		this.manifestCartonFlg = manifestCartonFlg;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getPkoMovZoneId() {
		return this.pkoMovZoneId;
	}

	public void setPkoMovZoneId(BigDecimal pkoMovZoneId) {
		this.pkoMovZoneId = pkoMovZoneId;
	}

	public String getPrtadr() {
		return this.prtadr;
	}

	public void setPrtadr(String prtadr) {
		this.prtadr = prtadr;
	}

	public String getRfidPrtadr() {
		return this.rfidPrtadr;
	}

	public void setRfidPrtadr(String rfidPrtadr) {
		this.rfidPrtadr = rfidPrtadr;
	}

	public String getScaleCommAddr() {
		return this.scaleCommAddr;
	}

	public void setScaleCommAddr(String scaleCommAddr) {
		this.scaleCommAddr = scaleCommAddr;
	}

	public String getScaleCommCmd() {
		return this.scaleCommCmd;
	}

	public void setScaleCommCmd(String scaleCommCmd) {
		this.scaleCommCmd = scaleCommCmd;
	}

	public String getScaleCommPort() {
		return this.scaleCommPort;
	}

	public void setScaleCommPort(String scaleCommPort) {
		this.scaleCommPort = scaleCommPort;
	}

	public String getScannerSerDevId() {
		return this.scannerSerDevId;
	}

	public void setScannerSerDevId(String scannerSerDevId) {
		this.scannerSerDevId = scannerSerDevId;
	}

	public String getSplHandLoc() {
		return this.splHandLoc;
	}

	public void setSplHandLoc(String splHandLoc) {
		this.splHandLoc = splHandLoc;
	}

	public BigDecimal getTouchscreenFlg() {
		return this.touchscreenFlg;
	}

	public void setTouchscreenFlg(BigDecimal touchscreenFlg) {
		this.touchscreenFlg = touchscreenFlg;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

	public String getVocTermId() {
		return this.vocTermId;
	}

	public void setVocTermId(String vocTermId) {
		this.vocTermId = vocTermId;
	}

	public String getWkoPrcloc() {
		return this.wkoPrcloc;
	}

	public void setWkoPrcloc(String wkoPrcloc) {
		this.wkoPrcloc = wkoPrcloc;
	}

}