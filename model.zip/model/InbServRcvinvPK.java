package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the INB_SERV_RCVINV database table.
 * 
 */
@Embeddable
public class InbServRcvinvPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="WH_ID")
	private String whId;

	private String trknum;

	private String invnum;

	private String supnum;

	@Column(name="SERV_ID")
	private String servId;

	@Column(name="SERV_RATE_ID")
	private String servRateId;

	@Column(name="CLIENT_ID")
	private String clientId;

	public InbServRcvinvPK() {
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getTrknum() {
		return this.trknum;
	}
	public void setTrknum(String trknum) {
		this.trknum = trknum;
	}
	public String getInvnum() {
		return this.invnum;
	}
	public void setInvnum(String invnum) {
		this.invnum = invnum;
	}
	public String getSupnum() {
		return this.supnum;
	}
	public void setSupnum(String supnum) {
		this.supnum = supnum;
	}
	public String getServId() {
		return this.servId;
	}
	public void setServId(String servId) {
		this.servId = servId;
	}
	public String getServRateId() {
		return this.servRateId;
	}
	public void setServRateId(String servRateId) {
		this.servRateId = servRateId;
	}
	public String getClientId() {
		return this.clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof InbServRcvinvPK)) {
			return false;
		}
		InbServRcvinvPK castOther = (InbServRcvinvPK)other;
		return 
			this.whId.equals(castOther.whId)
			&& this.trknum.equals(castOther.trknum)
			&& this.invnum.equals(castOther.invnum)
			&& this.supnum.equals(castOther.supnum)
			&& this.servId.equals(castOther.servId)
			&& this.servRateId.equals(castOther.servRateId)
			&& this.clientId.equals(castOther.clientId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.trknum.hashCode();
		hash = hash * prime + this.invnum.hashCode();
		hash = hash * prime + this.supnum.hashCode();
		hash = hash * prime + this.servId.hashCode();
		hash = hash * prime + this.servRateId.hashCode();
		hash = hash * prime + this.clientId.hashCode();
		
		return hash;
	}
}