package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the RF_OUB_AUD_MOV_ZONE database table.
 * 
 */
@Entity
@Table(name="RF_OUB_AUD_MOV_ZONE")
@NamedQuery(name="RfOubAudMovZone.findAll", query="SELECT r FROM RfOubAudMovZone r")
public class RfOubAudMovZone implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RfOubAudMovZonePK id;

	public RfOubAudMovZone() {
	}

	public RfOubAudMovZonePK getId() {
		return this.id;
	}

	public void setId(RfOubAudMovZonePK id) {
		this.id = id;
	}

}