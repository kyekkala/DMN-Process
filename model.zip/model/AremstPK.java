package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the AREMST database table.
 * 
 */
@Embeddable
public class AremstPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String arecod;

	@Column(name="WH_ID")
	private String whId;

	public AremstPK() {
	}
	public String getArecod() {
		return this.arecod;
	}
	public void setArecod(String arecod) {
		this.arecod = arecod;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AremstPK)) {
			return false;
		}
		AremstPK castOther = (AremstPK)other;
		return 
			this.arecod.equals(castOther.arecod)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.arecod.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}