package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PACK_CFG database table.
 * 
 */
@Entity
@Table(name="PACK_CFG")
@NamedQuery(name="PackCfg.findAll", query="SELECT p FROM PackCfg p")
public class PackCfg implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PackCfgPK id;

	@Column(name="CAP_SER_ITM_FLG")
	private BigDecimal capSerItmFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="NO_CLOSE_FLG")
	private BigDecimal noCloseFlg;

	@Column(name="PACK_INV_ARRIV_FLG")
	private BigDecimal packInvArrivFlg;

	@Column(name="TOLERANCE_MAX")
	private BigDecimal toleranceMax;

	@Column(name="TOLERANCE_MIN")
	private BigDecimal toleranceMin;

	@Column(name="WGHT_CAPT_AUTO_FLG")
	private BigDecimal wghtCaptAutoFlg;

	@Column(name="WGHT_CAPT_FLG")
	private BigDecimal wghtCaptFlg;

	public PackCfg() {
	}

	public PackCfgPK getId() {
		return this.id;
	}

	public void setId(PackCfgPK id) {
		this.id = id;
	}

	public BigDecimal getCapSerItmFlg() {
		return this.capSerItmFlg;
	}

	public void setCapSerItmFlg(BigDecimal capSerItmFlg) {
		this.capSerItmFlg = capSerItmFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public BigDecimal getNoCloseFlg() {
		return this.noCloseFlg;
	}

	public void setNoCloseFlg(BigDecimal noCloseFlg) {
		this.noCloseFlg = noCloseFlg;
	}

	public BigDecimal getPackInvArrivFlg() {
		return this.packInvArrivFlg;
	}

	public void setPackInvArrivFlg(BigDecimal packInvArrivFlg) {
		this.packInvArrivFlg = packInvArrivFlg;
	}

	public BigDecimal getToleranceMax() {
		return this.toleranceMax;
	}

	public void setToleranceMax(BigDecimal toleranceMax) {
		this.toleranceMax = toleranceMax;
	}

	public BigDecimal getToleranceMin() {
		return this.toleranceMin;
	}

	public void setToleranceMin(BigDecimal toleranceMin) {
		this.toleranceMin = toleranceMin;
	}

	public BigDecimal getWghtCaptAutoFlg() {
		return this.wghtCaptAutoFlg;
	}

	public void setWghtCaptAutoFlg(BigDecimal wghtCaptAutoFlg) {
		this.wghtCaptAutoFlg = wghtCaptAutoFlg;
	}

	public BigDecimal getWghtCaptFlg() {
		return this.wghtCaptFlg;
	}

	public void setWghtCaptFlg(BigDecimal wghtCaptFlg) {
		this.wghtCaptFlg = wghtCaptFlg;
	}

}