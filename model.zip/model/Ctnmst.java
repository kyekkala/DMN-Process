package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CTNMST database table.
 * 
 */
@Entity
@NamedQuery(name="Ctnmst.findAll", query="SELECT c FROM Ctnmst c")
public class Ctnmst implements Serializable {
	private static final long serialVersionUID = 1L;

	public Ctnmst() {
	}

}