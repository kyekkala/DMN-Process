package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CNTZON database table.
 * 
 */
@Entity
@NamedQuery(name="Cntzon.findAll", query="SELECT c FROM Cntzon c")
public class Cntzon implements Serializable {
	private static final long serialVersionUID = 1L;

	public Cntzon() {
	}

}