package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the AUTO_ALC_VAL database table.
 * 
 */
@Entity
@Table(name="AUTO_ALC_VAL")
@NamedQuery(name="AutoAlcVal.findAll", query="SELECT a FROM AutoAlcVal a")
public class AutoAlcVal implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private AutoAlcValPK id;

	@Column(name="FIELD_NAME")
	private String fieldName;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USR_ID")
	private String lastUpdUsrId;

	private String operator;

	@Column(name="TABLE_NAM")
	private String tableNam;

	@Column(name="\"VALUE\"")
	private String value;

	public AutoAlcVal() {
	}

	public AutoAlcValPK getId() {
		return this.id;
	}

	public void setId(AutoAlcValPK id) {
		this.id = id;
	}

	public String getFieldName() {
		return this.fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUsrId() {
		return this.lastUpdUsrId;
	}

	public void setLastUpdUsrId(String lastUpdUsrId) {
		this.lastUpdUsrId = lastUpdUsrId;
	}

	public String getOperator() {
		return this.operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getTableNam() {
		return this.tableNam;
	}

	public void setTableNam(String tableNam) {
		this.tableNam = tableNam;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}