package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the AUTO_ALC_RULE database table.
 * 
 */
@Embeddable
public class AutoAlcRulePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="AUTO_ALC_NUM")
	private String autoAlcNum;

	@Column(name="WH_ID")
	private String whId;

	public AutoAlcRulePK() {
	}
	public String getAutoAlcNum() {
		return this.autoAlcNum;
	}
	public void setAutoAlcNum(String autoAlcNum) {
		this.autoAlcNum = autoAlcNum;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AutoAlcRulePK)) {
			return false;
		}
		AutoAlcRulePK castOther = (AutoAlcRulePK)other;
		return 
			this.autoAlcNum.equals(castOther.autoAlcNum)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.autoAlcNum.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}