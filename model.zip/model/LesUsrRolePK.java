package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the LES_USR_ROLE database table.
 * 
 */
@Embeddable
public class LesUsrRolePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="USR_ID")
	private String usrId;

	@Column(name="ROLE_ID")
	private String roleId;

	public LesUsrRolePK() {
	}
	public String getUsrId() {
		return this.usrId;
	}
	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}
	public String getRoleId() {
		return this.roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof LesUsrRolePK)) {
			return false;
		}
		LesUsrRolePK castOther = (LesUsrRolePK)other;
		return 
			this.usrId.equals(castOther.usrId)
			&& this.roleId.equals(castOther.roleId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.usrId.hashCode();
		hash = hash * prime + this.roleId.hashCode();
		
		return hash;
	}
}