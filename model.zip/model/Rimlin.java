package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the RIMLIN database table.
 * 
 */
@Entity
@NamedQuery(name="Rimlin.findAll", query="SELECT r FROM Rimlin r")
public class Rimlin implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RimlinPK id;

	@Column(name="CSTMS_CMMDTY_COD")
	private String cstmsCmmdtyCod;

	@Column(name="CSTMS_CRNCY")
	private String cstmsCrncy;

	@Column(name="CSTMS_CST")
	private BigDecimal cstmsCst;

	@Column(name="CSTMS_TYP")
	private String cstmsTyp;

	@Column(name="CSTMS_VAT_COD")
	private String cstmsVatCod;

	@Column(name="DFLT_ORGCOD")
	private String dfltOrgcod;

	@Column(name="DISTRO_OVRFLG")
	private BigDecimal distroOvrflg;

	@Column(name="DTY_STMP_TRK_FLG")
	private BigDecimal dtyStmpTrkFlg;

	private BigDecimal edtflg;

	@Column(name="EXP_CATCH_QTY")
	private BigDecimal expCatchQty;

	@Temporal(TemporalType.DATE)
	@Column(name="EXPIRE_DTE")
	private Date expireDte;

	private BigDecimal expqty;

	private String frhsta;

	private String hsttrn;

	@Column(name="IDN_CATCH_QTY")
	private BigDecimal idnCatchQty;

	private BigDecimal idnqty;

	@Temporal(TemporalType.DATE)
	@Column(name="INV_ATTR_DTE1")
	private Date invAttrDte1;

	@Temporal(TemporalType.DATE)
	@Column(name="INV_ATTR_DTE2")
	private Date invAttrDte2;

	@Column(name="INV_ATTR_FLT1")
	private BigDecimal invAttrFlt1;

	@Column(name="INV_ATTR_FLT2")
	private BigDecimal invAttrFlt2;

	@Column(name="INV_ATTR_FLT3")
	private BigDecimal invAttrFlt3;

	@Column(name="INV_ATTR_INT1")
	private BigDecimal invAttrInt1;

	@Column(name="INV_ATTR_INT2")
	private BigDecimal invAttrInt2;

	@Column(name="INV_ATTR_INT3")
	private BigDecimal invAttrInt3;

	@Column(name="INV_ATTR_INT4")
	private BigDecimal invAttrInt4;

	@Column(name="INV_ATTR_INT5")
	private BigDecimal invAttrInt5;

	@Column(name="INV_ATTR_STR1")
	private String invAttrStr1;

	@Column(name="INV_ATTR_STR10")
	private String invAttrStr10;

	@Column(name="INV_ATTR_STR11")
	private String invAttrStr11;

	@Column(name="INV_ATTR_STR12")
	private String invAttrStr12;

	@Column(name="INV_ATTR_STR13")
	private String invAttrStr13;

	@Column(name="INV_ATTR_STR14")
	private String invAttrStr14;

	@Column(name="INV_ATTR_STR15")
	private String invAttrStr15;

	@Column(name="INV_ATTR_STR16")
	private String invAttrStr16;

	@Column(name="INV_ATTR_STR17")
	private String invAttrStr17;

	@Column(name="INV_ATTR_STR18")
	private String invAttrStr18;

	@Column(name="INV_ATTR_STR2")
	private String invAttrStr2;

	@Column(name="INV_ATTR_STR3")
	private String invAttrStr3;

	@Column(name="INV_ATTR_STR4")
	private String invAttrStr4;

	@Column(name="INV_ATTR_STR5")
	private String invAttrStr5;

	@Column(name="INV_ATTR_STR6")
	private String invAttrStr6;

	@Column(name="INV_ATTR_STR7")
	private String invAttrStr7;

	@Column(name="INV_ATTR_STR8")
	private String invAttrStr8;

	@Column(name="INV_ATTR_STR9")
	private String invAttrStr9;

	private String lotnum;

	@Temporal(TemporalType.DATE)
	private Date mandte;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private String orgcod;

	@Column(name="PRT_CLIENT_ID")
	private String prtClientId;

	private String prtnum;

	private String rcvsts;

	private String retcod;

	private String revlvl;

	@Column(name="SUP_LOTNUM")
	private String supLotnum;

	private String tohsta;

	public Rimlin() {
	}

	public RimlinPK getId() {
		return this.id;
	}

	public void setId(RimlinPK id) {
		this.id = id;
	}

	public String getCstmsCmmdtyCod() {
		return this.cstmsCmmdtyCod;
	}

	public void setCstmsCmmdtyCod(String cstmsCmmdtyCod) {
		this.cstmsCmmdtyCod = cstmsCmmdtyCod;
	}

	public String getCstmsCrncy() {
		return this.cstmsCrncy;
	}

	public void setCstmsCrncy(String cstmsCrncy) {
		this.cstmsCrncy = cstmsCrncy;
	}

	public BigDecimal getCstmsCst() {
		return this.cstmsCst;
	}

	public void setCstmsCst(BigDecimal cstmsCst) {
		this.cstmsCst = cstmsCst;
	}

	public String getCstmsTyp() {
		return this.cstmsTyp;
	}

	public void setCstmsTyp(String cstmsTyp) {
		this.cstmsTyp = cstmsTyp;
	}

	public String getCstmsVatCod() {
		return this.cstmsVatCod;
	}

	public void setCstmsVatCod(String cstmsVatCod) {
		this.cstmsVatCod = cstmsVatCod;
	}

	public String getDfltOrgcod() {
		return this.dfltOrgcod;
	}

	public void setDfltOrgcod(String dfltOrgcod) {
		this.dfltOrgcod = dfltOrgcod;
	}

	public BigDecimal getDistroOvrflg() {
		return this.distroOvrflg;
	}

	public void setDistroOvrflg(BigDecimal distroOvrflg) {
		this.distroOvrflg = distroOvrflg;
	}

	public BigDecimal getDtyStmpTrkFlg() {
		return this.dtyStmpTrkFlg;
	}

	public void setDtyStmpTrkFlg(BigDecimal dtyStmpTrkFlg) {
		this.dtyStmpTrkFlg = dtyStmpTrkFlg;
	}

	public BigDecimal getEdtflg() {
		return this.edtflg;
	}

	public void setEdtflg(BigDecimal edtflg) {
		this.edtflg = edtflg;
	}

	public BigDecimal getExpCatchQty() {
		return this.expCatchQty;
	}

	public void setExpCatchQty(BigDecimal expCatchQty) {
		this.expCatchQty = expCatchQty;
	}

	public Date getExpireDte() {
		return this.expireDte;
	}

	public void setExpireDte(Date expireDte) {
		this.expireDte = expireDte;
	}

	public BigDecimal getExpqty() {
		return this.expqty;
	}

	public void setExpqty(BigDecimal expqty) {
		this.expqty = expqty;
	}

	public String getFrhsta() {
		return this.frhsta;
	}

	public void setFrhsta(String frhsta) {
		this.frhsta = frhsta;
	}

	public String getHsttrn() {
		return this.hsttrn;
	}

	public void setHsttrn(String hsttrn) {
		this.hsttrn = hsttrn;
	}

	public BigDecimal getIdnCatchQty() {
		return this.idnCatchQty;
	}

	public void setIdnCatchQty(BigDecimal idnCatchQty) {
		this.idnCatchQty = idnCatchQty;
	}

	public BigDecimal getIdnqty() {
		return this.idnqty;
	}

	public void setIdnqty(BigDecimal idnqty) {
		this.idnqty = idnqty;
	}

	public Date getInvAttrDte1() {
		return this.invAttrDte1;
	}

	public void setInvAttrDte1(Date invAttrDte1) {
		this.invAttrDte1 = invAttrDte1;
	}

	public Date getInvAttrDte2() {
		return this.invAttrDte2;
	}

	public void setInvAttrDte2(Date invAttrDte2) {
		this.invAttrDte2 = invAttrDte2;
	}

	public BigDecimal getInvAttrFlt1() {
		return this.invAttrFlt1;
	}

	public void setInvAttrFlt1(BigDecimal invAttrFlt1) {
		this.invAttrFlt1 = invAttrFlt1;
	}

	public BigDecimal getInvAttrFlt2() {
		return this.invAttrFlt2;
	}

	public void setInvAttrFlt2(BigDecimal invAttrFlt2) {
		this.invAttrFlt2 = invAttrFlt2;
	}

	public BigDecimal getInvAttrFlt3() {
		return this.invAttrFlt3;
	}

	public void setInvAttrFlt3(BigDecimal invAttrFlt3) {
		this.invAttrFlt3 = invAttrFlt3;
	}

	public BigDecimal getInvAttrInt1() {
		return this.invAttrInt1;
	}

	public void setInvAttrInt1(BigDecimal invAttrInt1) {
		this.invAttrInt1 = invAttrInt1;
	}

	public BigDecimal getInvAttrInt2() {
		return this.invAttrInt2;
	}

	public void setInvAttrInt2(BigDecimal invAttrInt2) {
		this.invAttrInt2 = invAttrInt2;
	}

	public BigDecimal getInvAttrInt3() {
		return this.invAttrInt3;
	}

	public void setInvAttrInt3(BigDecimal invAttrInt3) {
		this.invAttrInt3 = invAttrInt3;
	}

	public BigDecimal getInvAttrInt4() {
		return this.invAttrInt4;
	}

	public void setInvAttrInt4(BigDecimal invAttrInt4) {
		this.invAttrInt4 = invAttrInt4;
	}

	public BigDecimal getInvAttrInt5() {
		return this.invAttrInt5;
	}

	public void setInvAttrInt5(BigDecimal invAttrInt5) {
		this.invAttrInt5 = invAttrInt5;
	}

	public String getInvAttrStr1() {
		return this.invAttrStr1;
	}

	public void setInvAttrStr1(String invAttrStr1) {
		this.invAttrStr1 = invAttrStr1;
	}

	public String getInvAttrStr10() {
		return this.invAttrStr10;
	}

	public void setInvAttrStr10(String invAttrStr10) {
		this.invAttrStr10 = invAttrStr10;
	}

	public String getInvAttrStr11() {
		return this.invAttrStr11;
	}

	public void setInvAttrStr11(String invAttrStr11) {
		this.invAttrStr11 = invAttrStr11;
	}

	public String getInvAttrStr12() {
		return this.invAttrStr12;
	}

	public void setInvAttrStr12(String invAttrStr12) {
		this.invAttrStr12 = invAttrStr12;
	}

	public String getInvAttrStr13() {
		return this.invAttrStr13;
	}

	public void setInvAttrStr13(String invAttrStr13) {
		this.invAttrStr13 = invAttrStr13;
	}

	public String getInvAttrStr14() {
		return this.invAttrStr14;
	}

	public void setInvAttrStr14(String invAttrStr14) {
		this.invAttrStr14 = invAttrStr14;
	}

	public String getInvAttrStr15() {
		return this.invAttrStr15;
	}

	public void setInvAttrStr15(String invAttrStr15) {
		this.invAttrStr15 = invAttrStr15;
	}

	public String getInvAttrStr16() {
		return this.invAttrStr16;
	}

	public void setInvAttrStr16(String invAttrStr16) {
		this.invAttrStr16 = invAttrStr16;
	}

	public String getInvAttrStr17() {
		return this.invAttrStr17;
	}

	public void setInvAttrStr17(String invAttrStr17) {
		this.invAttrStr17 = invAttrStr17;
	}

	public String getInvAttrStr18() {
		return this.invAttrStr18;
	}

	public void setInvAttrStr18(String invAttrStr18) {
		this.invAttrStr18 = invAttrStr18;
	}

	public String getInvAttrStr2() {
		return this.invAttrStr2;
	}

	public void setInvAttrStr2(String invAttrStr2) {
		this.invAttrStr2 = invAttrStr2;
	}

	public String getInvAttrStr3() {
		return this.invAttrStr3;
	}

	public void setInvAttrStr3(String invAttrStr3) {
		this.invAttrStr3 = invAttrStr3;
	}

	public String getInvAttrStr4() {
		return this.invAttrStr4;
	}

	public void setInvAttrStr4(String invAttrStr4) {
		this.invAttrStr4 = invAttrStr4;
	}

	public String getInvAttrStr5() {
		return this.invAttrStr5;
	}

	public void setInvAttrStr5(String invAttrStr5) {
		this.invAttrStr5 = invAttrStr5;
	}

	public String getInvAttrStr6() {
		return this.invAttrStr6;
	}

	public void setInvAttrStr6(String invAttrStr6) {
		this.invAttrStr6 = invAttrStr6;
	}

	public String getInvAttrStr7() {
		return this.invAttrStr7;
	}

	public void setInvAttrStr7(String invAttrStr7) {
		this.invAttrStr7 = invAttrStr7;
	}

	public String getInvAttrStr8() {
		return this.invAttrStr8;
	}

	public void setInvAttrStr8(String invAttrStr8) {
		this.invAttrStr8 = invAttrStr8;
	}

	public String getInvAttrStr9() {
		return this.invAttrStr9;
	}

	public void setInvAttrStr9(String invAttrStr9) {
		this.invAttrStr9 = invAttrStr9;
	}

	public String getLotnum() {
		return this.lotnum;
	}

	public void setLotnum(String lotnum) {
		this.lotnum = lotnum;
	}

	public Date getMandte() {
		return this.mandte;
	}

	public void setMandte(Date mandte) {
		this.mandte = mandte;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getOrgcod() {
		return this.orgcod;
	}

	public void setOrgcod(String orgcod) {
		this.orgcod = orgcod;
	}

	public String getPrtClientId() {
		return this.prtClientId;
	}

	public void setPrtClientId(String prtClientId) {
		this.prtClientId = prtClientId;
	}

	public String getPrtnum() {
		return this.prtnum;
	}

	public void setPrtnum(String prtnum) {
		this.prtnum = prtnum;
	}

	public String getRcvsts() {
		return this.rcvsts;
	}

	public void setRcvsts(String rcvsts) {
		this.rcvsts = rcvsts;
	}

	public String getRetcod() {
		return this.retcod;
	}

	public void setRetcod(String retcod) {
		this.retcod = retcod;
	}

	public String getRevlvl() {
		return this.revlvl;
	}

	public void setRevlvl(String revlvl) {
		this.revlvl = revlvl;
	}

	public String getSupLotnum() {
		return this.supLotnum;
	}

	public void setSupLotnum(String supLotnum) {
		this.supLotnum = supLotnum;
	}

	public String getTohsta() {
		return this.tohsta;
	}

	public void setTohsta(String tohsta) {
		this.tohsta = tohsta;
	}

}