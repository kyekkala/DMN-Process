package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the BLDG_MST database table.
 * 
 */
@Entity
@Table(name="BLDG_MST")
@NamedQuery(name="BldgMst.findAll", query="SELECT b FROM BldgMst b")
public class BldgMst implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private BldgMstPK id;

	@Column(name="ADR_ID")
	private String adrId;

	@Column(name="BUSINESS_UNT")
	private String businessUnt;

	@Column(name="FLUID_LOAD_FLG")
	private BigDecimal fluidLoadFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="SORT_ATTR_LOCSTS")
	private String sortAttrLocsts;

	@Column(name="SORT_DEFAULT_FLG")
	private BigDecimal sortDefaultFlg;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	public BldgMst() {
	}

	public BldgMstPK getId() {
		return this.id;
	}

	public void setId(BldgMstPK id) {
		this.id = id;
	}

	public String getAdrId() {
		return this.adrId;
	}

	public void setAdrId(String adrId) {
		this.adrId = adrId;
	}

	public String getBusinessUnt() {
		return this.businessUnt;
	}

	public void setBusinessUnt(String businessUnt) {
		this.businessUnt = businessUnt;
	}

	public BigDecimal getFluidLoadFlg() {
		return this.fluidLoadFlg;
	}

	public void setFluidLoadFlg(BigDecimal fluidLoadFlg) {
		this.fluidLoadFlg = fluidLoadFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getSortAttrLocsts() {
		return this.sortAttrLocsts;
	}

	public void setSortAttrLocsts(String sortAttrLocsts) {
		this.sortAttrLocsts = sortAttrLocsts;
	}

	public BigDecimal getSortDefaultFlg() {
		return this.sortDefaultFlg;
	}

	public void setSortDefaultFlg(BigDecimal sortDefaultFlg) {
		this.sortDefaultFlg = sortDefaultFlg;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

}