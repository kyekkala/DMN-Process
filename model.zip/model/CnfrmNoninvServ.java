package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CNFRM_NONINV_SERV database table.
 * 
 */
@Entity
@Table(name="CNFRM_NONINV_SERV")
@NamedQuery(name="CnfrmNoninvServ.findAll", query="SELECT c FROM CnfrmNoninvServ c")
public class CnfrmNoninvServ implements Serializable {
	private static final long serialVersionUID = 1L;

	public CnfrmNoninvServ() {
	}

}