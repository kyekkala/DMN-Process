package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PRTMST_SUP_WH database table.
 * 
 */
@Entity
@Table(name="PRTMST_SUP_WH")
@NamedQuery(name="PrtmstSupWh.findAll", query="SELECT p FROM PrtmstSupWh p")
public class PrtmstSupWh implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PrtmstSupWhPK id;

	@Temporal(TemporalType.DATE)
	private Date cntdte;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Temporal(TemporalType.DATE)
	private Date lstrcv;

	private BigDecimal lstvar;

	private BigDecimal numcnt;

	public PrtmstSupWh() {
	}

	public PrtmstSupWhPK getId() {
		return this.id;
	}

	public void setId(PrtmstSupWhPK id) {
		this.id = id;
	}

	public Date getCntdte() {
		return this.cntdte;
	}

	public void setCntdte(Date cntdte) {
		this.cntdte = cntdte;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public Date getLstrcv() {
		return this.lstrcv;
	}

	public void setLstrcv(Date lstrcv) {
		this.lstrcv = lstrcv;
	}

	public BigDecimal getLstvar() {
		return this.lstvar;
	}

	public void setLstvar(BigDecimal lstvar) {
		this.lstvar = lstvar;
	}

	public BigDecimal getNumcnt() {
		return this.numcnt;
	}

	public void setNumcnt(BigDecimal numcnt) {
		this.numcnt = numcnt;
	}

}