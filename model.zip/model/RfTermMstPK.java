package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RF_TERM_MST database table.
 * 
 */
@Embeddable
public class RfTermMstPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="RF_VEN_NAM")
	private String rfVenNam;

	@Column(name="WH_ID")
	private String whId;

	@Column(name="TERM_ID")
	private String termId;

	public RfTermMstPK() {
	}
	public String getRfVenNam() {
		return this.rfVenNam;
	}
	public void setRfVenNam(String rfVenNam) {
		this.rfVenNam = rfVenNam;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getTermId() {
		return this.termId;
	}
	public void setTermId(String termId) {
		this.termId = termId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RfTermMstPK)) {
			return false;
		}
		RfTermMstPK castOther = (RfTermMstPK)other;
		return 
			this.rfVenNam.equals(castOther.rfVenNam)
			&& this.whId.equals(castOther.whId)
			&& this.termId.equals(castOther.termId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.rfVenNam.hashCode();
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.termId.hashCode();
		
		return hash;
	}
}