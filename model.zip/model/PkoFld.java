package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PKO_FLDS database table.
 * 
 */
@Entity
@Table(name="PKO_FLDS")
@NamedQuery(name="PkoFld.findAll", query="SELECT p FROM PkoFld p")
public class PkoFld implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PkoFldPK id;

	@Column(name="AUTO_FILL_FLG")
	private BigDecimal autoFillFlg;

	@Column(name="BC_FLD_FLG")
	private BigDecimal bcFldFlg;

	@Column(name="ID_FLD_FLG")
	private BigDecimal idFldFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	private BigDecimal srtseq;

	@Column(name="VIS_FLG")
	private BigDecimal visFlg;

	public PkoFld() {
	}

	public PkoFldPK getId() {
		return this.id;
	}

	public void setId(PkoFldPK id) {
		this.id = id;
	}

	public BigDecimal getAutoFillFlg() {
		return this.autoFillFlg;
	}

	public void setAutoFillFlg(BigDecimal autoFillFlg) {
		this.autoFillFlg = autoFillFlg;
	}

	public BigDecimal getBcFldFlg() {
		return this.bcFldFlg;
	}

	public void setBcFldFlg(BigDecimal bcFldFlg) {
		this.bcFldFlg = bcFldFlg;
	}

	public BigDecimal getIdFldFlg() {
		return this.idFldFlg;
	}

	public void setIdFldFlg(BigDecimal idFldFlg) {
		this.idFldFlg = idFldFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getSrtseq() {
		return this.srtseq;
	}

	public void setSrtseq(BigDecimal srtseq) {
		this.srtseq = srtseq;
	}

	public BigDecimal getVisFlg() {
		return this.visFlg;
	}

	public void setVisFlg(BigDecimal visFlg) {
		this.visFlg = visFlg;
	}

}