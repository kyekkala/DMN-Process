package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the USROPR database table.
 * 
 */
@Entity
@NamedQuery(name="Usropr.findAll", query="SELECT u FROM Usropr u")
public class Usropr implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private UsroprPK id;

	public Usropr() {
	}

	public UsroprPK getId() {
		return this.id;
	}

	public void setId(UsroprPK id) {
		this.id = id;
	}

}