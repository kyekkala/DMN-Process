package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PCKLST_RULE_GRP database table.
 * 
 */
@Entity
@Table(name="PCKLST_RULE_GRP")
@NamedQuery(name="PcklstRuleGrp.findAll", query="SELECT p FROM PcklstRuleGrp p")
public class PcklstRuleGrp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PCKLST_RULE_GRP_ID")
	private long pcklstRuleGrpId;

	@Column(name="CLIENT_ID")
	private String clientId;

	@Column(name="ENA_FLG")
	private BigDecimal enaFlg;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="PCKLST_RULE_GRP_NAME")
	private String pcklstRuleGrpName;

	@Column(name="WH_ID")
	private String whId;

	public PcklstRuleGrp() {
	}

	public long getPcklstRuleGrpId() {
		return this.pcklstRuleGrpId;
	}

	public void setPcklstRuleGrpId(long pcklstRuleGrpId) {
		this.pcklstRuleGrpId = pcklstRuleGrpId;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public BigDecimal getEnaFlg() {
		return this.enaFlg;
	}

	public void setEnaFlg(BigDecimal enaFlg) {
		this.enaFlg = enaFlg;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getPcklstRuleGrpName() {
		return this.pcklstRuleGrpName;
	}

	public void setPcklstRuleGrpName(String pcklstRuleGrpName) {
		this.pcklstRuleGrpName = pcklstRuleGrpName;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

}