package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the RPLWRK database table.
 * 
 */
@Entity
@NamedQuery(name="Rplwrk.findAll", query="SELECT r FROM Rplwrk r")
public class Rplwrk implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String rplref;

	@Temporal(TemporalType.DATE)
	private Date adddte;

	@Column(name="ALC_CATCH_QTY")
	private BigDecimal alcCatchQty;

	@Temporal(TemporalType.DATE)
	private Date alcdte;

	private BigDecimal alcqty;

	@Column(name="CLIENT_ID")
	private String clientId;

	private String cmbcod;

	private String concod;

	@Column(name="DST_MOV_ZONE_ID")
	private BigDecimal dstMovZoneId;

	private String dstloc;

	private BigDecimal frsflg;

	private String ftpcod;

	private String invsts;

	@Column(name="INVSTS_PRG")
	private String invstsPrg;

	@Column(name="LIST_ID")
	private String listId;

	@Column(name="LIST_SEQNUM")
	private BigDecimal listSeqnum;

	private String lodlvl;

	@Column(name="MIN_SHELF_HRS")
	private BigDecimal minShelfHrs;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	private String ordlin;

	private String ordnum;

	private String ordsln;

	@Column(name="PALLET_ID")
	private String palletId;

	@Column(name="PALLET_LOAD_SEQ")
	private BigDecimal palletLoadSeq;

	@Column(name="PALLET_POS")
	private String palletPos;

	private String parref;

	@Column(name="PCK_CATCH_QTY")
	private BigDecimal pckCatchQty;

	@Temporal(TemporalType.DATE)
	private Date pckdte;

	private BigDecimal pckqty;

	private String pcksts;

	@Column(name="PLTCTL_LODLVL")
	private String pltctlLodlvl;

	@Column(name="PLTCTL_REPLN_FLG")
	private BigDecimal pltctlReplnFlg;

	@Column(name="PRT_CLIENT_ID")
	private String prtClientId;

	private String prtnum;

	private BigDecimal rplcnt;

	private String rplmsg;

	private String rplsts;

	private String rtcust;

	@Column(name="RULE_NAM")
	private String ruleNam;

	private String schbat;

	private BigDecimal seqnum;

	@Column(name="SHIP_ID")
	private String shipId;

	@Column(name="SHIP_LINE_ID")
	private String shipLineId;

	private BigDecimal splflg;

	private String stcust;

	private String supnum;

	private BigDecimal untcas;

	private BigDecimal untpak;

	private String waybil;

	@Column(name="WH_ID")
	private String whId;

	private String wkolin;

	private String wkonum;

	private String wkorev;

	public Rplwrk() {
	}

	public String getRplref() {
		return this.rplref;
	}

	public void setRplref(String rplref) {
		this.rplref = rplref;
	}

	public Date getAdddte() {
		return this.adddte;
	}

	public void setAdddte(Date adddte) {
		this.adddte = adddte;
	}

	public BigDecimal getAlcCatchQty() {
		return this.alcCatchQty;
	}

	public void setAlcCatchQty(BigDecimal alcCatchQty) {
		this.alcCatchQty = alcCatchQty;
	}

	public Date getAlcdte() {
		return this.alcdte;
	}

	public void setAlcdte(Date alcdte) {
		this.alcdte = alcdte;
	}

	public BigDecimal getAlcqty() {
		return this.alcqty;
	}

	public void setAlcqty(BigDecimal alcqty) {
		this.alcqty = alcqty;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getCmbcod() {
		return this.cmbcod;
	}

	public void setCmbcod(String cmbcod) {
		this.cmbcod = cmbcod;
	}

	public String getConcod() {
		return this.concod;
	}

	public void setConcod(String concod) {
		this.concod = concod;
	}

	public BigDecimal getDstMovZoneId() {
		return this.dstMovZoneId;
	}

	public void setDstMovZoneId(BigDecimal dstMovZoneId) {
		this.dstMovZoneId = dstMovZoneId;
	}

	public String getDstloc() {
		return this.dstloc;
	}

	public void setDstloc(String dstloc) {
		this.dstloc = dstloc;
	}

	public BigDecimal getFrsflg() {
		return this.frsflg;
	}

	public void setFrsflg(BigDecimal frsflg) {
		this.frsflg = frsflg;
	}

	public String getFtpcod() {
		return this.ftpcod;
	}

	public void setFtpcod(String ftpcod) {
		this.ftpcod = ftpcod;
	}

	public String getInvsts() {
		return this.invsts;
	}

	public void setInvsts(String invsts) {
		this.invsts = invsts;
	}

	public String getInvstsPrg() {
		return this.invstsPrg;
	}

	public void setInvstsPrg(String invstsPrg) {
		this.invstsPrg = invstsPrg;
	}

	public String getListId() {
		return this.listId;
	}

	public void setListId(String listId) {
		this.listId = listId;
	}

	public BigDecimal getListSeqnum() {
		return this.listSeqnum;
	}

	public void setListSeqnum(BigDecimal listSeqnum) {
		this.listSeqnum = listSeqnum;
	}

	public String getLodlvl() {
		return this.lodlvl;
	}

	public void setLodlvl(String lodlvl) {
		this.lodlvl = lodlvl;
	}

	public BigDecimal getMinShelfHrs() {
		return this.minShelfHrs;
	}

	public void setMinShelfHrs(BigDecimal minShelfHrs) {
		this.minShelfHrs = minShelfHrs;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public String getOrdlin() {
		return this.ordlin;
	}

	public void setOrdlin(String ordlin) {
		this.ordlin = ordlin;
	}

	public String getOrdnum() {
		return this.ordnum;
	}

	public void setOrdnum(String ordnum) {
		this.ordnum = ordnum;
	}

	public String getOrdsln() {
		return this.ordsln;
	}

	public void setOrdsln(String ordsln) {
		this.ordsln = ordsln;
	}

	public String getPalletId() {
		return this.palletId;
	}

	public void setPalletId(String palletId) {
		this.palletId = palletId;
	}

	public BigDecimal getPalletLoadSeq() {
		return this.palletLoadSeq;
	}

	public void setPalletLoadSeq(BigDecimal palletLoadSeq) {
		this.palletLoadSeq = palletLoadSeq;
	}

	public String getPalletPos() {
		return this.palletPos;
	}

	public void setPalletPos(String palletPos) {
		this.palletPos = palletPos;
	}

	public String getParref() {
		return this.parref;
	}

	public void setParref(String parref) {
		this.parref = parref;
	}

	public BigDecimal getPckCatchQty() {
		return this.pckCatchQty;
	}

	public void setPckCatchQty(BigDecimal pckCatchQty) {
		this.pckCatchQty = pckCatchQty;
	}

	public Date getPckdte() {
		return this.pckdte;
	}

	public void setPckdte(Date pckdte) {
		this.pckdte = pckdte;
	}

	public BigDecimal getPckqty() {
		return this.pckqty;
	}

	public void setPckqty(BigDecimal pckqty) {
		this.pckqty = pckqty;
	}

	public String getPcksts() {
		return this.pcksts;
	}

	public void setPcksts(String pcksts) {
		this.pcksts = pcksts;
	}

	public String getPltctlLodlvl() {
		return this.pltctlLodlvl;
	}

	public void setPltctlLodlvl(String pltctlLodlvl) {
		this.pltctlLodlvl = pltctlLodlvl;
	}

	public BigDecimal getPltctlReplnFlg() {
		return this.pltctlReplnFlg;
	}

	public void setPltctlReplnFlg(BigDecimal pltctlReplnFlg) {
		this.pltctlReplnFlg = pltctlReplnFlg;
	}

	public String getPrtClientId() {
		return this.prtClientId;
	}

	public void setPrtClientId(String prtClientId) {
		this.prtClientId = prtClientId;
	}

	public String getPrtnum() {
		return this.prtnum;
	}

	public void setPrtnum(String prtnum) {
		this.prtnum = prtnum;
	}

	public BigDecimal getRplcnt() {
		return this.rplcnt;
	}

	public void setRplcnt(BigDecimal rplcnt) {
		this.rplcnt = rplcnt;
	}

	public String getRplmsg() {
		return this.rplmsg;
	}

	public void setRplmsg(String rplmsg) {
		this.rplmsg = rplmsg;
	}

	public String getRplsts() {
		return this.rplsts;
	}

	public void setRplsts(String rplsts) {
		this.rplsts = rplsts;
	}

	public String getRtcust() {
		return this.rtcust;
	}

	public void setRtcust(String rtcust) {
		this.rtcust = rtcust;
	}

	public String getRuleNam() {
		return this.ruleNam;
	}

	public void setRuleNam(String ruleNam) {
		this.ruleNam = ruleNam;
	}

	public String getSchbat() {
		return this.schbat;
	}

	public void setSchbat(String schbat) {
		this.schbat = schbat;
	}

	public BigDecimal getSeqnum() {
		return this.seqnum;
	}

	public void setSeqnum(BigDecimal seqnum) {
		this.seqnum = seqnum;
	}

	public String getShipId() {
		return this.shipId;
	}

	public void setShipId(String shipId) {
		this.shipId = shipId;
	}

	public String getShipLineId() {
		return this.shipLineId;
	}

	public void setShipLineId(String shipLineId) {
		this.shipLineId = shipLineId;
	}

	public BigDecimal getSplflg() {
		return this.splflg;
	}

	public void setSplflg(BigDecimal splflg) {
		this.splflg = splflg;
	}

	public String getStcust() {
		return this.stcust;
	}

	public void setStcust(String stcust) {
		this.stcust = stcust;
	}

	public String getSupnum() {
		return this.supnum;
	}

	public void setSupnum(String supnum) {
		this.supnum = supnum;
	}

	public BigDecimal getUntcas() {
		return this.untcas;
	}

	public void setUntcas(BigDecimal untcas) {
		this.untcas = untcas;
	}

	public BigDecimal getUntpak() {
		return this.untpak;
	}

	public void setUntpak(BigDecimal untpak) {
		this.untpak = untpak;
	}

	public String getWaybil() {
		return this.waybil;
	}

	public void setWaybil(String waybil) {
		this.waybil = waybil;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

	public String getWkolin() {
		return this.wkolin;
	}

	public void setWkolin(String wkolin) {
		this.wkolin = wkolin;
	}

	public String getWkonum() {
		return this.wkonum;
	}

	public void setWkonum(String wkonum) {
		this.wkonum = wkonum;
	}

	public String getWkorev() {
		return this.wkorev;
	}

	public void setWkorev(String wkorev) {
		this.wkorev = wkorev;
	}

}