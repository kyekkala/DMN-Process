package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the ABC_ESTIMATE database table.
 * 
 */
@Embeddable
public class AbcEstimatePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Temporal(TemporalType.DATE)
	private java.util.Date cntdte;

	@Column(name="WH_ID")
	private String whId;

	public AbcEstimatePK() {
	}
	public java.util.Date getCntdte() {
		return this.cntdte;
	}
	public void setCntdte(java.util.Date cntdte) {
		this.cntdte = cntdte;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AbcEstimatePK)) {
			return false;
		}
		AbcEstimatePK castOther = (AbcEstimatePK)other;
		return 
			this.cntdte.equals(castOther.cntdte)
			&& this.whId.equals(castOther.whId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.cntdte.hashCode();
		hash = hash * prime + this.whId.hashCode();
		
		return hash;
	}
}