package model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RCVLIN database table.
 * 
 */
@Embeddable
public class RcvlinPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private String trknum;

	private String supnum;

	private String invnum;

	private String invlin;

	private String invsln;

	private long seqnum;

	@Column(name="WH_ID")
	private String whId;

	@Column(name="CLIENT_ID")
	private String clientId;

	public RcvlinPK() {
	}
	public String getTrknum() {
		return this.trknum;
	}
	public void setTrknum(String trknum) {
		this.trknum = trknum;
	}
	public String getSupnum() {
		return this.supnum;
	}
	public void setSupnum(String supnum) {
		this.supnum = supnum;
	}
	public String getInvnum() {
		return this.invnum;
	}
	public void setInvnum(String invnum) {
		this.invnum = invnum;
	}
	public String getInvlin() {
		return this.invlin;
	}
	public void setInvlin(String invlin) {
		this.invlin = invlin;
	}
	public String getInvsln() {
		return this.invsln;
	}
	public void setInvsln(String invsln) {
		this.invsln = invsln;
	}
	public long getSeqnum() {
		return this.seqnum;
	}
	public void setSeqnum(long seqnum) {
		this.seqnum = seqnum;
	}
	public String getWhId() {
		return this.whId;
	}
	public void setWhId(String whId) {
		this.whId = whId;
	}
	public String getClientId() {
		return this.clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RcvlinPK)) {
			return false;
		}
		RcvlinPK castOther = (RcvlinPK)other;
		return 
			this.trknum.equals(castOther.trknum)
			&& this.supnum.equals(castOther.supnum)
			&& this.invnum.equals(castOther.invnum)
			&& this.invlin.equals(castOther.invlin)
			&& this.invsln.equals(castOther.invsln)
			&& (this.seqnum == castOther.seqnum)
			&& this.whId.equals(castOther.whId)
			&& this.clientId.equals(castOther.clientId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.trknum.hashCode();
		hash = hash * prime + this.supnum.hashCode();
		hash = hash * prime + this.invnum.hashCode();
		hash = hash * prime + this.invlin.hashCode();
		hash = hash * prime + this.invsln.hashCode();
		hash = hash * prime + ((int) (this.seqnum ^ (this.seqnum >>> 32)));
		hash = hash * prime + this.whId.hashCode();
		hash = hash * prime + this.clientId.hashCode();
		
		return hash;
	}
}