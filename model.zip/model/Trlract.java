package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TRLRACT database table.
 * 
 */
@Entity
@NamedQuery(name="Trlract.findAll", query="SELECT t FROM Trlract t")
public class Trlract implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TRLRACT_ID")
	private String trlractId;

	private String actcod;

	@Column(name="APPT_ID")
	private String apptId;

	@Column(name="ASSET_TAG")
	private String assetTag;

	@Column(name="AUTOGEN_FLG")
	private BigDecimal autogenFlg;

	@Column(name="CAR_MOVE_ID")
	private String carMoveId;

	private String carcod;

	@Column(name="CLIENT_ID")
	private String clientId;

	@Column(name="MOD_COLLST")
	private String modCollst;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Column(name="MOD_VALLST")
	private String modVallst;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	@Column(name="TRACTOR_NUM")
	private String tractorNum;

	private String trknum;

	@Column(name="TRLR_COD")
	private String trlrCod;

	@Column(name="TRLR_COND")
	private String trlrCond;

	@Column(name="TRLR_ID")
	private String trlrId;

	@Column(name="TRLR_NUM")
	private String trlrNum;

	@Column(name="TRLR_STAT")
	private String trlrStat;

	@Temporal(TemporalType.DATE)
	private Date trndte;

	@Column(name="WH_ID")
	private String whId;

	@Column(name="YARD_LOC")
	private String yardLoc;

	@Column(name="YARD_LOC_WH_ID")
	private String yardLocWhId;

	public Trlract() {
	}

	public String getTrlractId() {
		return this.trlractId;
	}

	public void setTrlractId(String trlractId) {
		this.trlractId = trlractId;
	}

	public String getActcod() {
		return this.actcod;
	}

	public void setActcod(String actcod) {
		this.actcod = actcod;
	}

	public String getApptId() {
		return this.apptId;
	}

	public void setApptId(String apptId) {
		this.apptId = apptId;
	}

	public String getAssetTag() {
		return this.assetTag;
	}

	public void setAssetTag(String assetTag) {
		this.assetTag = assetTag;
	}

	public BigDecimal getAutogenFlg() {
		return this.autogenFlg;
	}

	public void setAutogenFlg(BigDecimal autogenFlg) {
		this.autogenFlg = autogenFlg;
	}

	public String getCarMoveId() {
		return this.carMoveId;
	}

	public void setCarMoveId(String carMoveId) {
		this.carMoveId = carMoveId;
	}

	public String getCarcod() {
		return this.carcod;
	}

	public void setCarcod(String carcod) {
		this.carcod = carcod;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getModCollst() {
		return this.modCollst;
	}

	public void setModCollst(String modCollst) {
		this.modCollst = modCollst;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public String getModVallst() {
		return this.modVallst;
	}

	public void setModVallst(String modVallst) {
		this.modVallst = modVallst;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getTractorNum() {
		return this.tractorNum;
	}

	public void setTractorNum(String tractorNum) {
		this.tractorNum = tractorNum;
	}

	public String getTrknum() {
		return this.trknum;
	}

	public void setTrknum(String trknum) {
		this.trknum = trknum;
	}

	public String getTrlrCod() {
		return this.trlrCod;
	}

	public void setTrlrCod(String trlrCod) {
		this.trlrCod = trlrCod;
	}

	public String getTrlrCond() {
		return this.trlrCond;
	}

	public void setTrlrCond(String trlrCond) {
		this.trlrCond = trlrCond;
	}

	public String getTrlrId() {
		return this.trlrId;
	}

	public void setTrlrId(String trlrId) {
		this.trlrId = trlrId;
	}

	public String getTrlrNum() {
		return this.trlrNum;
	}

	public void setTrlrNum(String trlrNum) {
		this.trlrNum = trlrNum;
	}

	public String getTrlrStat() {
		return this.trlrStat;
	}

	public void setTrlrStat(String trlrStat) {
		this.trlrStat = trlrStat;
	}

	public Date getTrndte() {
		return this.trndte;
	}

	public void setTrndte(Date trndte) {
		this.trndte = trndte;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

	public String getYardLoc() {
		return this.yardLoc;
	}

	public void setYardLoc(String yardLoc) {
		this.yardLoc = yardLoc;
	}

	public String getYardLocWhId() {
		return this.yardLocWhId;
	}

	public void setYardLocWhId(String yardLocWhId) {
		this.yardLocWhId = yardLocWhId;
	}

}