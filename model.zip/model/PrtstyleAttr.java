package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the PRTSTYLE_ATTR database table.
 * 
 */
@Entity
@Table(name="PRTSTYLE_ATTR")
@NamedQuery(name="PrtstyleAttr.findAll", query="SELECT p FROM PrtstyleAttr p")
public class PrtstyleAttr implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PrtstyleAttrPK id;

	public PrtstyleAttr() {
	}

	public PrtstyleAttrPK getId() {
		return this.id;
	}

	public void setId(PrtstyleAttrPK id) {
		this.id = id;
	}

}