package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PCKLST_BREAK_ON_CRI database table.
 * 
 */
@Entity
@Table(name="PCKLST_BREAK_ON_CRI")
@NamedQuery(name="PcklstBreakOnCri.findAll", query="SELECT p FROM PcklstBreakOnCri p")
public class PcklstBreakOnCri implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PCKLST_BREAK_ON_CRI_ID")
	private long pcklstBreakOnCriId;

	@Column(name="BREAK_ON_FIELD")
	private String breakOnField;

	@Column(name="BREAK_ON_FUNCTION")
	private String breakOnFunction;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="MAX_ADD_PICK_WEIGHT")
	private BigDecimal maxAddPickWeight;

	@Column(name="MAX_PCKUNTQTY")
	private BigDecimal maxPckuntqty;

	@Column(name="MAX_QTY")
	private BigDecimal maxQty;

	@Column(name="MAX_VOLUME")
	private BigDecimal maxVolume;

	@Column(name="MAX_WEIGHT")
	private BigDecimal maxWeight;

	@Column(name="MIN_VOLUME")
	private BigDecimal minVolume;

	@Column(name="MIN_WEIGHT")
	private BigDecimal minWeight;

	@Column(name="PCKLST_RULE_ID")
	private BigDecimal pcklstRuleId;

	private BigDecimal seqnum;

	@Column(name="VOLUME_THR")
	private BigDecimal volumeThr;

	public PcklstBreakOnCri() {
	}

	public long getPcklstBreakOnCriId() {
		return this.pcklstBreakOnCriId;
	}

	public void setPcklstBreakOnCriId(long pcklstBreakOnCriId) {
		this.pcklstBreakOnCriId = pcklstBreakOnCriId;
	}

	public String getBreakOnField() {
		return this.breakOnField;
	}

	public void setBreakOnField(String breakOnField) {
		this.breakOnField = breakOnField;
	}

	public String getBreakOnFunction() {
		return this.breakOnFunction;
	}

	public void setBreakOnFunction(String breakOnFunction) {
		this.breakOnFunction = breakOnFunction;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public BigDecimal getMaxAddPickWeight() {
		return this.maxAddPickWeight;
	}

	public void setMaxAddPickWeight(BigDecimal maxAddPickWeight) {
		this.maxAddPickWeight = maxAddPickWeight;
	}

	public BigDecimal getMaxPckuntqty() {
		return this.maxPckuntqty;
	}

	public void setMaxPckuntqty(BigDecimal maxPckuntqty) {
		this.maxPckuntqty = maxPckuntqty;
	}

	public BigDecimal getMaxQty() {
		return this.maxQty;
	}

	public void setMaxQty(BigDecimal maxQty) {
		this.maxQty = maxQty;
	}

	public BigDecimal getMaxVolume() {
		return this.maxVolume;
	}

	public void setMaxVolume(BigDecimal maxVolume) {
		this.maxVolume = maxVolume;
	}

	public BigDecimal getMaxWeight() {
		return this.maxWeight;
	}

	public void setMaxWeight(BigDecimal maxWeight) {
		this.maxWeight = maxWeight;
	}

	public BigDecimal getMinVolume() {
		return this.minVolume;
	}

	public void setMinVolume(BigDecimal minVolume) {
		this.minVolume = minVolume;
	}

	public BigDecimal getMinWeight() {
		return this.minWeight;
	}

	public void setMinWeight(BigDecimal minWeight) {
		this.minWeight = minWeight;
	}

	public BigDecimal getPcklstRuleId() {
		return this.pcklstRuleId;
	}

	public void setPcklstRuleId(BigDecimal pcklstRuleId) {
		this.pcklstRuleId = pcklstRuleId;
	}

	public BigDecimal getSeqnum() {
		return this.seqnum;
	}

	public void setSeqnum(BigDecimal seqnum) {
		this.seqnum = seqnum;
	}

	public BigDecimal getVolumeThr() {
		return this.volumeThr;
	}

	public void setVolumeThr(BigDecimal volumeThr) {
		this.volumeThr = volumeThr;
	}

}