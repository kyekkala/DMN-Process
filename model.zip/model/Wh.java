package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the WH database table.
 * 
 */
@Entity
@NamedQuery(name="Wh.findAll", query="SELECT w FROM Wh w")
public class Wh implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="WH_ID")
	private String whId;

	private BigDecimal active;

	@Column(name="ADJ_THR_CST")
	private BigDecimal adjThrCst;

	@Column(name="ADJ_THR_UNIT")
	private BigDecimal adjThrUnit;

	@Column(name="ADR_ID")
	private String adrId;

	@Column(name="AISLE_MAX")
	private BigDecimal aisleMax;

	@Column(name="AUTO_PLAY_CST_THR")
	private BigDecimal autoPlayCstThr;

	@Column(name="BAY_MAX")
	private BigDecimal bayMax;

	@Column(name="CNSG_COD")
	private String cnsgCod;

	@Column(name="CNSG_PERIOD")
	private BigDecimal cnsgPeriod;

	@Column(name="CNT_THR_CST")
	private BigDecimal cntThrCst;

	@Column(name="CNT_THR_UNIT")
	private BigDecimal cntThrUnit;

	@Column(name="CONCAT_ORDER")
	private BigDecimal concatOrder;

	@Column(name="CRNCY_CODE")
	private String crncyCode;

	@Column(name="DEF_WH_FLG")
	private BigDecimal defWhFlg;

	@Column(name="DFLT_HLDPFX")
	private String dfltHldpfx;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DT")
	private Date insDt;

	@Column(name="INS_USER_ID")
	private String insUserId;

	@Column(name="LAST_REGEN_TIME")
	private String lastRegenTime;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DT")
	private Date lastUpdDt;

	@Column(name="LAST_UPD_USER_ID")
	private String lastUpdUserId;

	@Column(name="LENS_CUST_CLIENT_ID")
	private String lensCustClientId;

	@Column(name="LENS_CUSTOMER_ID")
	private String lensCustomerId;

	@Column(name="LENS_ENA_FLG")
	private BigDecimal lensEnaFlg;

	@Column(name="LENS_SITNAM")
	private String lensSitnam;

	@Column(name="LST_RTTN_ID")
	private String lstRttnId;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private String orgcod;

	@Column(name="PERM_ADJ_LOD")
	private String permAdjLod;

	@Column(name="PERM_ADJ_SUB")
	private String permAdjSub;

	@Column(name="PERM_CRE_LOD")
	private String permCreLod;

	@Column(name="PERM_CRE_SUB")
	private String permCreSub;

	@Temporal(TemporalType.DATE)
	@Column(name="RECALC_DATE")
	private Date recalcDate;

	@Column(name="RECALC_DIST_FLAG")
	private BigDecimal recalcDistFlag;

	@Column(name="RFID_ENA_FLG")
	private BigDecimal rfidEnaFlg;

	@Column(name="RTTN_ID_MAX_VALUE")
	private String rttnIdMaxValue;

	@Column(name="RTTN_ID_MIN_VALUE")
	private String rttnIdMinValue;

	private String sgln;

	@Column(name="SLOT_MAX")
	private BigDecimal slotMax;

	@Column(name="TRANS_WH_ID")
	private String transWhId;

	@Column(name="U_VERSION")
	private BigDecimal uVersion;

	@Column(name="WH_TYP_CD")
	private String whTypCd;

	@Column(name="WMP_LEFT_X")
	private BigDecimal wmpLeftX;

	@Column(name="WMP_LOWER_Y")
	private BigDecimal wmpLowerY;

	@Column(name="WMP_RIGHT_X")
	private BigDecimal wmpRightX;

	@Column(name="WMP_UPPER_Y")
	private BigDecimal wmpUpperY;

	public Wh() {
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

	public BigDecimal getActive() {
		return this.active;
	}

	public void setActive(BigDecimal active) {
		this.active = active;
	}

	public BigDecimal getAdjThrCst() {
		return this.adjThrCst;
	}

	public void setAdjThrCst(BigDecimal adjThrCst) {
		this.adjThrCst = adjThrCst;
	}

	public BigDecimal getAdjThrUnit() {
		return this.adjThrUnit;
	}

	public void setAdjThrUnit(BigDecimal adjThrUnit) {
		this.adjThrUnit = adjThrUnit;
	}

	public String getAdrId() {
		return this.adrId;
	}

	public void setAdrId(String adrId) {
		this.adrId = adrId;
	}

	public BigDecimal getAisleMax() {
		return this.aisleMax;
	}

	public void setAisleMax(BigDecimal aisleMax) {
		this.aisleMax = aisleMax;
	}

	public BigDecimal getAutoPlayCstThr() {
		return this.autoPlayCstThr;
	}

	public void setAutoPlayCstThr(BigDecimal autoPlayCstThr) {
		this.autoPlayCstThr = autoPlayCstThr;
	}

	public BigDecimal getBayMax() {
		return this.bayMax;
	}

	public void setBayMax(BigDecimal bayMax) {
		this.bayMax = bayMax;
	}

	public String getCnsgCod() {
		return this.cnsgCod;
	}

	public void setCnsgCod(String cnsgCod) {
		this.cnsgCod = cnsgCod;
	}

	public BigDecimal getCnsgPeriod() {
		return this.cnsgPeriod;
	}

	public void setCnsgPeriod(BigDecimal cnsgPeriod) {
		this.cnsgPeriod = cnsgPeriod;
	}

	public BigDecimal getCntThrCst() {
		return this.cntThrCst;
	}

	public void setCntThrCst(BigDecimal cntThrCst) {
		this.cntThrCst = cntThrCst;
	}

	public BigDecimal getCntThrUnit() {
		return this.cntThrUnit;
	}

	public void setCntThrUnit(BigDecimal cntThrUnit) {
		this.cntThrUnit = cntThrUnit;
	}

	public BigDecimal getConcatOrder() {
		return this.concatOrder;
	}

	public void setConcatOrder(BigDecimal concatOrder) {
		this.concatOrder = concatOrder;
	}

	public String getCrncyCode() {
		return this.crncyCode;
	}

	public void setCrncyCode(String crncyCode) {
		this.crncyCode = crncyCode;
	}

	public BigDecimal getDefWhFlg() {
		return this.defWhFlg;
	}

	public void setDefWhFlg(BigDecimal defWhFlg) {
		this.defWhFlg = defWhFlg;
	}

	public String getDfltHldpfx() {
		return this.dfltHldpfx;
	}

	public void setDfltHldpfx(String dfltHldpfx) {
		this.dfltHldpfx = dfltHldpfx;
	}

	public Date getInsDt() {
		return this.insDt;
	}

	public void setInsDt(Date insDt) {
		this.insDt = insDt;
	}

	public String getInsUserId() {
		return this.insUserId;
	}

	public void setInsUserId(String insUserId) {
		this.insUserId = insUserId;
	}

	public String getLastRegenTime() {
		return this.lastRegenTime;
	}

	public void setLastRegenTime(String lastRegenTime) {
		this.lastRegenTime = lastRegenTime;
	}

	public Date getLastUpdDt() {
		return this.lastUpdDt;
	}

	public void setLastUpdDt(Date lastUpdDt) {
		this.lastUpdDt = lastUpdDt;
	}

	public String getLastUpdUserId() {
		return this.lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getLensCustClientId() {
		return this.lensCustClientId;
	}

	public void setLensCustClientId(String lensCustClientId) {
		this.lensCustClientId = lensCustClientId;
	}

	public String getLensCustomerId() {
		return this.lensCustomerId;
	}

	public void setLensCustomerId(String lensCustomerId) {
		this.lensCustomerId = lensCustomerId;
	}

	public BigDecimal getLensEnaFlg() {
		return this.lensEnaFlg;
	}

	public void setLensEnaFlg(BigDecimal lensEnaFlg) {
		this.lensEnaFlg = lensEnaFlg;
	}

	public String getLensSitnam() {
		return this.lensSitnam;
	}

	public void setLensSitnam(String lensSitnam) {
		this.lensSitnam = lensSitnam;
	}

	public String getLstRttnId() {
		return this.lstRttnId;
	}

	public void setLstRttnId(String lstRttnId) {
		this.lstRttnId = lstRttnId;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getOrgcod() {
		return this.orgcod;
	}

	public void setOrgcod(String orgcod) {
		this.orgcod = orgcod;
	}

	public String getPermAdjLod() {
		return this.permAdjLod;
	}

	public void setPermAdjLod(String permAdjLod) {
		this.permAdjLod = permAdjLod;
	}

	public String getPermAdjSub() {
		return this.permAdjSub;
	}

	public void setPermAdjSub(String permAdjSub) {
		this.permAdjSub = permAdjSub;
	}

	public String getPermCreLod() {
		return this.permCreLod;
	}

	public void setPermCreLod(String permCreLod) {
		this.permCreLod = permCreLod;
	}

	public String getPermCreSub() {
		return this.permCreSub;
	}

	public void setPermCreSub(String permCreSub) {
		this.permCreSub = permCreSub;
	}

	public Date getRecalcDate() {
		return this.recalcDate;
	}

	public void setRecalcDate(Date recalcDate) {
		this.recalcDate = recalcDate;
	}

	public BigDecimal getRecalcDistFlag() {
		return this.recalcDistFlag;
	}

	public void setRecalcDistFlag(BigDecimal recalcDistFlag) {
		this.recalcDistFlag = recalcDistFlag;
	}

	public BigDecimal getRfidEnaFlg() {
		return this.rfidEnaFlg;
	}

	public void setRfidEnaFlg(BigDecimal rfidEnaFlg) {
		this.rfidEnaFlg = rfidEnaFlg;
	}

	public String getRttnIdMaxValue() {
		return this.rttnIdMaxValue;
	}

	public void setRttnIdMaxValue(String rttnIdMaxValue) {
		this.rttnIdMaxValue = rttnIdMaxValue;
	}

	public String getRttnIdMinValue() {
		return this.rttnIdMinValue;
	}

	public void setRttnIdMinValue(String rttnIdMinValue) {
		this.rttnIdMinValue = rttnIdMinValue;
	}

	public String getSgln() {
		return this.sgln;
	}

	public void setSgln(String sgln) {
		this.sgln = sgln;
	}

	public BigDecimal getSlotMax() {
		return this.slotMax;
	}

	public void setSlotMax(BigDecimal slotMax) {
		this.slotMax = slotMax;
	}

	public String getTransWhId() {
		return this.transWhId;
	}

	public void setTransWhId(String transWhId) {
		this.transWhId = transWhId;
	}

	public BigDecimal getUVersion() {
		return this.uVersion;
	}

	public void setUVersion(BigDecimal uVersion) {
		this.uVersion = uVersion;
	}

	public String getWhTypCd() {
		return this.whTypCd;
	}

	public void setWhTypCd(String whTypCd) {
		this.whTypCd = whTypCd;
	}

	public BigDecimal getWmpLeftX() {
		return this.wmpLeftX;
	}

	public void setWmpLeftX(BigDecimal wmpLeftX) {
		this.wmpLeftX = wmpLeftX;
	}

	public BigDecimal getWmpLowerY() {
		return this.wmpLowerY;
	}

	public void setWmpLowerY(BigDecimal wmpLowerY) {
		this.wmpLowerY = wmpLowerY;
	}

	public BigDecimal getWmpRightX() {
		return this.wmpRightX;
	}

	public void setWmpRightX(BigDecimal wmpRightX) {
		this.wmpRightX = wmpRightX;
	}

	public BigDecimal getWmpUpperY() {
		return this.wmpUpperY;
	}

	public void setWmpUpperY(BigDecimal wmpUpperY) {
		this.wmpUpperY = wmpUpperY;
	}

}