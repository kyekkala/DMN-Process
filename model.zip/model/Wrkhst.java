package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the WRKHST database table.
 * 
 */
@Entity
@NamedQuery(name="Wrkhst.findAll", query="SELECT w FROM Wrkhst w")
public class Wrkhst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="WRKHST_ID")
	private String wrkhstId;

	@Column(name="ACK_USR_ID")
	private String ackUsrId;

	private String ackdevcod;

	@Temporal(TemporalType.DATE)
	private Date ackdte;

	@Temporal(TemporalType.DATE)
	private Date adddte;

	@Column(name="ARC_SRC")
	private String arcSrc;

	@Temporal(TemporalType.DATE)
	private Date arcdte;

	private BigDecimal baspri;

	@Column(name="CLIENT_ID")
	private String clientId;

	private String cmpcod;

	@Temporal(TemporalType.DATE)
	private Date cmpdte;

	private String dstloc;

	private BigDecimal effpri;

	@Temporal(TemporalType.DATE)
	private Date issdte;

	private String lblbat;

	@Column(name="LIST_ID")
	private String listId;

	private String lodnum;

	@Temporal(TemporalType.DATE)
	private Date middte;

	@Column(name="MOD_USR_ID")
	private String modUsrId;

	@Temporal(TemporalType.DATE)
	private Date moddte;

	private String oprcod;

	private String prvloc;

	private String refloc;

	private BigDecimal reqnum;

	@Column(name="RF_OUT_AUD_ID")
	private String rfOutAudId;

	private String srcloc;

	@Column(name="WH_ID")
	private String whId;

	private String wrkref;

	private String wrksts;

	public Wrkhst() {
	}

	public String getWrkhstId() {
		return this.wrkhstId;
	}

	public void setWrkhstId(String wrkhstId) {
		this.wrkhstId = wrkhstId;
	}

	public String getAckUsrId() {
		return this.ackUsrId;
	}

	public void setAckUsrId(String ackUsrId) {
		this.ackUsrId = ackUsrId;
	}

	public String getAckdevcod() {
		return this.ackdevcod;
	}

	public void setAckdevcod(String ackdevcod) {
		this.ackdevcod = ackdevcod;
	}

	public Date getAckdte() {
		return this.ackdte;
	}

	public void setAckdte(Date ackdte) {
		this.ackdte = ackdte;
	}

	public Date getAdddte() {
		return this.adddte;
	}

	public void setAdddte(Date adddte) {
		this.adddte = adddte;
	}

	public String getArcSrc() {
		return this.arcSrc;
	}

	public void setArcSrc(String arcSrc) {
		this.arcSrc = arcSrc;
	}

	public Date getArcdte() {
		return this.arcdte;
	}

	public void setArcdte(Date arcdte) {
		this.arcdte = arcdte;
	}

	public BigDecimal getBaspri() {
		return this.baspri;
	}

	public void setBaspri(BigDecimal baspri) {
		this.baspri = baspri;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getCmpcod() {
		return this.cmpcod;
	}

	public void setCmpcod(String cmpcod) {
		this.cmpcod = cmpcod;
	}

	public Date getCmpdte() {
		return this.cmpdte;
	}

	public void setCmpdte(Date cmpdte) {
		this.cmpdte = cmpdte;
	}

	public String getDstloc() {
		return this.dstloc;
	}

	public void setDstloc(String dstloc) {
		this.dstloc = dstloc;
	}

	public BigDecimal getEffpri() {
		return this.effpri;
	}

	public void setEffpri(BigDecimal effpri) {
		this.effpri = effpri;
	}

	public Date getIssdte() {
		return this.issdte;
	}

	public void setIssdte(Date issdte) {
		this.issdte = issdte;
	}

	public String getLblbat() {
		return this.lblbat;
	}

	public void setLblbat(String lblbat) {
		this.lblbat = lblbat;
	}

	public String getListId() {
		return this.listId;
	}

	public void setListId(String listId) {
		this.listId = listId;
	}

	public String getLodnum() {
		return this.lodnum;
	}

	public void setLodnum(String lodnum) {
		this.lodnum = lodnum;
	}

	public Date getMiddte() {
		return this.middte;
	}

	public void setMiddte(Date middte) {
		this.middte = middte;
	}

	public String getModUsrId() {
		return this.modUsrId;
	}

	public void setModUsrId(String modUsrId) {
		this.modUsrId = modUsrId;
	}

	public Date getModdte() {
		return this.moddte;
	}

	public void setModdte(Date moddte) {
		this.moddte = moddte;
	}

	public String getOprcod() {
		return this.oprcod;
	}

	public void setOprcod(String oprcod) {
		this.oprcod = oprcod;
	}

	public String getPrvloc() {
		return this.prvloc;
	}

	public void setPrvloc(String prvloc) {
		this.prvloc = prvloc;
	}

	public String getRefloc() {
		return this.refloc;
	}

	public void setRefloc(String refloc) {
		this.refloc = refloc;
	}

	public BigDecimal getReqnum() {
		return this.reqnum;
	}

	public void setReqnum(BigDecimal reqnum) {
		this.reqnum = reqnum;
	}

	public String getRfOutAudId() {
		return this.rfOutAudId;
	}

	public void setRfOutAudId(String rfOutAudId) {
		this.rfOutAudId = rfOutAudId;
	}

	public String getSrcloc() {
		return this.srcloc;
	}

	public void setSrcloc(String srcloc) {
		this.srcloc = srcloc;
	}

	public String getWhId() {
		return this.whId;
	}

	public void setWhId(String whId) {
		this.whId = whId;
	}

	public String getWrkref() {
		return this.wrkref;
	}

	public void setWrkref(String wrkref) {
		this.wrkref = wrkref;
	}

	public String getWrksts() {
		return this.wrksts;
	}

	public void setWrksts(String wrksts) {
		this.wrksts = wrksts;
	}

}